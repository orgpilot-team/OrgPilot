# ARKA architecture reconciliation

Review date: 2026-11-09. Time zone: `Asia/Tehran`.

This review reconciles the three architecture documents with the official brief, dataset contracts, and the supplied Q01-Q17 review record. It changes documentation only. It does not claim product implementation, numerical equivalence, security, performance, or acceptance results.

The recorded team decisions are one bounded AI Agent, PostgreSQL as the only product database engine, and independent publication of valid manager reports. The previous embedded SQLite product calculator is superseded. SQLite remains permissible as an isolated reference test oracle. It is outside the product execution path.

## Sources and authority

Read the [source register](001-system-blueprint.md#system-2) for S01-S17. The official brief and dataset contracts define requirements. A team decision selects an architecture within those requirements. A Codex proposal alone does not establish approval.

The user identified `C:/Users/ashkriz/Desktop/Adr.md` as the requested review file. An [unchanged source copy](sources/Adr.md) is retained in this documentation set. Its question text and final result table were both checked. The original decision approvers and approval dates are not supplied. This review does not invent them.

The [existing Structurizr model](../../architecture/structurizr/workspace.dsl) confirms the three decisions above. Its authority notes and relevant component contracts were checked. It is an existing target model, not proof of implementation. It was not changed.

| Source | SHA-256 at this review |
|---|---|
| S16 review record and exact source copy | `0c7cea554016930366100cb1138ada6ace7f05e918e274ee24f0a89e465639df` |
| S01 current brief PDF | `6d68d3fcc285f6908af0d97c0429dfefb489f00b7f6538ed03573552ed6955f8` |

Document 001 formerly listed a different PDF hash. It does not match the current file. All 19 pages of the current file were read. Pages 13 and 16 were also checked as images. A hash difference alone does not establish a change in requirements. Earlier numerical audit results remain attributed historical evidence.

Use exactly four decision statuses:

- `Requirement`: an explicit brief or dataset contract rule.
- `Accepted`: a recorded team decision.
- `Proposed`: a design choice without approval evidence.
- `Open`: an unresolved choice or source conflict.

A question can contain more than one status. For example, Q03 has an Accepted engine choice and an Open equivalence gate. Do not give the whole question one status that hides this distinction. The review source's count of explicit, partial, and absent brief answers is a source summary. It is not an approval count.

<a id="question-map"></a>

## Q01-Q17 mapping

These IDs refer only to the architecture review in S16. [Manager questions Q01-Q16](003-decisions-and-roadmap.md#manager-question-map) belong to S07. Diagram review questions use the `VQ` prefix in [their register](visualizations/open-questions.md).

All acceptance gates below are planned. They were not executed in this documentation task.

| Review question | Requirement and decision status | ADRs | Document sections | Acceptance gates and open log |
|---|---|---|---|---|
| <a id="review-q01"></a>Q01: Agent topology | `Accepted`: one bounded AI Agent plus deterministic modules; S16 Q01 result table explicitly records a team decision. `Open`: execution limits. | [ADR-13](003-decisions-and-roadmap.md#adr-13), [ADR-10](003-decisions-and-roadmap.md#adr-10) | [001: system](001-system-blueprint.md#system-1), [modules](001-system-blueprint.md#system-4) | [AT-20](003-decisions-and-roadmap.md#at-20), AT-17/18; DL-14 |
| <a id="review-q02"></a>Q02: files and intake | `Requirement`: structured sources, manager input, and uploads; S01 pp.3,12-14 and S02/S07. `Proposed`: separate document registration and structured intake. `Open`: exact formats, including Excel, and retrieval. | [ADR-16](003-decisions-and-roadmap.md#adr-16), ADR-08 | [001: modules](001-system-blueprint.md#system-4), [002: ingestion](002-data-architecture.md#data-4) | [AT-22](003-decisions-and-roadmap.md#at-22), AT-03/13; DL-10 |
| <a id="review-q03"></a>Q03: 55 KPIs in PostgreSQL | `Accepted`: PostgreSQL only; S16 Q03 body/result and S17. `Requirement`: canonical results unchanged; S02-S04 and S01 p.16. `Proposed`: versioned translations. `Open`: proof for all 55 definitions. | [ADR-01](003-decisions-and-roadmap.md#adr-01) | [002: calculation](002-data-architecture.md#data-6), [engine boundary](002-data-architecture.md#data-10) | [AT-02](003-decisions-and-roadmap.md#at-02), AT-03/05/17; DL-01 |
| <a id="review-q04"></a>Q04: natural-language queries | `Requirement`: read-only, registered SQL with data-layer row controls; S01 pp.9,13. `Proposed`: predefined tools first, then validated custom SQL. `Open`: exact allowlists and limits. Free SQL is incompatible with the required boundary. | [ADR-06](003-decisions-and-roadmap.md#adr-06), ADR-10 | [001: security](001-system-blueprint.md#system-10), [002: query path](002-data-architecture.md#data-10) | [AT-06](003-decisions-and-roadmap.md#at-06), AT-10/16/20; DL-06/14 |
| <a id="review-q05"></a>Q05: duplicate orders | `Requirement`: report duplicates as data issues; preserve original dataset and SQL. `Open`: accepted RAW/DEDUP calculation policy. S16's two-mode comparison is Proposed, not organizer approval. | [ADR-02](003-decisions-and-roadmap.md#adr-02) | [002: ingestion](002-data-architecture.md#data-4), [calculation](002-data-architecture.md#data-6) | AT-02, [AT-05](003-decisions-and-roadmap.md#at-05); DL-02 |
| <a id="review-q06"></a>Q06: incomplete data | `Requirement`: continue reports, identify missing sources, and use null for unavailable current values; S01 pp.13-14,17 and S02. S16 summary/S17 retain dated last-valid context. `Open`: release conditions, age, closure, and wire mapping. | [ADR-04](003-decisions-and-roadmap.md#adr-04) | [002: quality](002-data-architecture.md#data-5), [001: output](001-system-blueprint.md#system-9) | [AT-04](003-decisions-and-roadmap.md#at-04), [AT-23](003-decisions-and-roadmap.md#at-23); DL-03 |
| <a id="review-q07"></a>Q07: historical correction | `Requirement`: cutoff eligibility and canonical results; S02-S04. Preserve the existing versioned snapshot/report design. `Proposed`: full rebuild as the correctness baseline. `Open`: selective calculation and restatement notices. | [ADR-03](003-decisions-and-roadmap.md#adr-03), [ADR-05](003-decisions-and-roadmap.md#adr-05) | [002: time](002-data-architecture.md#data-3), [recalculation](002-data-architecture.md#data-7), [lineage](002-data-architecture.md#data-8) | AT-02/03/05; DL-04 |
| <a id="review-q08"></a>Q08: conflicting records | `Requirement`: preserve source facts and report data issues. `Proposed`: conflict state and quarantine. `Open`: a valid precedence rule. No last-row-wins rule is supplied. | [ADR-11](003-decisions-and-roadmap.md#adr-11) | [002: time](002-data-architecture.md#data-3), [ingestion](002-data-architecture.md#data-4) | AT-05; DL-05 |
| <a id="review-q09"></a>Q09: access | `Requirement`: supplied hierarchy, row controls for every query, individual workload data only for a direct supervisor; S01 pp.5,10,13 and S05. `Proposed`: policy catalog. `Open`: shared-source predicates and columns. | [ADR-06](003-decisions-and-roadmap.md#adr-06) | [001: security](001-system-blueprint.md#system-10), [002: organization](002-data-architecture.md#data-9) | AT-06/07/13; DL-06 |
| <a id="review-q10"></a>Q10: capacity and personal data | `Requirement`: aggregate team capacity, no individual attendance monitoring; S01 pp.6,9,12-13. `Proposed`: a headcount measure. `Open`: formula, hours contract, small-group inference, and text redaction. | [ADR-06](003-decisions-and-roadmap.md#adr-06) | [001: analysis](001-system-blueprint.md#system-8), [002: organization](002-data-architecture.md#data-9) | AT-06/10; DL-07 |
| <a id="review-q11"></a>Q11: three workflows | `Requirement`: actual event reconstruction, stage SLA, and supplied M01 workflow ownership; S01 pp.5-6,16 and S11. `Proposed`: stage catalog. `Open`: stage owners and routing. | [ADR-15](003-decisions-and-roadmap.md#adr-15), ADR-07 | [001: workflows](001-system-blueprint.md#system-7), [002: entities](002-data-architecture.md#data-2) | [AT-12](003-decisions-and-roadmap.md#at-12), AT-08; DL-08 |
| <a id="review-q12"></a>Q12: signals and escalation | `Requirement`: deterministic detection and R1-R8; S01 pp.6-8,13 and S11. `Proposed`: strict crossing and named unknown states. `Open`: equality, baseline, zero denominator, warning-day count, and reset. | [ADR-07](003-decisions-and-roadmap.md#adr-07) | [001: signals](001-system-blueprint.md#system-7), [002: quality](002-data-architecture.md#data-5) | [AT-08](003-decisions-and-roadmap.md#at-08), AT-09; DL-09 |
| <a id="review-q13"></a>Q13: organization and receipt time | `Requirement`: Tehran time, cutoff, next-report input effect, dynamic structure; S01 p.14, S02/S05/S07. `Open`: M11 morning 75/76, historic scope, same-day receipt, calendar known-at. Morning 76 in S16 is Proposed. | [ADR-08](003-decisions-and-roadmap.md#adr-08), ADR-16 | [001: replay](001-system-blueprint.md#system-5), [002: time](002-data-architecture.md#data-3), [organization](002-data-architecture.md#data-9) | AT-03/07/15/22; DL-10 |
| <a id="review-q14"></a>Q14: role reports and shared analysis | `Requirement`: one Insight Brief as report source and role-specific access; S01 pp.9-10. `Open`: internal schema and suppressed/ongoing mapping. Shared evidence is never a new grant. | [ADR-09](003-decisions-and-roadmap.md#adr-09), ADR-06 | [001: analysis](001-system-blueprint.md#system-8), [output](001-system-blueprint.md#system-9), [002: report versions](002-data-architecture.md#data-8) | AT-06/10/11; DL-11 |
| <a id="review-q15"></a>Q15: decisions and action | `Requirement`: human decision, drafts only, no automatic execution; S01 pp.11-12 and S02. `Proposed`: separate decision, draft, and execution-confirmation states. `Open`: actual execution tracking in MVP. | [ADR-17](003-decisions-and-roadmap.md#adr-17) | [001: modules](001-system-blueprint.md#system-4), [analysis](001-system-blueprint.md#system-8), [002: report history](002-data-architecture.md#data-8) | [AT-14](003-decisions-and-roadmap.md#at-14); DL-12 |
| <a id="review-q16"></a>Q16: LLM failure | `Accepted`: independent valid-report publication and failed-report records; S16 Q16 result table and S17. `Requirement`: every active manager still needs a valid report. `Proposed`: template fallback. `Open`: retry, timeout, status export, replacement rules. | [ADR-14](003-decisions-and-roadmap.md#adr-14), ADR-10 | [001: replay](001-system-blueprint.md#system-5), [output](001-system-blueprint.md#system-9), [002: operations](002-data-architecture.md#data-11) | [AT-21](003-decisions-and-roadmap.md#at-21), AT-11/15/18; DL-13 |
| <a id="review-q17"></a>Q17: models and limits | `Requirement`: USD 5 per whole day, 15 minutes, and report deadline; S01 pp.14,16,19. `Proposed`: provider-neutral gateway, reservations, tool/token limits, tracing, and QA share. `Open`: model, provider, products, prices, and exact limits. | [ADR-10](003-decisions-and-roadmap.md#adr-10), ADR-13 | [001: analysis](001-system-blueprint.md#system-8), [003: measurement](003-decisions-and-roadmap.md#decisions-8) | [AT-17](003-decisions-and-roadmap.md#at-17), [AT-18](003-decisions-and-roadmap.md#at-18), AT-20; DL-14/16 |

## Important conflicts and disposition

The [Decision Log](003-decisions-and-roadmap.md#decision-log) retains options, effects, owners, and gates. No Open row is silently closed by this review.

| Conflict | Disposition |
|---|---|
| Old dual-engine proposal versus recorded PostgreSQL-only decision | Resolved by explicit S16 Q03 decision, confirmed by S17. Update product and interactive paths. Keep original SQL and an isolated test oracle. Numerical proof remains Open. |
| Unqualified Proposed/Open banner versus recorded team decisions | Resolved by statement-level statuses. Add ADR-13 and ADR-14. Preserve unapproved design details as Proposed. |
| Daily atomic wording versus independent publication | Resolve at the package boundary: one manager's text/JSON is atomic; manager outcomes are independent. Incomplete required coverage cannot pass the day. Retry and fallback remain Open. |
| Q06 prior value versus current null contract | Preserve a historical display with the actual date. Never reuse that value as current. Exact wire mapping, eligibility, and age remain DL-03. |
| Q13 provisional morning 76 versus conflicting static metadata | Keep both scenarios. Neither the Codex proposal nor a calculated report count approves precedence. DL-10 remains Open. |
| Generic precision examples versus KPI-specific SQL | Use canonical definition and rounding. Registered ad hoc queries are permitted. Added-number wire representation remains Open. |
| Brief suppressed versus schema ongoing | Preserve both sources and suppression history. Do not change the dataset schema or invent a mapping. DL-11 remains Open. |
| Shared Insight versus recipient access | Reuse the analytical source with authorized projections. Restricted evidence and its derived claims cannot leak through shared prompts or cache. The internal schema remains Open. |

## Decisions needed before implementation

The architecture review is complete at the documentation level. Product implementation is outside this task. The team must resolve or explicitly approve named temporary policies for these P0 design choices before affected work starts:

1. Q03: translation/type contract and the all-55 equivalence plan. Proof is an implementation acceptance gate, not a result available now.
2. Q05/Q06/Q08: calculation input mode, invalid-data publication, dated prior-value mapping, and conflict handling. Organizer answers are needed where the source contract is incomplete.
3. Q04/Q09/Q10: shared-source row/column grants, privacy rules, capacity definition, and custom-query limits.
4. Q11/Q12/Q13: stage owners, signal edge rules, and time precedence for organization changes and attachments.
5. Q14/Q16/Q17: output-status contract, shared Insight representation, failure/status policy, and bounded model execution.

Retention and execution-confirmation details remain in DL-12/DL-15. Final hardware, hidden labels, and organizer limits block final acceptance, not independent documentation or authorized source-preservation work. The three Accepted topology decisions do not need to be selected again.

## File changes

| File | Change |
|---|---|
| [001 system blueprint](001-system-blueprint.md) | Apply the three recorded decisions. Correct module, calculation, query, and publication boundaries. Add exact status definitions, sources, dated-value limits, and stable section/requirement anchors. |
| [002 data architecture](002-data-architecture.md) | Replace the dual-engine runtime proposal with PostgreSQL-only execution. Define versioned translation and equivalence gates. Preserve the 55-KPI catalog, source history, policies, and lineage design. |
| [003 decisions and roadmap](003-decisions-and-roadmap.md) | Update ADR-01/04/09. Add ADR-13 through ADR-17, the Decision Log, and AT-20 through AT-23. Correct coverage and workflow gates. Separate manager question IDs from review IDs. Remove unqualified old delivery-check claims. |
| [Diagram open questions](visualizations/open-questions.md) | Use VQ IDs. Replace the retired engine question with the remaining translation/security gates. Link the central Decision Log. |
| [Entity contracts](visualizations/proposed-entity-contracts.md) | Correct the engine status. Keep physical entities and constraints Proposed. |
| [Diagram guide](visualizations/README.md) | Link current decisions and clarify legacy labels, question IDs, and historical verification claims. |
| [Source copy](sources/Adr.md) | Preserve the supplied review record without changes. |
| This review | Add the Q01-Q17 map, source provenance, conflict disposition, blockers, and verification limits. |
| [Unified diff](reconciliation.diff) | Compare the changed documents with the saved pre-edit files. Include new documentation. Exclude the diff itself. |

<a id="verification"></a>

## Verification record

Git status failed because this workspace has no Git repository. No commit or push was attempted. A pre-edit SHA-256 baseline and document copies were saved outside the workspace. The final comparison uses this baseline; it is not a Git diff.

<!-- VERIFICATION_RESULT_START -->
Documentation checks passed:

- All 17 review questions have one mapping row. All referenced ADR and acceptance IDs exist.
- The set has 17 ADRs and 23 planned acceptance gates. The original 12 ADR IDs and 19 acceptance IDs remain available.
- All 150 local Markdown links in the changed/new Markdown files resolve, including explicit section anchors. All five fenced diagram blocks have closed fences. No graphical Mermaid check is claimed.
- The 55-row KPI catalog is unchanged and its IDs match the supplied dictionary.
- All 1,193 dataset files in the baseline are unchanged. All 1,442 existing files outside the six edited documents retain their baseline hashes. This includes source SQL, review artifacts, and the Structurizr model. The scan excludes `.venv` and Git internals.
- The retained review source copy is byte-for-byte equal to the user's file. The external original hash is unchanged.
- Six existing Markdown files changed. Three files were added: this review, the source copy, and the unified diff. No existing file was deleted.

The diff excludes itself. It compares six edited files against verified pre-edit copies and includes the two new Markdown files.
<!-- VERIFICATION_RESULT_END -->

No KPI SQL, product, security, replay, model, performance, restore, or cost tests were run. No dependency was installed. Existing Mermaid diagrams were checked as document text only; no Mermaid renderer was run. Earlier audit and diagram checks are historical source claims, not new test results.
