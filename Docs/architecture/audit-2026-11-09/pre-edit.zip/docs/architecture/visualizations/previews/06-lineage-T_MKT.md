﻿```mermaid
flowchart LR
  LEGEND["CONFIRMED: direct evidence | DERIVED: SQL or measured relation<br/>PROPOSED: review required | UNRESOLVED: evidence gap"]
  cal["cal: calculation input"]
  crm_lead_events["crm_lead_events: calculation input"]
  crm_leads["crm_leads: calculation input"]
  order_events["order_events: calculation input"]
  orders["orders: calculation input"]
  task_events["task_events: calculation input"]
  tasks["tasks: calculation input"]
  lead_fact["lead_fact: SQL view"]
  crm_leads -->|DERIVED execution input| lead_fact
  crm_lead_events -->|DERIVED execution input| lead_fact
  crm_leads -->|"DERIVED join/filter: lead_id; drop_day correction selection"| lead_fact
  revenue_daily["revenue_daily: SQL view"]
  orders -->|DERIVED execution input| revenue_daily
  order_events -->|DERIVED execution input| revenue_daily
  lead_fact -->|DERIVED execution input| revenue_daily
  cal -->|DERIVED execution input| revenue_daily
  orders -->|"DERIVED join/filter: order_id; date; channel and event filters"| revenue_daily
  task_fact["task_fact: SQL view"]
  tasks -->|DERIVED execution input| task_fact
  task_events -->|DERIVED execution input| task_fact
  tasks -->|"DERIVED join/filter: task_id"| task_fact
  K_MKT_ORDERS["K_MKT_ORDERS"]
  orders -->|DERIVED computation| K_MKT_ORDERS
  K_MKT_ORDERS -->|CONFIRMED entity_id| T_MKT
  K_MKT_REV["K_MKT_REV"]
  revenue_daily -->|DERIVED computation| K_MKT_REV
  cal -->|"DERIVED join/population: d"| K_MKT_REV
  order_events -->|"DERIVED join/population: order_id"| K_MKT_REV
  orders -->|"DERIVED join/population: order_id"| K_MKT_REV
  K_MKT_REV -->|CONFIRMED entity_id| T_MKT
  K_TASK_OVERDUE_T_MKT["K_TASK_OVERDUE_T_MKT"]
  cal -->|DERIVED computation| K_TASK_OVERDUE_T_MKT
  task_fact -->|DERIVED computation| K_TASK_OVERDUE_T_MKT
  task_events -->|"DERIVED join/population: task_id"| K_TASK_OVERDUE_T_MKT
  tasks -->|"DERIVED join/population: task_id"| K_TASK_OVERDUE_T_MKT
  K_TASK_OVERDUE_T_MKT -->|CONFIRMED entity_id| T_MKT
  T_MKT -.->|CONFIRMED aggregate display; active dates apply| M01
  T_MKT -.->|CONFIRMED aggregate display; active dates apply| M02
  T_MKT -.->|CONFIRMED aggregate display; active dates apply| M11

```
