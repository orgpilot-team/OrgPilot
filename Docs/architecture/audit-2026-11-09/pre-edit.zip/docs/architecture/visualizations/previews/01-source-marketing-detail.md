﻿```mermaid
erDiagram
  mkt_daily {
    string date "date_lexeme; observed CSV"
    string source "text; observed CSV"
    string spend_toman "integer_lexeme; observed CSV"
    string impressions "integer_lexeme; observed CSV"
    string clicks "integer_lexeme; observed CSV"
    string leads "integer_lexeme; observed CSV"
  }
  web_sessions {
    string date "date_lexeme; observed CSV"
    string channel "text; observed CSV"
    string sessions "integer_lexeme; observed CSV"
  }

```
