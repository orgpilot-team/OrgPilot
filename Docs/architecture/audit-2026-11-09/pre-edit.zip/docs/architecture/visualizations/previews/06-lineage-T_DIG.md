﻿```mermaid
flowchart LR
  LEGEND["CONFIRMED: direct evidence | DERIVED: SQL or measured relation<br/>PROPOSED: review required | UNRESOLVED: evidence gap"]
  cal["cal: calculation input"]
  mkt_daily["mkt_daily: calculation input"]
  task_events["task_events: calculation input"]
  tasks["tasks: calculation input"]
  task_fact["task_fact: SQL view"]
  tasks -->|DERIVED execution input| task_fact
  task_events -->|DERIVED execution input| task_fact
  tasks -->|"DERIVED join/filter: task_id"| task_fact
  K_DIG_LEADS["K_DIG_LEADS"]
  mkt_daily -->|DERIVED computation| K_DIG_LEADS
  K_DIG_LEADS -->|CONFIRMED entity_id| T_DIG
  K_DIG_CPL_7D["K_DIG_CPL_7D"]
  cal -->|DERIVED computation| K_DIG_CPL_7D
  mkt_daily -->|DERIVED computation| K_DIG_CPL_7D
  K_DIG_CPL_7D -->|CONFIRMED entity_id| T_DIG
  K_DIG_SPEND["K_DIG_SPEND"]
  mkt_daily -->|DERIVED computation| K_DIG_SPEND
  K_DIG_SPEND -->|CONFIRMED entity_id| T_DIG
  K_TASK_OVERDUE_T_DIG["K_TASK_OVERDUE_T_DIG"]
  cal -->|DERIVED computation| K_TASK_OVERDUE_T_DIG
  task_fact -->|DERIVED computation| K_TASK_OVERDUE_T_DIG
  task_events -->|"DERIVED join/population: task_id"| K_TASK_OVERDUE_T_DIG
  tasks -->|"DERIVED join/population: task_id"| K_TASK_OVERDUE_T_DIG
  K_TASK_OVERDUE_T_DIG -->|CONFIRMED entity_id| T_DIG
  T_DIG -.->|CONFIRMED aggregate display; active dates apply| M01
  T_DIG -.->|CONFIRMED aggregate display; active dates apply| M02
  T_DIG -.->|CONFIRMED aggregate display; active dates apply| M06

```
