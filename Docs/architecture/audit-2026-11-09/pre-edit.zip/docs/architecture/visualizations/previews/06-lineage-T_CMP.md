﻿```mermaid
flowchart LR
  LEGEND["CONFIRMED: direct evidence | DERIVED: SQL or measured relation<br/>PROPOSED: review required | UNRESOLVED: evidence gap"]
  cal["cal: calculation input"]
  task_events["task_events: calculation input"]
  tasks["tasks: calculation input"]
  ticket_events["ticket_events: calculation input"]
  tickets["tickets: calculation input"]
  task_fact["task_fact: SQL view"]
  tasks -->|DERIVED execution input| task_fact
  task_events -->|DERIVED execution input| task_fact
  tasks -->|"DERIVED join/filter: task_id"| task_fact
  ticket_fact["ticket_fact: SQL view"]
  tickets -->|DERIVED execution input| ticket_fact
  ticket_events -->|DERIVED execution input| ticket_fact
  tickets -->|"DERIVED join/filter: ticket_id"| ticket_fact
  K_CMP_RES_48H_PCT["K_CMP_RES_48H_PCT"]
  ticket_fact -->|DERIVED computation| K_CMP_RES_48H_PCT
  ticket_events -->|"DERIVED join/population: ticket_id"| K_CMP_RES_48H_PCT
  tickets -->|"DERIVED join/population: ticket_id"| K_CMP_RES_48H_PCT
  K_CMP_RES_48H_PCT -->|CONFIRMED entity_id| T_CMP
  K_CMP_RES_MED["K_CMP_RES_MED"]
  ticket_fact -->|DERIVED computation| K_CMP_RES_MED
  ticket_events -->|"DERIVED join/population: ticket_id"| K_CMP_RES_MED
  tickets -->|"DERIVED join/population: ticket_id"| K_CMP_RES_MED
  K_CMP_RES_MED -->|CONFIRMED entity_id| T_CMP
  K_CMP_TICKETS["K_CMP_TICKETS"]
  cal -->|DERIVED computation| K_CMP_TICKETS
  tickets -->|DERIVED computation| K_CMP_TICKETS
  K_CMP_TICKETS -->|CONFIRMED entity_id| T_CMP
  K_CMP_BACKLOG["K_CMP_BACKLOG"]
  cal -->|DERIVED computation| K_CMP_BACKLOG
  ticket_fact -->|DERIVED computation| K_CMP_BACKLOG
  ticket_events -->|"DERIVED join/population: ticket_id"| K_CMP_BACKLOG
  tickets -->|"DERIVED join/population: ticket_id"| K_CMP_BACKLOG
  K_CMP_BACKLOG -->|CONFIRMED entity_id| T_CMP
  K_TASK_OVERDUE_T_CMP["K_TASK_OVERDUE_T_CMP"]
  cal -->|DERIVED computation| K_TASK_OVERDUE_T_CMP
  task_fact -->|DERIVED computation| K_TASK_OVERDUE_T_CMP
  task_events -->|"DERIVED join/population: task_id"| K_TASK_OVERDUE_T_CMP
  tasks -->|"DERIVED join/population: task_id"| K_TASK_OVERDUE_T_CMP
  K_TASK_OVERDUE_T_CMP -->|CONFIRMED entity_id| T_CMP
  T_CMP -.->|CONFIRMED aggregate display; active dates apply| M01
  T_CMP -.->|CONFIRMED aggregate display; active dates apply| M04
  T_CMP -.->|CONFIRMED aggregate display; active dates apply| M10

```
