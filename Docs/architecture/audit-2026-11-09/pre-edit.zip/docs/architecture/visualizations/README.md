# ARKA / DIDRAH diagrams and access evidence

Current reconciliation: 2026-11-09. See the [Q01-Q17 review](../004-reconciliation-review.md#question-map) and [Decision Log](../003-decisions-and-roadmap.md#decision-log). One bounded AI Agent, PostgreSQL-only product execution, and independent valid-report publication are Accepted. Physical data models and keys remain Proposed. Earlier SQLite lineage checks are historical reference checks, not approval of a product engine.

The remaining text records the earlier diagram task. Its counts, hash checks, and renderer limits are historical claims, not results of this reconciliation. CONFIRMED and DERIVED are evidence labels. They do not mean Accepted team decisions. The diagram review IDs use VQ01-VQ10. Q IDs in security examples refer to S07 manager inputs. The current architecture review Q01-Q17 is a separate namespace.

This collection describes source files, a proposed model, and required access limits. It does not implement a database or approve an open decision. Review date: 2026-11-03, Asia/Tehran.

## Read the diagrams

| Main diagram | Meaning | Companion detail |
|---|---|---|
| [01-source-data-erd.mmd](01-source-data-erd.mmd) | Observed CSV families and selected relations | Eight `01-source-*-detail.mmd` ERDs; catalog, profiles, and relationship evidence |
| [02-proposed-database-erd.mmd](02-proposed-database-erd.mmd) | Existing conceptual proposal, copied with proposal warning | [Layers](02-proposed-layers.mmd); [entity contracts](proposed-entity-contracts.md) |
| [03-organization-hierarchy.mmd](03-organization-hierarchy.mmd) | Unit/team assignments and derived manager reporting chain | manager-access-summary.csv; effective dates |
| [04-management-access-graph.mmd](04-management-access-graph.mmd) | Internal calculation and authorized query/report paths | [Worked examples](security-examples.md) |
| [05-column-access-overview.mmd](05-column-access-overview.mmd) | Column use and visibility classes | access-matrix-detailed.csv |
| [06-kpi-data-lineage.mmd](06-kpi-data-lineage.mmd) | Sources, five views, KPI entity groups, manager display scope | Eleven `06-lineage-*.mmd` domain diagrams; all 55 KPI records |

There are 26 Mermaid files. No SVG file was created. No suitable local Mermaid renderer was found. No dependency was installed and no network service was used. Structural checks passed. A Mermaid parser and visual layout check remain pending. The large lineage overview is an index; use the entity diagrams for detailed reading.

## Evidence labels and arrows

- CONFIRMED means a source file or an official requirement states the fact.
- DERIVED means SQL, identifier matches, or measured records support the link. It is not an enforced FK or a new grant.
- PROPOSED means a design needs review. Every entity and edge in Diagram B has this status.
- UNRESOLVED means evidence does not establish an exact answer.

In Diagram A, an arrow connects a parent key to a child reference. A domain ERD uses a dotted, non-identifying link. Its `0..1` parent and `0..many` child notation describes a candidate distinct-entity model. Read measured multiplicities and missing keys in relationship-evidence.csv. These symbols do not assert raw uniqueness or mandatory parents. Raw orders contain duplicates. No CSV relationship is enforced by a database.

In Diagram B, crow's-foot arrows reproduce the existing conceptual proposal. They do not describe installed tables or approved physical constraints. SourceFile to DQIncident has the proposal's limitation: a missing delivery can have an incident without a file.

In Diagram C, solid arrows show supplied assignments. Dotted arrows show a manager reporting chain derived through unit/team structure. Neither arrow is an access grant. In Diagram D, arrows show required information boundaries. They do not claim that security controls already exist. In Diagram E, computation use and display classification are independent axes. In Diagram F, solid arrows show computation, joins, or filters. Dotted entity-to-manager arrows show aggregate display scope from the access matrix. They never permit underlying source rows.

## Actual tables and columns

Inspected 1093 CSV files, including 1079 drops, with 26 file families and 139 distinct table/column pairs. Read all records for type shapes, nulls, key repeats, and joins. CSV has no declared SQL type. Observed lexical types do not choose a database storage type.

table-column-catalog.csv retains exact column names. It includes both `tickets.created_at` and `tickets.create_time`, and both `ticket_events.at` and `ticket_events.event_time`. An absent field after a header change is separate from an empty cell. The documented reference aliases are `create_time -> created_at`, `event_time -> at`, and `calendar_days.date -> cal.d`. `crm_lead_events.drop_day` is ingestion metadata required by reference SQL. It is not an observed CSV column.

table-profiles.csv reports candidate key repeats, exact repeats, file counts, and grains. Event tables have no supplied event occurrence ID. Do not use a business entity ID as an event PK. Daily observations are not a supplied persistent snapshot table. `orders.order_id` is not a reliable raw PK. Unique keys observed in this package remain candidates, not guarantees for hidden data. Customer and campaign IDs have no supplied parent registry. Marketing source strings do not prove a lead-to-advertising attribution FK.

relationship-evidence.csv contains 23 checked links: 11 CONFIRMED assignments and 12 DERIVED joins or identifier/date matches. All are unenforced. Full-data matching does not prove as-of-day completeness or effective-date validity. No relationship is asserted merely because two columns have the same name. The field `order_events.actor_team` refers to both team IDs and the unit ID `U_SAL`. Its checked parent domain is the union of units and teams. It is not a team-only FK. There are 5,017 empty `tickets.order_id` cells and 1,539 empty `ticket_events.staff_id` cells. Keep these optional references; do not make up parent records.

## Access matrix

access-matrix-detailed.csv contains 1529 records: every observed column for every manager. The records include scope, use, KPI dependencies, row conditions, query/report visibility, masking, evidence, and status. manager-access-summary.csv gives all 11 manager scopes and permitted KPI IDs.

`internal_use=REQUIRED_INTERNAL` is separate from `column_visibility`. A required input can be DENIED for display. VISIBLE_AGGREGATED means only the supplied authorized KPI result or the stated capacity purpose. It does not allow a manager to select the source column. VISIBLE_DIRECT_TEAM applies only to minimum workload fields for the direct supervisor. RESTRICTED requires an added documented condition. DENIED expresses a prohibited exposure. UNRESOLVED is not permission. Individual attendance status is never an authorized manager result; internal status can support team capacity only.

No raw-table grant was supplied. The matrix does not assert that all raw data is explicitly prohibited by name. It records the missing grant and prevents permission from being inferred. Candidate physical projections and predicate enforcement remain PROPOSED. The exact field mapping has DERIVED or UNRESOLVED status unless an official rule specifies it. No precise raw-column allowlist is present in the brief or CSV matrix.

M01-M04 have no employee-level exception. M05-M11 can use individual data only for direct-team workload. A supervisor cannot see individual leave under that exception. Do not expose unredacted task or ticket text without a purpose and redaction policy. Cross-team KPI computation runs under an internal service boundary; its result is authorized by KPI entity. [Security examples](security-examples.md) explain M07, M03, M01, M11, and shared orders.

## KPI lineage method

All 55 original KPI SQL statements compile with SQLite EXPLAIN against the five original views in an isolated memory schema. No source row was changed and no KPI result was generated in this task. sql-execution-column-reads.csv records prepare-time reads, including `o.*` and `t.*` expansion. Such reads can include unused fields. They are execution dependencies, not selected value lineage or display rights.

kpi-source-manager-mapping.csv separates execution sources from selected value and population sources. Selected view fields are expanded to their source fields. This expansion is conservative where identical field names occur in multiple relations. It is not a proof of a minimum invalidation set. The supplied SQL remains in each record for review. For revenue, selecting b2b does not make order amounts value inputs; selecting b2c or marketplace does not make CRM amounts value inputs. The full revenue view still needs all its relations to compile. The calendar spine can control row presence even when it does not supply an amount.

Each KPI owns the entity stated in the dictionary. A manager can display its aggregate result only if that entity occurs in visible_entities. owner_manager_id identifies signal ownership; it is not the only permitted aggregate viewer. The escalation rules do not grant new source access. None of the 55 definitions uses staff_availability. Capacity is a separate permitted purpose with an unresolved formula.

## Time and known limits

Use only deliveries through R-1 for morning R. Build facts after the cutoff. A filter on a full-history final fact does not prevent future information. Validate active manager, team, and staff records. M11, T_MKT, E25, and E26 have supplied day-75 starts. The first report morning and historic marketplace scope remain open. No diagram treats all 11 managers as active for the entire replay.

Staff assignments have effective dates, but not all temporary changes have a row-level dated transfer record. A decision text is not a replacement staff assignment. Calendar event timing and historic access need a known-at policy. The inherited architecture keeps these review points open.

## Validation and source protection

See validation-summary.json and diagram-validation.csv. All observed headers are catalogued. All 55 SQL statements and all 11 manager scopes are covered. Checks reject direct-team visibility for levels 1 and 2 and reject individual availability status display. All 1222 protected existing files outside .venv retained their SHA-256 hashes. protected-file-hashes.csv provides the baseline. All new output is in this directory. Existing architecture, source CSVs, SQL, JSON, PDF, audits, and notebooks remain unchanged. No commit or push was made.

The original 19-page PDF was read with the existing bundled pypdf package. Key access requirements were rechecked on pages 6, 10, 12, and 13. Supporting files include all three architecture documents, DATA_MAP_FA.md, exploration relationship evidence, DQ-001, KPI-VAL-001, and the technical review. The supplied matrix and brief take priority over proposals. PDF text extraction preserves imperfect Persian order; this collection uses the explicit requirements cross-checked with the source matrix and README. No new architectural decision was finalized.

For unresolved policy and design work, read [open-questions.md](open-questions.md). This is the stop point for this task.
