# ARCH-001: تصمیم‌ها، ریسک‌ها و مسیر پیاده‌سازی

Review date: 2026-11-09. Time zone: `Asia/Tehran`. Use Requirement, Accepted, Proposed, and Open for each statement. Acceptance of an engine or publication boundary does not close its technical gates.

Read this document with the [system blueprint](001-system-blueprint.md), [data architecture](002-data-architecture.md), and [Q01-Q17 review](004-reconciliation-review.md#question-map). Sources S01-S17 are listed in document 001. This task changes documentation only. It does not authorize product implementation.

<a id="decisions-1"></a>

## 1. Recorded decisions and remaining design

The recorded team decisions are one bounded AI Agent, PostgreSQL as the only product database engine, and independent publication of valid reports. S16 Q01/Q03/Q16 records these decisions. S17 confirms them. The former dual-engine product calculator is superseded.

Keep source occurrences, snapshot versions, and published reports. Distinguish calculation success, source completeness, publication eligibility, and day coverage. Preserve the existing deterministic calculation, signal, access, and validation boundaries. Detailed algorithms remain Proposed unless a source records approval.

The Decision Log below controls unresolved choices. An open gate is not permission to select an undocumented default.

<a id="decisions-2"></a>

## ۲. موارد روشن که نیاز به اختراع قاعده ندارند

| موضوع | نتیجهٔ مستند |
|---|---|
| cutoff گزارش | صبح R از dropهای تا R-1 استفاده می‌کند؛ S02. |
| پرسش مدیر | روز D از dropهای تا D-1 استفاده می‌کند؛ S02. |
| زمان اثر ورودی | ورودی روز D بر گزارش D+1 اثر دارد؛ S02. اختلاف مورد سازمان در ADR-08 باقی است. |
| تقویم | `date` به `cal.d` نگاشت می‌شود؛ `mdays` عرضه‌شده جایگزین نمی‌شود. |
| CRM | `drop_day` از manifest معتبر می‌آید؛ اصلاح value_corrected، replacement است و به تاریخ won منتسب می‌شود. |
| schema مشاهده‌شده | `create_time -> created_at` و `event_time -> at` با حفظ raw؛ تشخیص بر اساس header. |
| فرمول | ۵۵ تعریف موجود تغییر نمی‌کند؛ عدد LLM یا نمونهٔ بریف جای SQL نیست. |
| نبود داده | `null` و data issue؛ منبع غایب نباید کل گزارش صبح را متوقف کند. |
| تصمیم اجرایی | مدیر تصمیم می‌گیرد؛ سیستم فقط draft وظیفه/پیام و پیگیری می‌سازد. |

انتخاب روش فنی اجرای این موارد هنوز باید review شود. ولی وجود قاعدهٔ اصلی نباید دوباره به یک پرسش کسب‌وکار تبدیل شود.

<a id="decisions-3"></a>

## 3. Architecture decision records

<a id="adr-01"></a>

### ADR-01: PostgreSQL execution and canonical KPI equivalence

**Accepted:** PostgreSQL is the only product database engine. It executes all 55 KPIs and all custom queries. S16 Q03 states that this choice is final. S17 states the same boundary. Approver names and the original approval date are not supplied. Record this review date separately.

**Requirement:** preserve S03-S04 definitions and results. Do not modify the original SQL or source data. A PostgreSQL choice does not authorize numerical differences.

**Proposed:** register versioned PostgreSQL translations separately from canonical SQL. Exact PostgreSQL expressions remain a design choice; they cannot change the canonical result. Use an isolated SQLite reference harness only for tests. Compare the same frozen inputs and policy. The previous PostgreSQL-plus-SQLite product proposal is superseded. Do not reopen the database choice as an implementation default.

**Open:** exact translation strategy, reference type profile, engine version, median implementation, and proof for every output relation. Cover NULL/no-row, integer division, time arithmetic, rounding, joins, dimensions, and all replay mornings. Direct rewriting with accepted numeric drift is incompatible with the zero-wrong-number requirement.

**Gate:** AT-02, AT-03, AT-05, AT-17. No PostgreSQL parity or benchmark result is claimed. Engineering owns translation. The project owner confirms any missing reference type or input policy contract.

<a id="adr-02"></a>

### ADR-02: ورودی پذیرفته‌شدهٔ orders

**Status:** Open: accepted RAW/DEDUP input policy. Proposed: two versioned comparison modes. Requirement: preserve sources and canonical definitions.

**مسئله:** drop 076 دارای ۶۹۹ ردیف خام و ۴۳۷ payload متمایز است. RAW/DEDUP در S09 هشت KPI را عوض می‌کند. اختلاف B2C خالص در تشخیص خام، ۳۳۲٬۰۶۰٬۰۰۰ تومان است؛ با gross برابر نیست.

**پیشنهاد معماری:** هر دو input policy با نسخه، lineage و result namespace جدا پشتیبانی شوند. هیچ policy نهایی پیش‌فرض فرض نشود. حذف براساس order_id، به‌ویژه روی event، ممنوع است.

**تصمیم پذیرش لازم:** آیا رابطهٔ `orders` باید RAW باشد یا exact payload repeats را حذف کند؟ یک expected result رسمی نیز می‌تواند این ابهام را حل کند.

**مالک پاسخ:** پشتیبان پروژه/برگزارکننده؛ تیم سپس پیاده‌سازی policy را تصویب می‌کند. این پرسش در S08-S09 باز مانده است. تا پاسخ، مقایسهٔ هر دو mode مجاز است، ولی نتیجهٔ نهایی accepted اعلام نمی‌شود.

<a id="adr-03"></a>

### ADR-03: dependency و selective recalculation

**Status:** Proposed: staged recalculation. Open: optimization scope and approval. Requirement: preserve cutoff and canonical results.

**مسئله:** field، event selector، join، gate و window دامنهٔ اثر را تعیین می‌کنند. تساوی خروجی یا وابستگی سطح جدول برای تعیین حداقل اثر کافی نیست.

**پیشنهاد:** ابتدا full rebuild بر snapshot، سپس recompute در سطح KPIهای متأثر و بعد در صورت نیاز کلیدهای دقیق. DependencySpec شامل value dependencies و execution dependencies جدا باشد. اطلاعات ناکافی، fallback به recomputation گسترده‌تر می‌دهد.

**شرط تصویب:** selective و full rebuild برای همهٔ fixtureهای late/correction/repeated event برابر باشند؛ تغییر contributor بدون تغییر مقدار نیز invalidate شود. برای منبع غایب با تاریخ‌های نامعلوم، ادعای دامنهٔ دقیق ممنوع است.

**مالک تصمیم:** مهندسی داده و مسئول آزمون. انتخاب الگوریتم وابستگی، مجوز انتشار مقدار ناقص نیست.

<a id="adr-04"></a>

### ADR-04: کامل‌بودن منبع و انتشار مقدار ناقص

**Status:** Requirement: continue reporting and disclose unavailable data. Open: closure, release policy, and dated historical context mapping.

**مسئله:** manifest درست و backfill مشاهده‌شده، closure را ثابت نمی‌کنند. دادهٔ فعلی کران تأخیر یا expected total مستقل ندارد. S10 هیچ مقدار عددی نگه‌داشته‌شده‌ای را به‌عنوان «قطعاً بی‌دلیل withheld» اثبات نکرده است.

**پیشنهاد اولیه:** مقدار reference داخلی حفظ شود. خروجی مستقل منتشر شود. خروجی وابسته به incident حل‌نشده تا تعیین سیاست، `null` و issue داشته باشد. نبود SQL row از missing value جدا بماند. عدم closure کلی، برچسب `not_asserted` است؛ لزوماً تمام نتایج عادی بدون incident را مسدود نمی‌کند.

**گزینه‌ها:** hold برای unresolved incident؛ انتشار delivered-snapshot با برچسب صریح؛ یا release مبتنی بر closure معتبر. data model هر سه را پشتیبانی می‌کند.

**دو پاسخ لازم:** چه سند یا قرارداد، source interval را کامل می‌داند؟ آیا نمایش مقدار دقیق snapshot ناقص با برچسب روشن برای ارزیابی پذیرفته است؟

**مالک پاسخ:** برگزارکننده/مالک منبع. **مالک طراحی:** تیم داده و محصول. threshold تأخیر دلخواه، پاسخ این پرسش نیست.

**Q06 result and current-value boundary:** S16 summary records a dated last-valid-value display. S17 Report Writer preserves it. Keep that existing display behavior. Its release conditions are Open. A prior value must not replace a current missing value. Current output remains `null` with a data issue. Display historical context only with its actual KPI date, query, snapshot, unit, and current permission. Maximum age and output mapping need a decision. This does not close the choice of hold, qualified release, or closure-backed release. See DL-02 and DL-03.

<a id="adr-05"></a>

### ADR-05: restatement و نسخهٔ گزارش

**Status:** Proposed: report restatement mechanism. Open: notification and approval. Preserve the existing immutable report-version design.

**پیشنهاد:** گزارش منتشرشده immutable بماند. محاسبهٔ جدید روی تاریخ قدیمی نسخهٔ `restated` با cutoff جدید ایجاد کند. `as_reported`، `restated` و `counterfactual` در API، storage و UI جدا باشند.

**تصمیم باز:** چه تغییرهایی به مدیر اعلام شوند؟ چه کسی انتشار مجدد را تأیید کند؟ آیا نسخهٔ اولیه در URL ثابت اول نمایش داده شود یا آخرین نسخه با هشدار و پیوند به اولیه؟

**محدودیت ثابت:** گزارش صبح گذشته نباید از آینده داده بگیرد. آمار تاریخی و نسخهٔ گزارش می‌توانند متفاوت باشند ولی برچسبشان باید روشن باشد. اصلاح سابقه، تصمیم انسانی گذشته را خودکار لغو نمی‌کند.

**مالک تصمیم:** تیم محصول و معماری. پیشنهاد اولیه، نسخهٔ اولیه به‌عنوان گزارش واقعی و دسترسی صریح به نسخهٔ اصلاح‌شده است.

<a id="adr-06"></a>

### ADR-06: اجرای دسترسی مصوب و امنیت query

**Status:** Requirement: supplied hierarchy and individual-data restrictions. Proposed: policy catalog and physical controls. Open: resource/column/purpose mapping.

**وضعیت اصلاح‌شده، ۲۰۲۶-۱۱-۰۳:** اصل دامنهٔ دسترسی، الزام موجود است و تصمیم باز نیست. بریف ص۱۰ دسترسی را به زیرمجموعهٔ مدیر محدود می‌کند و دادهٔ فردی را فقط برای سرپرست مستقیم مجاز می‌داند. ص۱۳ کنترل ردیفی در لایهٔ داده را برای همهٔ queryها، از جمله گفتگو، الزامی می‌کند. دادهٔ فردی فقط برای مدیریت بار کار است؛ ارزیابی و رتبه‌بندی افراد مجاز نیست. طبق ص۶، ص۱۲ و ص۱۳، مرخصی فقط به شکل ظرفیت تجمیعی تیم وارد تحلیل می‌شود. `dataset/org/access_matrix.csv` دامنهٔ دقیق مدیران را ثبت کرده است:

| مدیر | دامنهٔ دادهٔ تجمیعی مجاز | دادهٔ فردی مجاز برای مدیریت بار کار |
|---|---|---|
| M01، مدیر ارشد | سازمان، هر سه واحد و تمام تیم‌های ماتریس | ندارد |
| M02، مدیر کل فروش | U_SAL، T_ENT، T_DIG، T_MKT | ندارد |
| M03، مدیر کل عملیات | U_OPS، T_WH، T_SHP | ندارد |
| M04، مدیر کل پشتیبانی | U_SUP، T_RSP، T_CMP | ندارد |
| M05، سرپرست فروش سازمانی | T_ENT | فقط T_ENT |
| M06، سرپرست بازاریابی دیجیتال | T_DIG | فقط T_DIG |
| M07، سرپرست انبار | T_WH | فقط T_WH |
| M08، سرپرست ارسال | T_SHP | فقط T_SHP |
| M09، سرپرست پاسخ‌گویی | T_RSP | فقط T_RSP |
| M10، سرپرست شکایات و مرجوعی | T_CMP | فقط T_CMP |
| M11، سرپرست مارکت‌پلیس | T_MKT | فقط T_MKT |

این جدول grant تازه نیست؛ بازنویسی ماتریس منبع است. زمان فعال‌شدن مدیر و تیم باید اعمال شود؛ اختلاف صبح شروع M11 در ADR-08 جدا باقی است. مجوز فردی، مجوز نمایش وضعیت مرخصی اشخاص نیست. بریف و ماتریس، فهرست مجاز تک‌تک ستون‌های خام را عرضه نکرده‌اند؛ نگاشت جدول/ستون و predicate باید همین قواعد موجود را اجرا کند.

**مسئله:** access_matrix دامنهٔ entityها را تعیین می‌کند؛ تمام جدول‌ها team_id ندارند. مشترک‌بودن orders میان فروش و عملیات مجوز کل اطلاعات فروش نمی‌سازد.

**پیشنهاد:** policy catalog برای resource، column، purpose و predicate ایجاد شود. scoped views در PostgreSQL پیش از LLM اعمال شوند. نقش کاربر، مالک جدول و دارای BYPASSRLS نباشد. Query Gateway یک SELECT/CTE خواندنی معتبر با function/table allowlist اجرا کند.

**جزئیات اجرای باز:** نگاشت دامنهٔ مصوب به ردیف‌ها و ستون‌های منابع مشترک؛ دامنهٔ دادهٔ گذشته برای تیم جدید؛ حذف دادهٔ نامجاز از evidence ارجاع بین‌واحدی؛ روش تجمیع ظرفیت و جلوگیری از بازشناسی افراد در تیم کوچک. این موارد، مجوز بازتعریف سلسله‌مراتب یا گسترش دسترسی نیستند. default برای مجوز تعریف‌نشده deny است.

**شرط تصویب:** آزمون منفی روی join، subquery، UNION، CTE، خطا، export، log، cache و تغییر role. تغییر principal از پارامتر یا prompt نباید scope را عوض کند.

**مالک تصمیم:** تیم امنیت/معماری؛ ابهام معنای مجاز manager question Q08 در صورت لزوم با برگزارکننده حل شود. وجود KPI `K_ORG_ORDERS` به M03 مجوز سازمان نمی‌دهد. query عملیاتی مجاز باید تعریف و policy مستقل داشته باشد.

<a id="adr-07"></a>

### ADR-07: جزئیات مرزی signal و escalation

**Status:** Requirement: R1-R8. Open: edge cases. Proposed: named candidate interpretations only.

قواعد اصلی R1-R8 از config الزام‌اند. موارد زیر در منبع به اندازهٔ کافی دقیق نیستند و نباید پنهانی انتخاب شوند:

| موضوع باز | پیشنهاد قابل آزمون، نه قاعدهٔ مصوب |
|---|---|
| تساوی با warn/crit | مقایسهٔ strict بر اساس عبارت عبور؛ تست equality جدا؛ تأیید برگزارکننده پیش از ارزیابی نهایی. |
| baseline دوطرفه یا نامطلوب | جهت نامطلوب از `direction` برای هشدار؛ رشد/افت مطلوب در نمایش؛ R5 می‌تواند تفسیر دوطرفه داشته باشد و باید روشن شود. |
| چهار هفته با missing/holiday | فقط نقاط مجاز؛ baseline ناقص با reason؛ حداقل نمونه و حذف تعطیلی گذشته صریح در config. |
| مخرج صفر در تغییر ۱۰٪/۲۰٪ | وضعیت undefined و rule تصمیم جدا؛ تقسیم بر epsilon یا عدد بی‌نهایت ممنوع. |
| روزهای پیوستهٔ هشدار با دادهٔ غایب | روز نامعلوم نه سالم و نه هشدار قطعی؛ پیشنهاد توقف شمارش تا تعیین وضعیت، بدون پاک‌کردن سابقه. |
| reset episode | recovery با معیار مصوب و ثبت علت؛ تغییر rule version به‌تنهایی سیگنال جدید نسازد. |
| ادامهٔ تشدید چند سطح | تقویم هر recipient و reason مستقل؛ مهلت سطح بعد اگر در config نیست نیازمند سیاست صریح است. |
| تجمیع هم‌علت | گروه‌بندی فقط با evidence؛ causal guess مدل نباید چند مالک مستقل را حذف کند. |

مدت R2 «بیش از» `escalate_after_days` است؛ `>=` جایگزین بی‌توضیح آن نشود. مالک، scope و سابقه از داده تعیین می‌شوند. وزن‌های رتبه‌بندی و آستانهٔ sample کم پارامتر طراحی هستند.

**مالک تصمیم:** تیم محصول/تحلیل؛ برای موارد اثرگذار بر امتیاز، تأیید برگزارکننده. تا آن زمان تست‌ها هر تفسیر را نام‌گذاری می‌کنند، نه اینکه یکی را قانون قطعی بنامند.

<a id="adr-08"></a>

### ADR-08: تقویم مدیریت و تقدم ورودی‌ها

**Status:** Requirement: cutoff and manager-input timing. Open: source precedence, M11 start, attachment readiness, and calendar known-at.

**اختلاف مستند:** بریف از ۱۰ گزارش روزانه می‌گوید. S05 مدیر M11 و تیم T_MKT را از روز ۷۵ فعال می‌کند. S07 تغییر سازمان را روز ۷۵ می‌فرستد، در حالی که S02 اثر ورودی را صبح بعد قرار می‌دهد.

**پیشنهاد:** roster با valid time و known time ساخته شود. `report_population_policy` تقدم static effective date یا فرمان runtime را مشخص کند. M01 تا M10 در هر ۳۰ صبح پوشش داده شوند؛ مدیر فعال اضافه حذف نشود.

با فعال‌شدن M11 از صبح ۷۶، خروجی ۳۰ روز شامل ۳۱۶ brief است. با تقدم مستقیم effective day و شروع صبح ۷۵، ۳۱۷ brief می‌شود. این دو تعداد، محاسبهٔ دو policy هستند؛ تعداد accepted هنوز تأیید نشده است. ۳۰۰ گزارش ثابت نباید بدون توجه به تغییر سازمان هدف کد شود.

**ورودی هم‌روز:** S07 پرسش manager Q09 را پیش از upload IN07 روز ۸۰ نوشته است. محتوای پرسش به پیوست اشاره دارد، ولی زمان دقیق دریافت آن در روز مشخص نیست. پیشنهاد، ثبت dependency صریح attachment و زمان دریافت است. اگر فایل هنوز مجاز/دریافت‌شده نیست، پاسخ clarification/data_unavailable بدهد؛ صرف وجود آن در filesystem مجوز خواندن زودهنگام نیست.

**سایر زمینه‌ها:** calendar رویدادها known_at ندارد. نمایش رخداد آینده به‌عنوان علت جاری ممنوع باشد. استفاده از برنامهٔ کمپین آینده نیازمند visibility policy جداست.

**مالک پاسخ:** برگزارکننده برای زمان‌بندی ارزیابی؛ تیم معماری برای event ordering و registry.

<a id="adr-09"></a>

### ADR-09: Output status, rounding, and registered numbers

**Requirement:** S01 p.16 uses the KPI dictionary for rounding. S02 defines the correct value as the reference SQL result. Generic one-decimal examples do not replace individual KPI precision. Preserve canonical precision. Tolerance after reference rounding is zero. No uniform extra rounding is permitted.

**Requirement:** S01 pp.9 and 13 permit registered ad hoc queries. A new breakdown or supported estimate is not prohibited because it is outside the original 55 definitions. Register the executed SQL, result, definition, snapshot, scope, and query_id. The LLM cannot invent its value.

**Open conflict:** S01 p.15 specifies `new/escalated/suppressed`. S06 permits `new/escalated/ongoing`. Preserve suppression history. The proposed mapping to internal history and `open_items` is not approved. Do not emit an invalid enum or silently change `suppressed` to `ongoing`. The organizer must confirm the wire mapping. The supplied schema is unchanged.

**Open:** machine-readable mapping of added query results or estimates when the evaluator requires a KPI reference. The schema makes query_id optional, but the brief requires traceability for every number. Proposed validation makes it mandatory for published numbers. Keep unsupported numbers out of the report until a valid mapping exists.

**Requirement:** one shared Insight Brief is the source for role reports (S01 pp.9-10). **Open:** the internal schema and authorized projection contract. It is distinct from `brief_schema.json`. A shared analysis never grants another manager its restricted evidence.

**Gates:** AT-02, AT-10, AT-11, AT-23. Organizer owns output-contract resolution. Product and data teams own internal representation.

<a id="adr-10"></a>

### ADR-10: بودجه، مدل و محدودیت اجرا

**Status:** Requirement: whole-day cost/time limits. Proposed: provider-neutral gateway, ledger, and budget shares. Open: model, products, and exact limits.

**الزام فعلی:** حداکثر ۵ دلار LLM در هر روز شامل تمام گزارش‌ها، تحلیل‌ها، گفتگو و retry. حداکثر ۱۵ دقیقه اجرای یک روز روی ماشین مرجع؛ ساعت شبیه‌سازی گزارش پیش از ۰۷:۳۰.

**پیشنهاد:** ledger رزرو هزینه پیش از call، سقف token و tool-call، cache با scope و سهم ذخیره برای QA. یک مدل کم‌هزینه برای کار معمول و مدل قوی‌تر فقط در صورت نیاز و بودجه؛ مدل و قیمت در این سند انتخاب نشده‌اند.

**پیشنهاد بودجهٔ اولیه برای آزمون، نه حد پذیرش جدید:** ۳٫۵ دلار تحلیل/گزارش، ۱ دلار QA و ۰٫۵ دلار reserve؛ این ارقام تضمین هزینه نیستند. انتقال سهم تنها در همان سقف ۵ دلار و با reservation اتمی مجاز باشد. embedding یا خدمت مدل اضافی نیز در ledger بیاید.

**شرط تصویب:** روز پرترافیک با retry و سؤال مدیر از سقف نگذرد. fallback قطعی، گزارش قابل استفاده تولید کند و کیفیت افت‌کرده ثبت شود. هزینهٔ زیرساخت جدا گزارش شود؛ با سقف LLM اشتباه نشود.

**مالک تصمیم:** تیم مهندسی/محصول؛ ماشین مرجع، نرخ‌ها و نسخهٔ حدود نهایی از برگزارکننده دریافت شود.

<a id="adr-11"></a>

### ADR-11: correction conflict و چرخهٔ موجودیت

**Status:** Proposed: conflict state and quarantine. Open: source precedence. No team-approved conflict-resolution algorithm is recorded.

**پیشنهاد:** conflicting same-drop correction و payload متفاوت با business_id یکسان، state مستقل داشته باشد. reference view روی دادهٔ مبهم به‌صورت خروجی قطعاً معتبر منتشر نشود. رویدادهای تکرارشونده یا reopening حفظ شوند.

**محدودیت:** SQL موجود برای بعضی انتخاب‌ها ترتیب کامل ندارد. اضافه‌کردن last-row-wins، latest timestamp یا بزرگ‌ترین value قاعدهٔ کسب‌وکار تازه است. در دادهٔ فعلی correction tie مشاهده نشده است؛ این مورد ریسک دادهٔ پنهان است، نه خطای اثبات‌شدهٔ فعلی.

**مالک تصمیم:** تیم داده برای تشخیص و quarantine؛ مالک قرارداد برای precedence در صورت مشاهدهٔ واقعی یا الزام آزمون.

<a id="adr-12"></a>

### ADR-12: نگهداری، backup و audit

**Status:** Proposed: backup and retention mechanism. Open: intervals, audit access, and restore policy.

**پیشنهاد:** برای ارزیابی، raw، config، query و همهٔ report versionهای لازم برای replay حفظ شوند. backup سازگار archive/DB و restore test لازم است. log حاوی دادهٔ فردی در خروجی عمومی benchmark قرار نگیرد.

**تصمیم باز:** دورهٔ retention پس از ارزیابی، محدودیت حجم، مدت backup و نقش مشاهدهٔ audit. حذف تاریخچه برای کاهش هزینه پیش از تعیین این موارد انجام نشود.

**مالک تصمیم:** تیم معماری و مسئول عملیات. این طراحی به نگهداری نامحدود همهٔ فایل‌های cache نیاز ندارد؛ cache مشتق قابل بازسازی است.

<a id="adr-13"></a>

### ADR-13: One bounded AI Agent

**Accepted:** use one bounded AI Agent with deterministic modules. Evidence: S16 Q01 result table explicitly states a team decision. S17 identifies one Agent. The source does not supply an approver name or original approval date.

The Agent can investigate authorized evidence and draft analysis, answers, and report language. KPI calculation, signals, workflow projections, permission checks, and final validation remain deterministic. Writer and Validator modules do not imply extra autonomous Agents. A multi-agent topology is not an approved alternative.

**Open:** tool-call, token, time, cancellation, and investigation-round limits. **Gate:** AT-20 and ADR-10. Engineering owns the execution controller.

<a id="adr-14"></a>

### ADR-14: Independent report publication

**Accepted:** publish each valid manager report independently. Record failed reports and partially failed day status. Evidence: S16 Q16 result table explicitly states a team decision; S17 Publication and Schedule contracts agree. Approver name and original approval date are not supplied.

**Proposed publication mechanism:** commit JSON and Persian text atomically for one manager package. A failure for manager B must not withdraw a valid package for manager A. Record errors even if a draft was never created. A day passes coverage only when every required active manager has a valid package. Independent publication does not weaken AT-15.

**Proposed:** bounded retries and a deterministic template fallback with valid query-backed numbers. **Open:** timeout, retry limits, fallback content, failure/status export contract, and replacement-version rules. A fallback must pass scope, schema, number, and evidence checks. A failed report cannot be called successful because an error file exists.

**Gates:** AT-11, AT-15, AT-18, AT-21. Product and engineering own failure policy.

<a id="adr-15"></a>

### ADR-15: Workflow stage ownership

**Requirement:** reconstruct WF1-WF3 from actual logs. S11 assigns end-to-end owner M01 to all three workflows. Stage SLA values and KPI formulas remain their separate supplied contracts.

**Open:** stage-to-team mapping and routing of a stage delay. An end-to-end owner is not proof of each stage owner. `order_events.actor_team` can identify a team or a unit. Staff/event links require valid dates and permissions. Do not create a team-only FK or infer an owner from workflow order.

**Proposed:** a versioned stage responsibility catalog. Options are an approved stage owner with escalation to M01, or explicit unresolved routing until that mapping exists. The latter preserves honesty but cannot satisfy stage-owner routing acceptance. Changing the canonical KPI owner is not an option without source authority.

**Gate:** AT-08 and AT-12, including an unmapped stage and a unit actor. Product/data owners must approve the mapping.

<a id="adr-16"></a>

### ADR-16: Runtime files and operational documents

**Requirement:** support nightly structured sources and manager inputs through API or an input folder. Uploads are required. The brief names Excel; current fixtures include CSV and Markdown. JSON also carries manifests, inputs, and output contracts.

**Proposed:** separate structured import from untrusted document registration. Preserve originals, receipt time, audience, schema/type checks, and lineage. Keep uploaded revisions separate from canonical drops. Do not ingest development documentation, audit outputs, notebooks, or hidden labels into product evidence.

**Open:** exact Excel formats and validation, additional PDF support, file limits, retrieval method, and same-day upload readiness. PostgreSQL text retrieval is a proposal. RAG and a vector database are not approved dependencies. A CSV/JSON/MD fixture scope alone does not settle required upload formats.

**Gate:** AT-03, AT-13, AT-22; same-day precedence remains ADR-08. Product and engineering own the format contract.

<a id="adr-17"></a>

### ADR-17: Human decision and action truth

**Requirement:** the system proposes; a human decides. After a valid decision it can create task/message drafts and track later evidence. It must not send, transfer staff, or execute organizational actions (S01 pp.11-12; S02).

**Proposed:** separate decision, draft, execution confirmation, and observed follow-up states. A decision record is not proof of execution. The fixed replay data already includes scripted decision effects; it does not change in response to a team action.

**Open:** whether MVP stores human execution confirmation, who can confirm it, and what evidence is needed. Options are decision/draft tracking only, or explicit human-confirmed execution tracking. The latter adds state and audit duties; it does not authorize an execution tool.

**Gate:** AT-14. Product owns lifecycle details.

<a id="decisions-4"></a>

## ۴. اولویت پاسخ‌های لازم

پرسش‌ها در این مرحله ثبت می‌شوند؛ این سند هیچ پیام یا درخواستی به شخص دیگری ارسال نمی‌کند.

| اولویت | پرسش | چه کاری به پاسخ وابسته است؟ |
|---|---|---|
| P0 | RAW یا exact payload DEDUP برای orders؟ | اعلام parity نهایی و مقدارهای حساس به input mode. |
| P0 | closure منبع چیست و مقدار qualified پذیرفته است؟ | انتشار خروجی‌های وابسته به incident حل‌نشده. |
| P0 اجرایی | نگاشت و آزمون دسترسی مصوب بریف و access_matrix روی ردیف/ستون منابع مشترک چگونه اجرا شود؟ اصل دامنه و محدودیت دادهٔ فردی مشخص است. | عرضهٔ Text-to-SQL و drill-down پس از اثبات کنترل دسترسی؛ فقط تعارض مشخص و حل‌نشده به برگزارکننده ارجاع شود. |
| P1 | شروع گزارش M11 و ترتیب upload/question هم‌روز؟ | coverage قطعی و QA مطابق clock. |
| P1 | Confirm suppressed/ongoing mapping and added-number wire mapping. Canonical rounding is already a Requirement. | Final JSON and text validation; ADR-09. |
| P1 | مرز threshold، baseline و escalation در حالت‌های مبهم؟ | آزمون‌های قطعی detection و recurrence. |

کارهای طراحی و پیاده‌سازی آینده که مستقل از این پاسخ‌ها هستند، مانند source archive، snapshot و حفظ raw، می‌توانند پس از تأیید معماری جلو بروند. پاسخ‌ندادن به P0 نباید با انتخاب پنهانی business rule جبران شود.

<a id="decisions-5"></a>

## ۵. ریسک‌های عمده و اقدام کنترل

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| نشت آینده از fact یا فایل preloadشده | گزارش تاریخی ظاهراً درست ولی غیرقابل قبول | cutoff قبل از projection؛ poison future data test؛ snapshot hash. |
| input grain نامشخص | عدد مرجع متفاوت با evaluator | دو policy جدا و پاسخ رسمی ADR-02. |
| اعتماد به manifest برای completeness | صفر جعلی یا رفع incident زودهنگام | expected source registry، closure جدا و آزمون missing/empty. |
| تغییر arithmetic در port | اختلاف حتی در صدم ساعت | Canonical SQLite test oracle, PostgreSQL translation version, and boundary parity. |
| دسترسی خام در query یا cache | نشت به مدیر دیگر یا LLM | RLS، scope در cache key، worker جدا و adversarial query suite. |
| اصلاح تاریخی به شکل سیگنال تجاری | هشدار و تشدید نادرست | `knowledge_revision` جدا و incident linkage. |
| hardcode حوادث توسعه | شکست روی دادهٔ پنهان | تغییر تاریخ، شناسه، dimension و ترتیب delivery در fixtureهای مصنوعی. |
| قاعدهٔ تکرار بدون recipient state | حذف هشدار مالک یا تکرار برای والد | state جدا برای episode و recipient؛ تست escalation chain. |
| نبود دو شاهد مستقل | علت ساختگی با confidence بالا | lineage groups و validator مستقل از LLM. |
| برداشت علّی از تصمیم شبیه‌سازی‌شده | نسبت‌دادن اثر بدون مدرک | before/after با کنترل تقویم و محدودیت؛ عدم تغییر دادهٔ replay پس از تصمیم. |
| رشد تعداد مدیران یا سؤالات | شکست زمان یا هزینه | template writer، reservation، cache مجاز و اندازه‌گیری بدترین روز. |
| پیچیدگی دو dialect | خطای مسیر query و هزینهٔ نگهداری | interface واحد، reference result authoritative و ثبت engine هر query. |
| وضعیت فعلی entity جایگزین reference شود | تغییر backlog/SLA بدون مجوز | projection عملیاتی جدا، formula hash ثابت. |

<a id="decisions-6"></a>

## ۶. مسیر مرحله‌ای پیاده‌سازی پس از review

زمان‌ها برآورد تقویمی قطعی نیستند. مراحل با خروجی قابل بررسی و شرط خروج تعریف شده‌اند. برنامهٔ نسبی سه‌هفته‌ای بریف را می‌توان پس از شناخت ظرفیت تیم بر این مراحل منطبق کرد.

| مرحله | کار لازم | خروجی قابل بررسی | شرط خروج |
|---|---|---|---|
| P0: review معماری | مرور سه سند، تعیین owner ADRها و ثبت EvaluationProfile | تصمیم‌های پذیرفته/ردشده و پرسش‌های پذیرش | scope و مرزهای امنیت و reference روشن باشد؛ implementation فقط بعد از این مرحله. |
| P1: ستون فقرات داده | archive، manifest checks، adapter، lineage، snapshot و org/config clock | replay قابل تکرار تا یک cutoff، با source status | retry بی‌اثر، sourceها محفوظ، no future leakage و missing source قابل مشاهده. |
| P2: یک روز کامل | همهٔ ۵۵ KPI، query registry، یک چرخهٔ signal/evidence/report، QA محدود و RLS | صبح ۶۲ برای ۱۰ مدیر پایه، JSON/text معتبر، cost/time log | عددها برابر reference، scope صحیح، atomic manager package; independent publication and day coverage؛ policyهای نامصوب صریح باشند. |
| P3: تاریخچه و Workflow | سه workflow، suppression/escalation، restatement و تصمیم‌ها | کنترل‌روم با case/stage evidence و history | late/correction/reopened tests و زمان‌بندی مدیر قبول شوند. |
| P4: replay و تعامل | صبح ۶۲ تا ۹۱، همهٔ ورودی‌های S07، org change و dashboard | briefs و ۱۶ QA با run manifest | coverage بر roster مصوب، schema و security suite موفق. |
| P5: پذیرش و بسته | robustness، hidden-like fixtures، benchmark، restore و بستهٔ اجرایی | دستور واحد Docker، راهنمای config، گزارش پذیرش/هزینه | بدون تغییر کد روی data root جدید اجرا شود؛ همهٔ gateهای لازم پاس شوند. |

در هر مرحله، CSVهای audit به برنامهٔ تولیدی تبدیل یا به‌عنوان lookup پاسخ استفاده نمی‌شوند. fixtureهای آن‌ها فقط oracle آزمون توسعه‌اند. مسیر runtime فقط source، config و ورودی مجاز مدیر را می‌خواند.

### ۶.۱. کمترین مسیر سرتاسری قابل بررسی

پیش از تکمیل P2، یک slice کوچک چنین ساخته شود:

۱. ورودی‌های تاریخی لازم تا drop 061 با manifest و lineage دریافت شوند؛ دیگر dropها برای job قابل دسترسی نباشند.

2. Calculate `K_RSP_FRT_MED` and `K_RSP_TICKETS` with approved PostgreSQL translations. If unit or organization FRT is displayed, use its own canonical ID and approved translation. Do not relabel the team KPI.

۳. یک rule قطعی، یک evidence query برای شکست دسته و یک گزارش فارسی M09 ساخته شود. اگر شواهد علت کافی نیست، علت اختراع نشود. خروجی با schema، مقدار و scope بررسی شود.

۴. یک پرسش مجاز M09 و یک درخواست نامجاز برای دادهٔ تیم دیگر اجرا شود. در آزمون، هیچ دادهٔ نامجاز حتی در ورودی LLM ظاهر نشود.

۵. اجرای همان job دوباره، receipt و نتیجهٔ یکسان بدهد. hash منابع تغییر نکند.

این slice، محصول کامل یا پذیرش ۱۰ گزارش نیست. **نخستین milestone قابل ارائه، پایان P2 است: یک روز کامل با ۵۵ تعریف و ۱۰ گزارش پایه.** سپس همین مسیر روی روز دارای منبع غایب اجرا شود. مقیاس‌دادن UI پیش از این شواهد ارزش کمتری دارد.

<a id="decisions-7"></a>

## ۷. راهبرد آزمون و پذیرش

آزمون‌ها لایه‌ای هستند: قرارداد منبع، محاسبه، تاریخچه، دسترسی، سیگنال، تولید و اجرای کامل. هر آزمون snapshot، input policy، engine/config version و نتیجهٔ قابل بررسی دارد. «نبود exception» یا «متن خوب» معیار صحت نیست.

| ID | آزمون | معیار پذیرش |
|---|---|---|
| <a id="at-01"></a>AT-01 | ingest و idempotency | manifest/actual/expected مستقل سنجیده شوند؛ retry هیچ occurrence یا report اضافی نسازد؛ source hash تغییر نکند. |
| <a id="at-02"></a>AT-02 | PostgreSQL equivalence | All 55 IDs; unchanged original SQL/view hashes plus translated SQL hashes; identical inputs and policy; equal keys, dimensions, row presence, NULL, and reference-rounded values for all replay mornings and boundaries. No tolerance after rounding. |
| <a id="at-03"></a>AT-03 | cutoff و replay | صبح ۶۲ تا ۹۱؛ drop≤R-1؛ سؤال D با drop≤D-1؛ future rows در storage ممکن ولی در گزارش ممنوع؛ initial CRM مجاز. |
| <a id="at-04"></a>AT-04 | missing/empty/backfill | absent source در گزارش؛ NULL با issue؛ empty با missing یکی نشود؛ ۳۲ تغییر support و دو تغییر payment جدا توضیح داده شوند. |
| <a id="at-05"></a>AT-05 | duplicate/schema/correction | RAW/DEDUP قابل تفکیک؛ schema aliases مبتنی بر header؛ اصلاح L02045 فقط از صبح۷۱؛ counterfactual وارد گزارش واقعی نشود. |
| <a id="at-06"></a>AT-06 | authorization | صفر نشت در سه سطح، در result، prompt، cache، export، logs و خطا؛ دادهٔ فردی فقط با direct-team و purpose مجاز. |
| <a id="at-07"></a>AT-07 | org/config change | تیم/سطح جدید از metadata و clock؛ بدون تغییر کد؛ آستانهٔ IN06 از گزارش۷۹؛ cache و grant با revision سازگار. |
| <a id="at-08"></a>AT-08 | recurrence/escalation | کمتر از۱۰٪ تغییر به همان مخاطب new نسازد؛ reason و history تشدید حاضر؛ owner و rule version درست؛ حداکثر پنج مورد. |
| <a id="at-09"></a>AT-09 | کشف رویداد | معیار رسمی: حضور در گزارش مالک، ظرف۲۴ ساعت، KPI/entity درست و علت سازگار با label مرجع؛ حداقل۹۰٪ روی پاسخ رسمی. |
| <a id="at-10"></a>AT-10 | grounding | هر عدد query و snapshot؛ هر علت منتشرشده حداقل دو evidence group؛ فرضیه از fact جدا؛ دادهٔ ناکافی به علت قطعی تبدیل نشود. |
| <a id="at-11"></a>AT-11 | خروجی و UI | brief و QA مطابق schema؛ فارسی RTL؛ maxItems=5؛ لینک عدد تا query مجاز؛ همهٔ کارکنان نام‌برده در mentioned_staff_ids و scope کنترل شوند. |
| <a id="at-12"></a>AT-12 | Three workflows | Valid case joins; supplied stage SLA and separate KPI SQL; repeated/open/unknown cases; M01 end-to-end ownership; approved stage mapping and routing; unknown owner and unit actors do not become guessed team owners. |
| <a id="at-13"></a>AT-13 | prompt injection | دستور داخل ticket/upload هیچ policy، query permission، عدد، مقصد یا action را تغییر ندهد. |
| <a id="at-14"></a>AT-14 | decision/action | بدون تصمیم معتبر، draft اجرایی ایجاد/منتسب نشود؛ هیچ ارسال یا جابه‌جایی خودکار؛ effect_direction یکی از enum و شواهد قبل/بعد موجود. |
| <a id="at-15"></a>AT-15 | Daily coverage | Exactly the approved active roster has a valid base brief each morning. Independent publication is allowed. Any missing or failed required package leaves the day incomplete. Retry does not add duplicate coverage. |
| <a id="at-16"></a>AT-16 | QA | تمام۱۶ پرسش فعلی با clock، scope، تعریف و refusal مناسب؛ دقت رسمی حداقل۸۵٪ روی مجموعهٔ ارزیاب، نه فقط نمونه‌های توسعه. |
| <a id="at-17"></a>AT-17 | عملکرد | هر روز شامل ingest تا JSON و validation، حداکثر۱۵ دقیقه روی ماشین اعلامی؛ گزارش پیش از۰۷:۳۰ simulated؛ warm/cold جدا ثبت شوند. |
| <a id="at-18"></a>AT-18 | هزینه | مجموع واقعی مدل در هر روز≤۵دلار؛ token، retry، cache hit، نرخ و reservation ثبت؛ exhaustion نتیجهٔ کنترل‌شده بدهد. |
| <a id="at-19"></a>AT-19 | تعمیم و تحویل | data root و تنظیم جدید بدون تغییر کد؛ یک دستور Docker؛ no hardcoded incident days/IDs؛ restart و restore موفق. |
| <a id="at-20"></a>AT-20 | One bounded Agent | One AI Agent serves analysis and writing. Deterministic modules handle calculation, signals, access, and validation. Enforce approved tool/token/time/cancellation limits. No extra autonomous Agent is introduced. |
| <a id="at-21"></a>AT-21 | Failure and publication | Fail one manager job before a draft and another during validation. Other valid packages publish once. Text/JSON for each package commit together. Failed required jobs remain visible and the day remains incomplete. Retry/fallback stays within time and cost limits. |
| <a id="at-22"></a>AT-22 | Upload boundary | Test the approved format list, identity, audience, receipt/readiness, parsing failure, and injection. Operational documents stay separate from developer documents and canonical drops. No unavailable attachment enters evidence. |
| <a id="at-23"></a>AT-23 | Dated historical context | Current missing value remains null with an issue. Last-valid context uses its actual date, query, snapshot, unit, and current permission. No stale-as-current substitution. Output mapping must be approved. |

The table combines source requirements and planned gates for Accepted decisions or Proposed mechanisms. Preserve the current brief limits with a version. Organizer confirmation is still needed under DL-16. Do not change a limit after a failed test without authority.

### ۷.۱. تفکیک oracle محاسبه، کیفیت و کشف

oracle محاسبه، SQL اصلی روی ورودی پذیرفته‌شده و cutoff مشخص است. audit CSVهای S09-S10 برای regression همان داده مفیدند؛ ستون‌های reportable ممیزی، policy تولیدی مصوب نیستند.

oracle کیفیت، وضعیت source و قرارداد closure است. عدد برابر با SQL، به معنی complete بودن منبع نیست. در آزمون، SQL value و publication state جدا مقایسه شوند.

oracle کشف، برچسب‌های پنهان برگزارکننده است. این برچسب‌ها در workspace نیستند. از نام incident یا تاریخ‌های شناخته‌شده برای ادعای دستیابی به ۹۰٪ استفاده نمی‌شود. با fixtureهای مصنوعی می‌توان سازوکار را آزمون کرد، ولی امتیاز رسمی فقط پس از ارزیابی رسمی معلوم است.

<a id="manager-question-map"></a>

### 7.2. Supplied manager questions

These are manager-input questions from S07, not the architecture review questions in S16. Their IDs are a separate namespace. This table specifies expected behavior, not stored numerical answers.

| پرسش | رفتار مورد انتظار |
|---|---|
| Q01 / M09 | تیکت روز قبل به تفکیک category در T_RSP؛ توضیح علت فقط با شاهد کافی و داده تا drop065. |
| Q02 / M04 | صبح/روز۶۷ با gap پشتیبانی؛ `data_unavailable` طبق سیاست hold، یا فقط خروجی qualified در صورت پذیرش رسمی؛ صفر جعلی ممنوع. |
| Q03 / M02 | روشن‌کردن دامنهٔ «درآمد» و هدف؛ KPI سازمان خارج از grant واحد را بدون اجازه نخواند. امکان clarification یا refusal؛ سؤال داشتن، grant نمی‌سازد. |
| Q04 / M01 | median روزانهٔ picking در هفت روز گذشته؛ از KPI/query مجاز؛ median هفت median جای آن نباشد. |
| Q05 / M11 | marketplace از آغاز فعالیت مجاز تا دیروز؛ roster، input policy و cutoff رعایت شوند. |
| Q06 / M11 | درآمد کل سازمان خارج از scope؛ `refused_out_of_scope`. |
| Q07 / M01 | «فروش» مبهم؛ تعریف و بازه روشن یا فرض مشخص با امکان تأیید؛ legacy definition جای خالص مرجع نیاید. |
| Q08 / M03 | درخواست تعداد سفارش؛ policy عملیاتی باید اجازه دهد. بدون resource grant، org KPI قابل استفاده نیست. پاسخ مورد انتظار نیازمند ADR-06 است. |
| Q09 / M02 | attachment فقط پس از دریافت مجاز؛ reconciliation واحد، بازه و تعریف؛ تعریف فایل بیرونی از دو عدد حدس زده نشود. |
| Q10 / M07 | کارهای باز اعضای مستقیم انبار برای مدیریت کار مجاز؛ بدون رتبه‌بندی عملکرد. |
| Q11 / M03 | بارکاری فردی تیم انبار برای مدیر واحد مجاز نیست؛ `refused_individual_data` و پیشنهاد تجمیع تیم. |
| Q12 / M05 | win-rate سی‌روزه به تفکیک lead source؛ query ثبت‌شدهٔ افزوده در scope T_ENT؛ فیلتر won/lost و window مرجع حفظ شود. |
| Q13 / M09 | پرونده‌های T_CMP خارج از تیم؛ `refused_out_of_scope`. |
| Q14 / M08 | on-time شهر مشهد در سه روز گذشته؛ query با snapshot تا drop089 و unit/precision صحیح. |
| Q15 / M01 | تصمیم‌های مجاز با اثر مشاهده‌شده و uncertainty؛ outcome متن قدیمی جای محاسبه را نگیرد. |
| Q16 / M06 | CPL هفت‌روزه به تفکیک source؛ جمع spend بر جمع lead، NULLIF و هزار تومان؛ نه میانگین CPLهای روزانه. |

Q03 نشان می‌دهد بررسی scope باید قبل از تولید پاسخ عددی باشد. مرجع محاسبهٔ target فعلی `scope='ORG'` است. تیم فروش نباید به بهانهٔ سؤال، هدف یا درآمد کامل سازمان را دریافت کند. راه‌حل نهایی به تأیید policy و معنای سؤال وابسته است.

### ۷.۳. آزمون‌های مرزی و خصمانه

- median: empty، all-NULL، odd/even، mixed NULL، عدد منفی، مقدار اعشاری و مرز rounding؛ چهار مورد زمان S08 تکرار شوند.
- گروه: no row در برابر NULL، صفر واقعی، denominator صفر، dimension جدید، initial CRM و آیندهٔ cal.
- تاریخچه: event بسیار دیررس، MIN قبلی، MAX بعدی، reopen، refund بعد از تحویل، فرزند قبل از والد و correction tie متعارض.
- وابستگی: تغییر category در دو گروه، جابه‌جایی timestamp، windowهای هفت/سی روز، MTD، ساعت۲۲ و contributor ثابت‌مقدار.
- امنیت: UNION و CTE به دادهٔ فردی، SQL چنددستوری، function اثرگذار، SET ROLE/set_config، ATTACH، فایل/extension، query پرهزینه و خطای افشاگر.
- isolation: cache یک مدیر برای مدیر دیگر استفاده نشود؛ request در pool context قبلی را نگیرد؛ لینک query گذشته به کاربر لغوشده داده نشود.
- injection: دستور مخفی upload روز۷۳ و متن تیکت، همچنین دستور در header/filename؛ هیچ دستور داده‌ای به control plane نرود.
- تعمیم: جابه‌جایی زمان حوادث، نام فایل‌های schema شناخته‌شده، IDs جدید و تعداد تیم بیشتر؛ هیچ شناسهٔ نمونه در منطق تولیدی لازم نباشد.

fixtureهای مصنوعی در محیط آزمون جدا ساخته می‌شوند. dataset اصلی یا auditها برای ساختن آزمون دستکاری نمی‌شوند.

<a id="decisions-8"></a>

## ۸. اندازه‌گیری عملکرد و هزینه

در هر روز، wall time مراحل ingest، snapshot، facts، KPI، signal، workflow، evidence، LLM و validation ثبت شود. زمان bootstrap روزهای۱ تا۶۰ جدا از زمان هر روز ارزیابی گزارش شود. برای روز کامل، تعداد مدیر واقعی، تعداد پرسش و cache state ثبت شوند.

برای هر model call، `day, purpose, model_version, input_tokens, output_tokens, cached_tokens, price_version, reserved_cost, actual_cost, retry_of` نگهداری شود. ledger روز با run receipt آشتی داده شود. نرخ ثابتِ بدون تاریخ یا تخمین LLM از هزینه پذیرفته نیست.

گزارش benchmark شامل همهٔ ۳۰ روز، بیشینه، میانه و توزیع زمان باشد. حد پذیرش هر روز کنترل می‌شود؛ میانگین خوب شکست یک روز را پنهان نمی‌کند. مصرف حافظه و حجم archive/snapshot نیز ثبت شود. هدف عددی برای این دو پس از baseline سخت‌افزار تعیین شود.

برای صحت، آمار زیر لازم است: تعداد تعریف و سری، SQL failure، numeric mismatch، no-row mismatch، scope refusal، نشت کشف‌شده، report coverage، schema failure، incident باز و suppressed/escalated count. این آمار نباید به quota مصنوعی تعداد سیگنال تبدیل شود.

<a id="decisions-9"></a>

## 9. Documentation delivery and verification

The three architecture documents are reconciled with the supplied review record. Document 004 contains the Q01-Q17 mapping, source checks, file changes, and verification limits. The Decision Log below retains unresolved choices. No product code, SQL port, KPI run, security test, performance test, or acceptance result is claimed.

This workspace has no Git repository. A saved pre-edit file baseline is used for the [unified diff](reconciliation.diff). This task does not commit or push.

<a id="decision-log"></a>

<a id="decisions-10"></a>

## 10. Decision Log

All rows below are `Open`. Options are review inputs, not accepted rules. Listed roles are proposed owners, not assigned people. Close a row only with a source or team decision record and the applicable gate evidence.

| ID / review | Conflict or missing choice | Options and architectural effects | Owner / gate |
|---|---|---|---|
| DL-01 / Q03 | PostgreSQL is Accepted; all 55 translations and input types are unproved. | Versioned translation preserves source SQL and needs a reference harness. Unchecked rewriting risks numeric drift and fails the requirement. Do not restore a second product engine. | Engineering; ADR-01; AT-02,03,05,17 |
| DL-02 / Q05 | RAW and exact-payload DEDUP change eight KPI definitions' results. | RAW preserves all accepted occurrences; DEDUP changes join populations. Preserve both comparison namespaces until the organizer supplies the calculation policy or expected result. Retry idempotency is separate. | Organizer/data owner; ADR-02; AT-02,05 |
| DL-03 / Q06 | Source closure and release policy are absent. Last-valid display does not validate current data. | Hold current dependent values as null; qualified snapshot release; or closure-backed release. Each needs explicit eligibility. Dated prior context can be shown only through an approved mapping. Never fill the current slot with old data. | Organizer/product; ADR-04; AT-04,23 |
| DL-04 / Q07 | Full rebuild versus selective calculation; restatement notice and approval. | Full rebuild is the proposed correctness baseline. Selective work requires equivalence and dependency proof. Both preserve prior report versions. | Data/product; ADR-03,05; AT-03,05 |
| DL-05 / Q08 | Payload conflicts and same-drop correction ties lack precedence. | Obtain a source precedence rule, or quarantine affected outputs with an issue. Last-row-wins invents a rule. No current correction tie is claimed. | Source/data owner; ADR-11; AT-05 |
| DL-06 / Q09 | Shared sources lack complete row/column/purpose projections. | Reviewed resource predicates and redaction, or deny undefined access. Table consumption does not grant source visibility. All choices must retain the supplied hierarchy. | Security/data; ADR-06; AT-06 |
| DL-07 / Q10 | Capacity formula, working hours, group size, and free-text redaction are unresolved. | Approved headcount metric or an hour-based metric with a work-calendar contract. Do not invent hours or expose individual leave. Small-group inference needs controls. | Product/security; ADR-06; AT-06,10 |
| DL-08 / Q11 | M01 owns each workflow; stage owners and delay routing are not defined. | Approved stage catalog with escalation, or unresolved routing. Do not infer owners or change canonical KPI ownership. | Product/data; ADR-15; AT-08,12 |
| DL-09 / Q12 | Threshold equality, sparse baseline, zero denominator, unknown days, and reset. | Explicit versioned rules with named edge cases. Strict crossing is Proposed. Unknown data cannot become normal. | Product/organizer; ADR-07; AT-08,09 |
| DL-10 / Q13 | Static day-75 start conflicts with next-morning input effect. Upload receipt and calendar known-at are missing. | M11 morning 75 gives 317 briefs; morning 76 gives 316. Neither is selected. Record attachment receipt/readiness; defer an unavailable manager Q09 attachment. Planned events are not observed causes. | Organizer/architecture; ADR-08,16; AT-03,07,15,22 |
| DL-11 / Q14 | suppressed in brief versus ongoing in schema; internal Insight schema and added-number mapping. | Confirm an internal ledger/open_items mapping or obtain a revised official wire contract. Neither is approved. Shared analysis still needs role-specific evidence controls. | Organizer/product; ADR-09; AT-10,11 |
| DL-12 / Q15 | Decision approval is not execution evidence. Actual execution tracking scope is undecided. | Decision/draft tracking only, or human-confirmed execution states with evidence. Neither enables automatic action. | Product; ADR-17; AT-14 |
| DL-13 / Q16 | Independent publication is Accepted; failure export, retry, timeout, and fallback are not specified. | Bounded retry then explicit failure, or a validated template fallback. Failure before draft must be recorded. Partial coverage never passes the day. | Product/engineering; ADR-14; AT-15,21 |
| DL-14 / Q01,Q17 | Agent bounds, model, provider, gateway, tracing, and budget shares are not selected. | Use a provider-neutral interface with measured limits. A gateway product is a candidate only. Benchmark the whole day including QA and retry within USD 5 and 15 minutes. | Engineering/product; ADR-10,13; AT-17,18,20 |
| DL-15 / cross-cutting | Retention, backup interval, audit viewers, and restore procedure. | Retain all replay evidence for evaluation. Later retention needs an approved policy and reproducible restore. Derived cache can be rebuilt. | Operations/architecture; ADR-12; AT-06,19 |
| DL-16 / acceptance | Final organizer profile, reference hardware, hidden labels, and complete raw dictionary are unavailable. | Preserve current brief limits. Record organizer confirmation before final acceptance. Do not claim hidden-event detection, QA accuracy, or performance from documentation checks. | Organizer; AT-02,09,16,17,18,19 |

Implementation remains outside this task. Before product implementation starts, close the team-controlled P0 design choices or explicitly approve named temporary policies. External acceptance questions can remain tracked during authorized scaffolding, but no affected result can be called accepted. The Accepted Agent, engine, and publication decisions need no new selection meeting.
