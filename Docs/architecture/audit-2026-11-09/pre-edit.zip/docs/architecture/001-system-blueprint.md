# ARCH-001: طرح معماری سیستم ARKA

Review date: 2026-11-09. Time zone: `Asia/Tehran`.

Status: requirements, accepted team decisions, proposed details, and open issues. No product implementation or acceptance result is claimed. See the [Q01-Q17 review](004-reconciliation-review.md) and the [Decision Log](003-decisions-and-roadmap.md#decision-log).

<a id="system-1"></a>

## 1. Accepted architecture and proposed details

ARKA uses one bounded AI Agent and deterministic modules. PostgreSQL is the only product database engine. These are `Accepted` team decisions in S16 Q01/Q03. S17 states the same target. See [ADR-13](003-decisions-and-roadmap.md#adr-13) and [ADR-01](003-decisions-and-roadmap.md#adr-01).

The modular application has an API, a Persian RTL interface, and a background worker in one codebase. Keep original files in protected file storage with SHA-256 hashes. File storage is not a second database. Queue and run state can use PostgreSQL. Framework and physical deployment details remain Proposed.

`ReferenceCalculator` executes PostgreSQL-compatible SQL for the 55 canonical KPI definitions. Preserve the original SQLite SQL and views as requirement evidence. Keep translated SQL and its version separate. All 55 definitions need numerical equivalence checks before acceptance. SQLite can serve as an isolated test oracle. It is not a product calculator or interactive query engine. The former dual-engine proposal is superseded by the recorded team decision. No equivalence result is claimed.

The Agent uses authorized evidence for analysis and writing. Calculation, signal detection, authorization, and output checks are deterministic. The Agent has no database credentials or organizational action tools. The same Agent can support analysis and role-specific writing. Separate Writer and Validator modules do not create extra AI Agents.

Each valid manager report is published independently. Record each outcome and the day status. A day with a required report failure is incomplete. Template fallback, retry count, and timeout remain Proposed. See [ADR-14](003-decisions-and-roadmap.md#adr-14).

Python for API/worker and TypeScript for the interface remain proposals. Docker delivery with one command is a Requirement. Model, provider, framework, and gateway product are not selected.

<a id="system-2"></a>

## ۲. منابع و درجهٔ اعتبار

Use these four decision statuses:

| Status | Meaning | Evidence needed |
|---|---|---|
| `Requirement` | An explicit brief or dataset contract rule. | Source, page or field, and applicable version. |
| `Accepted` | A recorded team decision. | Decision statement and source location. Record an approver and date when supplied. |
| `Proposed` | A design option with no approval evidence. | Proposal, options, and review owner. |
| `Open` | An unresolved rule, conflict, or choice. | Sources, effects, owner, and closure evidence. |

An observation is an evidence type, not a fifth status. A Codex recommendation is not team approval. S16 records decisions; it does not replace S01-S07 requirements. S17 confirms the existing target model. Its design details do not prove approval or implementation. Keep unresolved source conflicts in the [Decision Log](003-decisions-and-roadmap.md#decision-log).

### ۲.۱. فهرست منابع بررسی‌شده

مسیرهای جدول نسبت به این سند هستند. شناسهٔ منبع در دو سند دیگر نیز همین معنا را دارد.

| شناسه | منبع | نتیجهٔ بررسی و کاربرد |
|---|---|---|
| S01 | [بریف اصلی DIDRAH](../../Project_berif/بریف%20پروژه%20بوتکمپ%20_%20دستیار%20ایجنتیک%20مدیران%20سازمانی%20_%20دیدراه.pdf) | Current PDF: 19 pages read on 2026-11-09. Pages 13 and 16 also checked as images. Product and acceptance requirements. |
| S02 | [README_FA.md](../../dataset/README_FA.md) | زمان دسترسی، ساختار drop، قرارداد محاسبه و ورودی مدیر را مشخص می‌کند. |
| S03 | [kpi_dictionary.csv](../../dataset/config/kpi_dictionary.csv) | ۵۵ تعریف؛ شناسه، مالک، واحد، SQL، ابعاد و آستانه‌ها. |
| S04 | [reference_views.sql](../../dataset/config/reference_views.sql) | پنج view مرجع: `order_fact`، `ticket_fact`، `lead_fact`، `task_fact` و `revenue_daily`. |
| S05 | [org](../../dataset/org/) و [access_matrix.csv](../../dataset/org/access_matrix.csv) | واحدها، تیم‌ها، مدیران، کارکنان، تاریخ شروع و محدودیت دادهٔ فردی. |
| S06 | [brief_schema.json](../../dataset/output_contract/brief_schema.json)، [qa_answer_schema.json](../../dataset/output_contract/qa_answer_schema.json)، [example_brief.json](../../dataset/output_contract/example_brief.json) | قالب واقعی خروجی؛ مثال، مرجع مقدار یا تاریخ صحیح نیست. |
| S07 | [scripted_inputs.json](../../dataset/manager_inputs/scripted_inputs.json) و [uploads](../../dataset/uploads/) | ۲۳ ورودی شامل ۱۶ پرسش؛ تغییر اولویت، آستانه، سازمان، تصمیم و فایل. ترتیب آرایه کاملاً زمانی نیست. |
| S08 | [RCA-001](../../review/rca-001-report.md) و [شواهد آن](../../review/rca-001-evidence.json) | تقویم، `drop_day`، median، تکرار سفارش و تغییر schema. |
| S09 | [KPI-VAL-001](../../review/kpi-val-001-report.md)، [شواهد](../../review/kpi-val-001-evidence.json)، [مقایسهٔ CSV](../../review/kpi-val-001-results.csv) | مقایسهٔ RAW و DEDUP برای همهٔ تعریف‌ها و ۳۰ صبح. CSV دارای ۱۷۶٬۰۰۲ ردیف است. |
| S10 | [DQ-001](../../review/dq-001-report.md)، [شواهد](../../review/dq-001-evidence.json)، [اثر KPI در CSV](../../review/dq-001-kpi-impact.csv) | تفکیک اثر دیررسیدن، وضعیت نامعلوم و نبود ردیف SQL؛ CSV دارای ۲۳٬۰۳۹ ردیف است. |
| S11 | [escalation_rules.csv](../../dataset/config/escalation_rules.csv)، [workflow_definitions.csv](../../dataset/config/workflow_definitions.csv)، [monthly_targets.csv](../../dataset/config/monthly_targets.csv) | هشت قاعده، سه Workflow با ۱۲ مرحله و سه هدف ماهانه. |
| S12 | [calendar_days.csv](../../dataset/calendar/calendar_days.csv)، [events_calendar.csv](../../dataset/calendar/events_calendar.csv) | تاریخ کسب‌وکار، ماه شمسی، روز هفته، تعطیلی و زمینهٔ رویداد. |
| S13 | [history](../../dataset/history/) | حافظهٔ تصمیم و گزارش قدیمی با تعریف متفاوت. |
| S14 | [drops](../../dataset/drops/) | ۹۱ manifest و ۱٬۰۷۹ فایل CSV؛ نمونه‌های روزهای ۰۰۰، ۰۶۶، ۰۶۷، ۰۷۰، ۰۷۶، ۰۸۱ و ۰۸۲ مستقیماً بررسی شدند. |
| S15 | [نقشهٔ اکتشافی](../../review/exploration/DATA_MAP_FA.md) و [نتایج اکتشاف](../../review/exploration/) | مدرک کمکی دربارهٔ جدول‌ها و روابط؛ جایگزین قرارداد رسمی نیست. |
| S16 | [Architecture review record](sources/Adr.md) | Exact copy of `C:/Users/ashkriz/Desktop/Adr.md`, supplied by the user. Q01-Q17 and the result table were read. Explicit team decisions are separated from proposals. |
| S17 | [Existing Structurizr model](../../architecture/structurizr/workspace.dsl) | Authority notes and relevant component contracts checked. Confirms one Agent, PostgreSQL-only execution, and independent publication. The model file was not changed. |

S16 is available. A complete official raw-column Data Dictionary, source closure contract, and hidden evaluation labels were not found. Observed columns and audit results do not replace these contracts.

Earlier audit findings are historical evidence. This review did not rerun the 55 SQL queries or verify every earlier audit claim. See the current verification record in document 004.

Current S01 SHA-256: `6d68d3fcc285f6908af0d97c0429dfefb489f00b7f6538ed03573552ed6955f8`. The former listed hash was `fac22a35109e627d90be519e187354a773f57a4d26561311ce90963e3780e747`. It does not match the current file. This does not establish which PDF content changed.

### ۲.۲. مشاهده‌هایی که طراحی را محدود می‌کنند

| مشاهده | اثر بر معماری |
|---|---|
| ۲۶۲ تکرار دقیق در `day_076/orders.csv`؛ ۶۹۹ ردیف خام و ۴۳۷ payload متمایز | idempotency دریافت با حذف تکرار تجاری یکسان نیست. هر دو سیاست ورودی باید قابل اجرا و نسخه‌دار باشند. |
| در S09، هشت KPI دارای ۴۱ اختلاف در snapshot نهایی و ۴۱۸ اختلاف در replay هستند | انتخاب RAW/DEDUP شرط پذیرش است؛ نمی‌توان آن را بهینه‌سازی بی‌اثر نامید. |
| سه فایل پشتیبانی در روز ۰۶۶ هم در پوشه و هم در manifest غایب‌اند | مقایسهٔ فایل با manifest کافی نیست؛ قرارداد منبع مورد انتظار نیز لازم است. |
| دادهٔ روز ۰۶۷، ۳۲ کلید تاریخی پشتیبانی را تغییر می‌دهد؛ هفت مورد متعلق به روز ۰۶۵ است | invalidation یک‌روزه یا محدودیت ثابت تأخیر کافی نیست. |
| ۳۵ مجموعهٔ مشارکت‌کننده عوض شده‌اند، ولی سه خروجی گرد‌شده ثابت مانده‌اند | تساوی مقدار، گواه تساوی شواهد یا کامل‌بودن نیست. |
| اصلاح `L02045` در drop 070 می‌رسد و فقط از صبح ۷۱ مجاز است | فیلتر دریافت باید قبل از ساخت fact اعمال شود. |
| از روز ۰۸۲ دو نام ستون پشتیبانی عوض می‌شود | adapter باید بر اساس schema شناخته‌شده کار کند، نه شمارهٔ روز ثابت. |
| تغییر روش محاسبهٔ مدت زمان، هشت مقدار گرد‌شده را در S08 تغییر داده است | معادل ریاضی PostgreSQL بدون آزمون، معادل محاسباتی قرارداد نیست. |

<a id="system-3"></a>

## ۳. ردیابی نیازمندی‌ها

| ID | الزام و مرجع | مسئول طراحی | آزمون پذیرش در سند 003 |
|---|---|---|---|
| <a id="req-01"></a>REQ-01 | دریافت ماژولار و ادامهٔ گزارش هنگام نبود منبع؛ S01 ص۱۳-۱۴، S02 | Ingestion، DQ، Orchestrator | AT-01، AT-04 |
| <a id="req-02"></a>REQ-02 | محاسبه با SQL ثبت‌شده و صفر عدد نادرست؛ S01 ص۱۳ و ۱۶، S03-S04 | Semantic، ReferenceCalculator، Validator | AT-02، AT-03 |
| <a id="req-03"></a>REQ-03 | سلسله‌مراتب قابل تغییر بدون تغییر کد؛ S01 ص۲ و ۱۷، S05 و S07 | Organization، Authorization | AT-07 |
| <a id="req-04"></a>REQ-04 | حداکثر پنج مورد، مالک درست، حذف تکرار و تشدید؛ S01 ص۷-۸، S11 | Signal، Workflow، Report | AT-08، AT-09 |
| <a id="req-05"></a>REQ-05 | دو شاهد مستقل برای هر علت و کوئری برای هر عدد؛ S01 ص۹-۱۰ | Evidence، Analysis، Validator | AT-10 |
| <a id="req-06"></a>REQ-06 | گزارش فارسی و RTL، داشبورد، گفتگو و اتاق کنترل؛ S01 ص۱۱-۱۲ و ۱۵ | Interface، Brief Publisher | AT-11 |
| <a id="req-07"></a>REQ-07 | سه Workflow از لاگ واقعی، SLA و گلوگاه؛ S01 ص۵-۶ و ۱۶، S11 | Process Projection | AT-12 |
| <a id="req-08"></a>REQ-08 | دسترسی ردیفی برای همهٔ کوئری‌های کاربر؛ S01 ص۱۳، S05 | Query Gateway، RLS | AT-06 |
| <a id="req-09"></a>REQ-09 | دادهٔ فردی فقط برای سرپرست مستقیم و مدیریت کار؛ S01 ص۱۳ و ۱۷ | Authorization، Privacy Filter | AT-06 |
| <a id="req-10"></a>REQ-10 | متن تیکت و فایل دستور نیست؛ S01 ص۱۳ و ۱۷ | Input Boundary، Tool Gateway | AT-13 |
| <a id="req-11"></a>REQ-11 | تصمیم با مدیر؛ فقط پیش‌نویس و پیگیری؛ S01 ص۱۱-۱۲، S02 | Decision Registry | AT-14 |
| <a id="req-12"></a>REQ-12 | تاریخچهٔ ۶۰ روز و replay سی روز، صبح ۶۲ تا ۹۱؛ S01 ص۱۴، S02 | ReplayClock، Snapshot Builder | AT-03، AT-15 |
| <a id="req-13"></a>REQ-13 | کشف حداقل ۹۰٪ در ۲۴ ساعت و دقت گفتگو حداقل ۸۵٪؛ S01 ص۱۶-۱۷ | Evaluation Harness | AT-09، AT-16 |
| <a id="req-14"></a>REQ-14 | هر روز حداکثر ۱۵ دقیقه روی ماشین مرجع؛ گزارش پیش از ۰۷:۳۰ شبیه‌سازی؛ S01 ص۱۴ | Orchestrator، Metrics | AT-17 |
| <a id="req-15"></a>REQ-15 | مجموع هزینهٔ LLM حداکثر ۵ دلار در روز، شامل گفتگو؛ S01 ص۱۶ | Budget Ledger | AT-18 |
| <a id="req-16"></a>REQ-16 | اجرای بدون تغییر کد روی دادهٔ پنهان؛ بستهٔ Docker با یک دستور؛ S01 ص۱۴ و ۱۸ | Configuration، Packaging | AT-19 |
| <a id="req-17"></a>REQ-17 | اصلاح تاریخی، رکورد دیررس، تکرار و schema change به‌عنوان مسئلهٔ داده؛ S01 ص۱۴ و ۱۷ | Ingestion، DQ، Versioning | AT-04، AT-05 |

اعداد حدود ۱۵۰ شاخص روزانه، ۲۵ سیگنال و هشت تحلیل در بریف، اندازهٔ تقریبی هستند. آن‌ها حداقل خروجی اجباری نیستند. ۵۵ تعریف می‌توانند چندین سری بعددار تولید کنند. صفحهٔ ۱۹ نیز نهایی‌شدن حدود پذیرش را به برگزارکننده واگذار می‌کند؛ اجرای آینده باید نسخهٔ حدود را ثبت کند.

<a id="system-4"></a>

## ۴. نمای ماژول‌ها و مرز اعتماد

```mermaid
flowchart TB
    S["CSV / manifest / manager inputs / uploads"] --> I["A: Ingestion adapters"]
    I --> R["Immutable source files + provenance"]
    I --> Q["DQ incidents and delivery state"]
    R --> H["B: Snapshot and event history"]
    H --> C["C: ReferenceCalculator - PostgreSQL SQL"]
    C --> K["Versioned KPI observations - PostgreSQL"]
    Q --> K
    K --> D["D: Deterministic signal engine"]
    H --> W["D: Workflow projections"]
    D --> G["G: Authorization and evidence gateway"]
    W --> G
    G --> E["E: Scoped analysis and Insight Brief"]
    E --> V["Number / scope / evidence / schema checks"]
    V --> F["F: Persian reports, dashboard, QA, control room"]
    F --> M["Human decision"]
    M --> A["Decision record and action drafts"]
    A --> G
    X["H: ReplayClock and evaluation"] --> H
    X --> V
```

منابع، متن آزاد و LLM قابل اعتماد اجرایی نیستند. worker محاسبهٔ ثبت‌شده و Query Gateway مرزهای مجزا دارند. worker می‌تواند با هویت خدماتی، snapshot سازمان را برای KPIهای ثبت‌شده محاسبه کند. این مجوز به LLM، مدیر یا مسیر Text-to-SQL منتقل نمی‌شود. دادهٔ خروجی worker نیز قبل از هر استفادهٔ کاربری، کنترل دسترسی می‌شود.

### ۴.۱. مسئولیت و رابط هر ماژول

نام رابط‌ها قرارداد طراحی است؛ endpoint یا کد موجود نیست.

| ماژول | ورودی | خروجی | مرز و رفتار خطا |
|---|---|---|---|
| A: `SourceAdapter` | `DeliveryEnvelope`، bytes و schema fingerprint | `ParsedBatch` با raw pointers، رکوردهای معتبر و ردشده | فقط parse و نگاشت مصوب؛ تغییر فرمول یا تصمیم دربارهٔ تکرار تجاری ممنوع. خطا با source/file/row ثبت می‌شود. |
| A: `IngestionCoordinator` | manifest، SourceContract، idempotency key | `BatchReceipt` و `SourceStatus` | ثبت فایل و metadata اتمی؛ فایل خراب به quarantine می‌رود. منابع سالم ادامه می‌یابند. |
| B: `SnapshotService` | `KnowledgeCutoff`، policy/config versions | `SnapshotRef` و روابط مجاز reference | فقط batchهای committed؛ زمان رویداد جای cutoff دریافت را نمی‌گیرد. |
| B: `ProjectionService` | snapshot و تغییرات entity/event | factهای نسخه‌دار و `ProjectionDelta` | projection قابل بازسازی است. raw و گزارش گذشته تغییر نمی‌کنند. |
| C: `SemanticRegistry` | S03-S04 و تنظیمات نسخه‌دار | `KpiSpec`، `DependencySpec`، units و query hash | SQL و metadata اصلی حفظ می‌شوند. شاخص جدید شناسهٔ جدید دارد. |
| C: `ReferenceCalculator` | Frozen snapshot, canonical definition, PostgreSQL SQL version, input policy | KPI result, QueryRun, lineage | Registered SQL only. Equivalence to original SQL is required. Do not replace failures with zero. |
| D: `SignalEngine` | KPIهای واجد شرایط، rule version و سابقه | signal occurrence، incident link و وضعیت مخاطب | بدون LLM؛ DQ به‌تنهایی business signal نمی‌سازد. |
| D: `WorkflowEngine` | event history، stage definitions و clock | case/stage وضعیت، SLA، bottleneck evidence | مرحلهٔ بدون SLA، وضعیت unknown دارد؛ عدد نمایشی بریف استفاده نمی‌شود. |
| E: `EvidenceService` | signal، scope، snapshot و پرسش محدود | `EvidenceBundle` با query و source pointers | قبل از ورود به LLM، row/column filtering و بررسی مقصد انجام می‌شود. |
| E: `AnalysisCoordinator` | evidence، محدودیت ابزار و بودجه | `InsightBrief` با facts، hypotheses، گزینه‌ها | ادعای بی‌شاهد حذف یا به نیاز بررسی تبدیل می‌شود؛ عدد توسط ابزار تولید می‌شود. |
| F: `ManagementInputService` | پرسش، تصمیم یا تغییر تنظیم احراز‌شده | input event، config revision یا QA job | متن فایل نمی‌تواند دستور مدیر بسازد. تغییر مجاز از زمان اثر مشخص فعال می‌شود. |
| F: `Publisher` | One authorized and validated manager package | JSON/text version and publication receipt | Publish valid packages independently. Record failed or absent packages and incomplete day status. |
| G: `QueryGateway` | AuthContext، QuerySpec و snapshot | نتیجهٔ محدود، query receipt یا refusal | read-only، deny by default و RLS؛ LLM هیچ credential پایگاه داده ندارد. |
| H: `ReplayRunner` | dataset root، clock و EvaluationProfile | run receipts، خروجی‌ها، معیار زمان/هزینه/صحت | هیچ شاخهٔ رفتاری به شمارهٔ حادثه یا شناسهٔ نمونه وابسته نیست. |

### Input and document boundary

`Requirement`: accept nightly sources and manager inputs, including uploads. The brief includes Excel as an upload example. S07 supplies CSV and Markdown attachments. The fixture set does not remove the upload requirement. Exact formats, Excel validation, PDF support, text retrieval, and RAG remain Open or Proposed under [ADR-16](003-decisions-and-roadmap.md#adr-16). Do not ingest developer documents, architecture files, audits, or hidden labels as product evidence. An operational Markdown upload remains untrusted data.

### ۴.۲. قرارداد مشترک پیام‌ها

هر درخواست داخلی دارای `request_id`، `run_id`، `schema_version`، `snapshot_id` و `policy_bundle_id` است. عملیات کاربر، `principal_id`، `auth_context_id` و `purpose` نیز دارند. `AuthContext` را سرور از هویت معتبر می‌سازد؛ این فیلد از متن LLM یا `manager_id` ارسالی کاربر پذیرفته نمی‌شود.

| قرارداد | فیلدهای اصلی و قید |
|---|---|
| `DeliveryEnvelope` | `dataset_id, source_id, drop_day, manifest_hash, file_hash, source_schema_version, received_at, batch_id`؛ `received_at` واقعی است. |
| `SnapshotRef` | `knowledge_drop_max, commit_seq_max, business_date_max, source_version_set, config_version_set, org_version, input_policy_id`؛ پس از ساخت تغییر نمی‌کند. |
| `KpiObservation` | `kpi_id, entity_id, dim, business_date, row_state, reference_value, publication_state, completeness_state, query_id, contributor_hash`؛ نبود ردیف از NULL جداست. |
| `SignalOccurrence` | `signal_id, episode_id, series_key, rule_version, occurrence_day, baseline_refs, owner_id, severity, dq_links`؛ وضعیت انتشار به مخاطب وابسته است. |
| `EvidenceBundle` | `scope_fingerprint, facts, queries, source_groups, contradictions, limitations, data_issues`؛ هر fact به query و snapshot متصل است. |
| `InsightBrief` | `summary, impact, metric_refs, drilldowns, causes, alternatives, options, history, proposed_owner, query_refs`؛ شرط پذیرش هر علت جدا بررسی می‌شود. |
| `QueryReceipt` | SQL واقعی اجراشده، params، hash، principal، purpose، snapshot، policy، زمان، تعداد ردیف، نتیجه یا خطا؛ log خودش مشمول دسترسی است. |
| `DecisionEvent` | `decision_id, actor_id, brief_version, selected_option, decided_at, effective_from, success_metric_refs`؛ هیچ اجرای خارجی ضمنی ندارد. |

کدهای خطای پایدار پیشنهادی: `SOURCE_MISSING`، `SCHEMA_UNSUPPORTED`، `CORRECTION_CONFLICT`، `REFERENCE_QUERY_FAILED`، `ACCESS_DENIED`، `BUDGET_EXHAUSTED` و `OUTPUT_VALIDATION_FAILED`. پاسخ خطا، دادهٔ خارج از scope یا نام فایل محرمانه را آشکار نمی‌کند.

<a id="system-5"></a>

## ۵. جریان اجرای شبانه و replay

```mermaid
sequenceDiagram
    participant R as ReplayClock
    participant I as Ingestion
    participant S as SnapshotService
    participant K as ReferenceCalculator
    participant G as Signal and Evidence
    participant L as LLM
    participant V as Validator
    participant P as Publisher
    R->>I: Admit drop D and eligible input events
    I->>I: Preserve, validate, commit, record DQ
    I->>S: Build snapshot for morning D+1
    S->>K: Cutoff-filtered reference relations
    K->>G: Versioned values and availability
    G->>G: Rules, workflow state, scoped evidence
    G->>L: Authorized evidence and reserved budget
    L->>V: Draft with evidence references
    V->>K: Verify numeric references on same snapshot
    V->>P: Validated report package
    P->>P: Commit version and publication receipt
```

۱. `day_000` بار اولیهٔ CRM است. نبود سایر منابع در آن روز حادثه نیست. روزهای ۱ تا ۶۰ برای تاریخچه و baseline وارد می‌شوند.

۲. گزارش صبح `R` فقط dropهای `000..R-1` را می‌بیند. پرسش روز `D` نیز فقط دادهٔ dropهای تا `D-1` را می‌بیند. تغییرهای مدیریتی روز `D` از گزارش `D+1` اثر می‌گذارند. `commit_seq` از ورود تصادفی فایل جدید به snapshot در حال اجرا جلوگیری می‌کند.

۳. رویدادهای ورودی بر اساس روز و ترتیب ثبت معتبر زمان‌بندی می‌شوند. ترتیب فعلی آرایهٔ S07 نباید clock را عقب ببرد. ترتیب چند ورودی هم‌روز و دریافت attachment باید صریح ثبت شود؛ ابهام manager Q09/IN07 در ADR-08 آمده است.

۴. missing source و schema failure مانع گزارش کل سازمان نمی‌شوند. گزارش هر مدیر با داده‌های مجاز و سالم و با بخش `data_issues` تولید می‌شود. مقدار ناموجود `null` است. «هیچ هشدار تأییدشده‌ای نیست» جایگزین «همه‌چیز سالم است» می‌شود، اگر داده کافی نباشد.

5. Pin calculation and configuration versions. Publish a report only after validation. Commit one manager package atomically. Publish packages independently. Retry must not duplicate a report or signal. Record day coverage separately.

۶. تغییر تاریخی، نسخهٔ جدید KPI می‌سازد. گزارش صبح گذشته با دادهٔ جدید بازنویسی نمی‌شود. مسیر `restated` از مسیر `as_reported` جداست.

<a id="system-6"></a>

## ۶. Semantic Layer و محاسبه

همهٔ ۵۵ تعریف از S03 خوانده شوند. SQL، شناسه، entity، مالک، unit، direction، rule، target، warn، crit، dim و مهلت تشدید در registry نسخه‌دار قرار گیرند. فهرست کامل پوشش و وابستگی در سند 002 است.

`cal` همان calendar عرضه‌شده است و فقط `date` به `d` نگاشت می‌شود. `crm_lead_events.drop_day` از manifest معتبر اضافه می‌شود. نگاشت شناخته‌شدهٔ `create_time -> created_at` و `event_time -> at` در adapter انجام می‌شود. فایل و SQL اصلی دست‌نخورده می‌مانند.

گردکردن در خود SQL مرجع انجام می‌شود. LLM، رابط و serializer نباید مقدار را دوباره گرد کنند. واحد «میلیون تومان»، «هزار تومان»، «تومان»، «ساعت»، «روز»، درصد و امتیاز از پنج یکسان نیستند. اختلاف دو درصد در توضیح، «واحد درصد» است. هر محاسبهٔ اضافه باید query و تعریف ثبت‌شدهٔ مستقل داشته باشد.

تجمیع سلسله‌مراتبی به معنی جمع‌زدن همهٔ خروجی‌های فرزند نیست. نرخ از صورت و مخرج، میانگین از sum/count و median از نمونه‌های مجاز محاسبه می‌شود. median تیم‌ها یا درصدهای گرد‌شده میانگین‌گیری نمی‌شوند. KPIهای تکراری در چند سطح، مانند FRT، شواهد مستقل نیستند. برای ۵۵ تعریف موجود، SQL همان سطح مرجع است؛ rollup جدید با شناسهٔ جدید ثبت می‌شود.

<a id="system-7"></a>

## ۷. موتور سیگنال و Workflow

### ۷.۱. قواعد قطعی و سابقهٔ مخاطب

قواعد S11 به‌صورت داده خوانده می‌شوند. `threshold` جهت KPI را رعایت می‌کند. `threshold_from_day8` پیش از روز هشتم ماه شمسی ارزیابی نمی‌شود. `info` هشدار نمی‌سازد. `dow_baseline:N` میانهٔ همان روز هفته در چهار هفتهٔ قبل را مبنا می‌گیرد و روز تعطیل را از این قاعده مستثنا می‌کند.

هر مقایسه فقط از مقادیر مجاز در همان knowledge snapshot استفاده می‌کند. نبود baseline، مقدار صفر مبنا یا دادهٔ نامطمئن به نتیجهٔ عادی یا انحراف نامحدود تبدیل نمی‌شود. جهت انحراف baseline، حداقل تعداد نمونه و تساوی دقیق با آستانه در ADR-07 تعیین می‌شوند.

| قاعدهٔ منبع | رفتار طراحی |
|---|---|
| R1 | شروع در `owner_manager_id` و پایین‌ترین سطح مسئول. اگر مالک فعال نباشد، routing issue ثبت شود؛ مالک جدید حدس زده نشود. |
| R2 | عبور از `crit`، بیش از `escalate_after_days` روز در وضعیت هشدار، یا بدترشدن حداقل ۲۰٪ نسبت به اولین گزارش، علت تشدید است. جهت بهتر/بدتر از dictionary می‌آید. |
| R3 | عبور Workflow یا شاخص سازمان از warn، طبق قاعدهٔ منبع به مدیر ارشد ارجاع می‌شود. سابقه و علت ثبت شود. |
| R4 | تغییر کمتر از ۱۰٪، گزارش تازهٔ همان سیگنال به همان مخاطب نمی‌سازد. مورد در `open_items` می‌ماند. |
| R6 | حداکثر پنج مورد؛ چند سیگنال هم‌علت فقط با مدرک مشترک و scope مجاز یک مورد می‌شوند. |

`series_key = kpi_id + entity_id + dimension` است. تاریخ هر occurrence جدا ثبت می‌شود. episode با استمرار مسئله مرتبط است، نه با یک مقدار گرد‌شده. هر مخاطب `first_seen, last_sent, first_value, last_value, escalation_reason` جدا دارد. افزایش سطح، تاریخچهٔ گزارش مالک را پاک نمی‌کند.

اولویت‌بندی پیشنهادی: شدت، اثر مشتری، اثر مالی مستند، وابستگی بین‌واحدی، اطمینان شواهد و اولویت اعلام‌شدهٔ مدیر. وزن‌ها تنظیمات نسخه‌دار هستند؛ عددهای نمایشی بریف وزن مصوب نیستند. اولویت مدیر نمی‌تواند دادهٔ غایب یا قید دسترسی را نادیده بگیرد.

تغییر مقدار ناشی از اصلاح، backfill، dedup یا schema repair به `knowledge_revision` متصل می‌شود. خود این تغییر، علت تجاری جدید نیست. وضعیت تجاری جاری فقط با شواهد واجد شرایط جداگانه ارزیابی می‌شود. گزارش‌های قدیمی و تشدیدهای واقعاً ارسال‌شده حفظ می‌شوند.

### ۷.۲. سه Workflow و Process Mining سبک

| Workflow | case و مراحل اصلی | خروجی و محدودیت |
|---|---|---|
| `WF1` | `order_id`: created، paid، picked، handed_over، delivered؛ سپس اتصال تیکت از `tickets.order_id` | SLA مراحل ۱، ۱۲ و ۶ ساعت؛ تحویل نسبت به `promised_by`. مرحلهٔ پیگیری SLA عددی ندارد. `K_WF1_SLA` فقط فرمول خود dictionary را اجرا می‌کند. |
| `WF2` | `ticket_id` مربوط به `T_CMP`: created، first_response، inspected، resolved | مراحل ۸، ۳۶ و ۲۴ ساعت از config. KPI کلی `K_WF2_SLA` حل در ۴۸ ساعت است؛ جمع مهلت مراحل جای آن را نمی‌گیرد. |
| `WF3` | `lead_id`: created، first_contact، qualified، proposal_sent، won/lost | مهلت مراحل ۲۴، ۷۲، ۱۲۰ و ۷۲۰ ساعت. KPI هفت‌روزهٔ WF3 همهٔ همین مراحل را عیناً نمی‌سنجد؛ SQL معیار نهایی است. |

projection فرآیند، مسیرها، مراحل طی‌شده، تکرار مرحله، ترتیب نامعتبر، case باز و زمان انتظار را ثبت می‌کند. case باز، نمونهٔ تکمیل‌شده برای median نیست؛ مدت انتظار آن در series جداست. نبود مرحله، شکست SLA یا صفر زمان فرض نمی‌شود.

نقشهٔ `directly-follows`، تعداد case، مدت مرحله، درصد SLA و backlog برای تشخیص گلوگاه کافی است. فعلاً موتور BPM، کشف فرایند با مدل پیچیده یا زیرساخت مستقل لازم نیست. گلوگاه از دادهٔ واقعی و هدف همان مرحله به دست می‌آید. آستانهٔ نمونهٔ کم و رتبه‌بندی گلوگاه پیشنهاد طراحی هستند.

روابط `order_id` و `ticket_id` شواهد اتصال پرونده‌اند. `mkt_daily` شناسهٔ lead ندارد؛ اتصال تک‌به‌تک تبلیغ به قرارداد از آن قابل اثبات نیست. مسیر بازاریابی به CRM فقط در سطح source و بازهٔ زمانی بررسی می‌شود، مگر رابطهٔ معتبر دیگری ارائه شود.

مالک انتهابه‌انتهای هر Workflow از ستون `owner` در S11 می‌آید. برای انتساب گلوگاه به مرحله، `order_events.actor_team` یا رابطهٔ مجاز staff/team در زمان رخداد بررسی می‌شود. نبود actor معتبر، مجوز حدس‌زدن مالک مرحله نیست؛ mapping تکمیلی stage-to-team در policy catalog تأیید شود. این metadata با مالک KPI موجود جایگزین نمی‌شود.

fact مرجع با projection چرخهٔ جاری یکی نیست. برای مثال `ticket_fact.resolved_at` برابر MAX است و `reopened` را جدا نگه می‌دارد. نمایش پروندهٔ بازشدهٔ مجدد نباید فرمول backlog مرجع را بی‌صدا تغییر دهد.

<a id="system-8"></a>

## ۸. تحلیل مبتنی بر شواهد و Insight Brief

برای هر مورد، ابتدا `EvidenceBundle` قطعی ساخته می‌شود: query مربوط به KPI، شکست مجاز بر حسب زمان/کانال/شهر/دسته، دادهٔ Workflow، رویداد زمینه‌ای، ظرفیت تجمیعی و تصمیم‌های گذشته. شناسهٔ evidence تا فایل و ردیف منبع قابل پیگیری است.

هر علت قابل انتشار باید حداقل دو گروه شاهد مستقل داشته باشد. دو KPI مشتق از یک جمعیت، دو شاهد مستقل نیستند. نمونهٔ مناسب، تغییر صف تیکت و دادهٔ ظرفیت تجمیعی از منبع جداست. استقلال مسیر مشاهده، استقلال آماری یا اثبات علیت نیست؛ S02 تصریح می‌کند که کل داده از یک شبیه‌سازی مشترک ساخته شده است.

| نوع گزاره | شرط |
|---|---|
| `observed_fact` | نتیجهٔ query ثبت‌شده، snapshot معلوم، مقدار و scope تأییدشده. |
| `supported_hypothesis` | حداقل دو گروه شاهد، ترتیب زمانی سازگار، محدودیت‌ها و علت جایگزین؛ متن با زبان احتمالی. |
| `needs_evidence` | کمتر از شواهد لازم یا تعارض؛ علت قطعی در گزارش ساخته نمی‌شود. اقدام بعدی برای جمع‌آوری شاهد پیشنهاد می‌شود. |
| `decision_option` | مالک، هزینه/اثر در صورت وجود evidence، ریسک، مهلت و معیار موفقیت؛ عدد تخمینی بدون روش و query ممنوع. |

`cause_confidence` با `source_completeness` یا صحت عدد یک فیلد نیست. روش امتیازدهی اطمینان باید نسخه‌دار و قابل توضیح باشد؛ عدد ۰ تا ۱ احتمال آماری کالیبره‌شده فرض نمی‌شود. برچسب کم/متوسط/زیاد و دلیل آن در متن بیاید. ادعای اثر تصمیم نیز مشاهدهٔ قبل/بعد است؛ هم‌زمانی، اثبات اثر علّی نیست.

ابزارهای مجاز تحلیل محدودند: `read_kpi`، `query_scoped_data`، `read_workflow`، `read_calendar_context`، `read_decision_history` و `propose_action_draft`. ابزار ویرایش منبع، ارسال پیام، جابه‌جایی نیرو و تغییر خودکار هدف وجود ندارد. درخواست tool دوباره مجوز، snapshot، row limit و بودجه را بررسی می‌کند.

ابزار `propose_action_draft` فقط با `DecisionEvent` معتبر و تأییدشدهٔ مدیر فعال می‌شود. پیش از آن، مدل فقط گزینهٔ تصمیم را در Insight Brief پیشنهاد می‌کند. هیچ فرمان داخل فایل، مدرک تأیید مدیر محسوب نمی‌شود.

یک `InsightBrief` نسخه‌دار منبع مشترک گزارش‌هاست. projection هر نقش فقط evidence مجاز همان نقش را شامل می‌شود. Brief حاوی اطلاعات فردی تیم به Writer مدیر بالاتر داده نمی‌شود. هم‌معنابودن تحلیل نباید به اشتراک‌گذاری خام prompt میان مدیران منجر شود.

مجوز نتیجهٔ مشتق نیز از شواهد آن پیروی می‌کند. مخاطب یک علت باید مجوز همهٔ شواهد لازم برای همان علت را داشته باشد. حذف یک جدول محرمانه و نگه‌داشتن نتیجه‌ای که از آن به دست آمده، کنترل دسترسی کافی نیست. برای مخاطب محدود، علت حذف یا با شواهد مجاز دوباره ساخته شود. انتشار خلاصهٔ بین‌واحدی فقط با grant صریح و خروجی تجمیعی مصوب مجاز است.

### ۸.۱. بودجه و رفتار هنگام خرابی LLM

سقف الزام‌شده ۵ دلار برای مجموع گزارش، تحلیل، پرسش‌های همان روز و retryهاست. `BudgetLedger` پیش از هر فراخوانی، هزینهٔ حداکثری آن را رزرو و پس از پاسخ با مصرف واقعی تسویه می‌کند. نرخ مدل از price config دارای تاریخ می‌آید. مدل یا قیمت مشخص در این طرح تثبیت نشده است.

پیشنهاد اولیه: تحلیل عمیق فقط برای موارد مهم، حداکثر دو دور تکمیل شواهد در هر تحلیل و سهم ذخیرهٔ بودجه برای QA. حدود دقیق در ADR-10 تصویب و با تست بار سنجیده شوند. عدد تقریبی هشت تحلیل در بریف سهمیهٔ اجباری نیست.

cache شامل snapshot، query/result hash، scope fingerprint، policy، model و prompt version است. cache بدون scope ممنوع است. هنگام کمبود بودجه یا خطای مدل، گزارش با قالب قطعی و عددهای تأییدشده ساخته می‌شود. علت بدون شاهد و گزینهٔ تخمینی حذف می‌شود. افت کیفیت تحلیل در لاگ ثبت می‌شود؛ عبور از سقف هزینه راه جبران نیست.

<a id="system-9"></a>

## ۹. رابط‌های مدیریت و خروجی

سه صفحهٔ اصلی فارسی و RTL کافی است: گفتگو و گزارش صبح، داشبورد نقش‌محور و اتاق کنترل Workflow برای مدیر ارشد. صفحهٔ سابقهٔ تصمیم و اقدام، بخشی از همین رابط‌هاست. از هر عدد می‌توان query و شواهد مجاز آن را دید.

| نقش | محتوای مجاز |
|---|---|
| مدیر ارشد | سلامت سازمان، پنج KPI اصلی، سه Workflow، موارد تشدیدشده و اثر تصمیم‌ها؛ دادهٔ کارکنان فقط تجمیعی. |
| مدیر واحد | شاخص‌ها و تیم‌های زیرمجموعه، ریسک وابستگی و گزینهٔ تخصیص منابع؛ بدون نام و بارکاری فردی. |
| سرپرست | KPI تیم، کارهای باز، موانع و بارکاری اعضای مستقیم برای مدیریت کار؛ بدون رتبه‌بندی یا معرفی مقصر. |

تعداد تیم و مدیر در UI ثابت نوشته نمی‌شود. `M11/T_MKT` آزمون تغییر سازمان است، نه استثنای کدنویسی. ابهام زمان فعال‌شدن آن در ADR-08 ثبت شده است.

### ۹.۱. قرارداد خروجی و کنترل پیش از انتشار

`submission/briefs/day_XXX/<manager_id>.json` از `brief_schema.json` ساخته می‌شود. `report_day, manager_id, items, numbers, data_issues, text_fa` الزامی‌اند. `items` حداکثر پنج مورد دارد. هر عدد، KPI/entity/dim/date/value و `query_id` قابل ردیابی دارد. اگر schema فیلدی را اختیاری بداند ولی بریف آن را برای ردیابی لازم بداند، Validator داخلی آن را الزامی می‌کند.

متن و JSON از یک مدل محتوای تأییدشده تولید می‌شوند. بازنویسی فارسی فقط ظاهر رقم و جمله را تغییر می‌دهد. استخراج عدد از متن، کنترل واحد، تطبیق evidence و کنترل دسترسی پیش از انتشار انجام می‌شود. مقدارهای ساختگی `example_brief.json` و تاریخ ناسازگار آن در محاسبه استفاده نمی‌شوند.

`data_issues.source` فقط enumهای قرارداد را دارد: `orders, tickets, crm, tasks, marketing, sessions, availability`. مسئلهٔ `csat` و `ticket_events` به `tickets` نگاشت می‌شود و نام دقیق فایل در detail مجاز می‌آید. حالت‌های داخلی بیشتر، در همین schema با `type=other` و توضیح قابل فهم نشان داده می‌شوند؛ enum منبع تغییر نمی‌کند.

برای دادهٔ ناموجود، `value=null` و issue ثبت شود. `open_items` محل موارد بدون تغییر است. وضعیت‌های item فقط `new, escalated, ongoing` هستند. بریف ص۱۵ از `suppressed` نام می‌برد؛ proposed mapping, pending organizer confirmation، نگهداری suppression در ledger داخلی و `open_items` است، نه فرستادن enum نامعتبر. این نگاشت نیازمند تأیید ADR-09 است.

پاسخ پرسش در `submission/qa/<input_id>.json` ذخیره می‌شود. وضعیت فقط یکی از `answered, refused_out_of_scope, refused_individual_data, data_unavailable, clarification_requested` است. query واقعاً اجراشده، rows و تعریف استفاده‌شده همراه پاسخ می‌آید. SQL پیشنهادی اجرا‌نشده به‌عنوان SQL اجراشده ثبت نمی‌شود.

در پرسش مبهم «فروش»، تعریف روشن شود: ثبت سفارش، فروش ناخالص، خالص B2C یا درآمد شامل قرارداد. گزارش قدیمی و فایل بیرونی تا تعیین تعریف و بازه وارد KPI مرجع نمی‌شوند. تفاوت، با reconciliation ثبت‌شده توضیح داده می‌شود؛ برابرسازی عددها هدف نیست.

### Last valid value and report failure

S16 Q06 records display of the last valid value with its actual date. S17 keeps this behavior. Preserve that historical context. Never put a prior value in a current-date KPI field. The unavailable current value remains `null` with a data issue. A historical number needs its actual KPI date, query, snapshot, and current access check. Eligibility, maximum age, and exact output mapping remain Open in [ADR-04](003-decisions-and-roadmap.md#adr-04).

Independent publication is Accepted. Record a failed or missing required package even if no draft exists. The day cannot pass coverage while that failure remains. A fallback must pass all checks and must not invent a cause. Its detailed policy remains Proposed under ADR-14.

<a id="system-10"></a>

## ۱۰. امنیت و حاکمیت

دامنهٔ دسترسی تصمیم باز نیست: بریف ص۱۰ و ص۱۳ و `dataset/org/access_matrix.csv` مرجع الزام‌اند. مدیران M01 تا M04 فقط دادهٔ تجمیعی زیرمجموعه را می‌بینند. سرپرستان M05 تا M11 فقط در تیم مستقیم خود دادهٔ فردی برای مدیریت بار کار دارند. مرخصی فقط ظرفیت تجمیعی تیم است؛ مجوز فردی این محدودیت را حذف نمی‌کند. جدول کامل دامنه‌ها و تفکیک الزام از جزئیات اجرای باز در ADR-06 سند 003 ثبت شده است. فهرست ستون‌های مجاز منابع مشترک باید از این قواعد استخراج و آزموده شود؛ بریف فهرست تک‌تک ستون‌ها را تعیین نکرده است.

`visible_entities` با سلسله‌مراتب فعال و مجوز منبع ترکیب می‌شود. فقط داشتن نقش مدیر بالاتر، مجوز دادهٔ فردی نمی‌دهد. `individual_level_data_team` استثنای محدود برای سرپرست مستقیم است. `staff_availability.status` نباید به فهرست حضور و مرخصی اشخاص تبدیل شود؛ ظرفیت برای تحلیل بالاتر تجمیعی است.

کنترل فیلد فردی به ستون staff_id محدود نیست. نام کارکنان یا اطلاعات فردی داخل `text_fa`، title و blocker نیز پیش از ورود به LLM بررسی و در صورت نامجازبودن حذف شوند. ذکر نام مجاز در گزارش باید با `mentioned_staff_ids` منطبق باشد. حذف شناسهٔ ساختارمند، متن آزاد را خودکار مجاز نمی‌کند.

| مسیر | کنترل لازم |
|---|---|
| KPI ذخیره‌شده | RLS بر entity، active roster، snapshot و sensitivity؛ ارجاع از report نیز دوباره مجوز می‌خواهد. |
| raw و event | فقط هویت ingestion/calculation محدود؛ مدیر و LLM مجوز مستقیم روی مخزن خام ندارند. |
| ad hoc SQL | انتخاب schema مجاز، AST validation، transaction فقط‌خواندنی، محدودیت زمان/حجم و RLS پیش از نتیجه. |
| evidence و فایل | مجوز در retrieval، حذف فیلد فردی نامجاز و ثبت مقصد؛ متن آزاد untrusted است. |
| cache و log | کلید scope و policy؛ لاگ کامل تنها برای نقش audit؛ خطا و query plan نیز ممکن است داده افشا کنند. |
| تغییر تنظیم و تصمیم | هویت actor، دامنهٔ اختیار، نسخهٔ قبل/بعد و زمان اثر؛ پیشنهاد LLM تغییر معتبر نیست. |

در PostgreSQL نقش کاربری نباید owner جدول، superuser یا دارای `BYPASSRLS` باشد. `FORCE ROW LEVEL SECURITY` و تست owner bypass برای جدول‌های مربوط بررسی شوند. سیاست‌های permissive با OR ترکیب می‌شوند؛ ترکیب مجوز عمومی و فردی باید آزمون منفی داشته باشد. این ویژگی‌ها در [مستندات رسمی Row Security](https://www.postgresql.org/docs/current/ddl-rowsecurity.html) توضیح داده شده‌اند.

`principal_id` و scope در context سرور ثبت می‌شوند. SQL تولیدی اجازهٔ `SET ROLE`، `set_config`، دسترسی به schema داخلی یا function دارای اثر جانبی ندارد. connection pool در پایان transaction context را پاک می‌کند. view دارای امتیاز مالک نباید RLS را دور بزند.

Interactive SQL executes only in PostgreSQL through QueryGateway. Use approved relations, trusted server identity, read-only roles, row and column controls, statement validation, and resource limits. The Agent has no direct credentials. Batch privileges must not become user-query privileges. Pool context, functions, errors, logs, caches, and exports need security checks. These controls are design contracts. They are not implemented here.

بعضی جدول‌ها مانند orders فاقد team_id هستند. دسترسی آن‌ها از `resource_scope_policy` تأییدشده می‌آید؛ به همهٔ مدیران صرفاً به علت مصرف مشترک جدول داده نمی‌شود. `T_MKT` می‌تواند policy کانال marketplace داشته باشد؛ عملیات، policy مرحلهٔ عملیاتی؛ این نگاشت‌ها باید پیش از Text-to-SQL در ADR-06 تصویب شوند. KPI سازمان به KPI واحد تغییر نام داده نمی‌شود.

در متن upload روز ۷۳، دستور پنهان برای حذف عددهای منفی و ارسال گزارش به همه وجود دارد. این متن فقط دادهٔ غیرقابل اعتماد است. parser یا LLM حق تغییر policy، مقصد، عدد یا tool از روی آن ندارد. کنترل مقصد و عدد بعد از تولید نیز مستقل اجرا می‌شود.

<a id="system-11"></a>

## ۱۱. توسعه‌پذیری و حدود نسخهٔ اول

افزودن منبع، adapter و SourceContract جدید می‌خواهد. افزودن KPI، registry entry، dependency spec و parity fixture می‌خواهد. افزودن سطح سازمان، node و policy می‌خواهد. هیچ‌یک نباید بازطراحی جریان روزانه را لازم کند.

نسخهٔ اول به message broker، Kubernetes، graph database، vector database یا چند agent خودمختار نیاز ندارد. برای این داده، جستجوی SQL و retrieval محدود متن کافی است. افزودن هر زیرساخت پس از اندازه‌گیری نیاز، ADR جدا می‌خواهد.

مرز توقف این تحویل، همین طراحی است. پیاده‌سازی، نصب package، تغییر dataset، تغییر SQL، تغییر ممیزی، commit و push در این کار انجام نمی‌شود.
