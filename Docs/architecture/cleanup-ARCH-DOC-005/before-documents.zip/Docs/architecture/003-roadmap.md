# ARCH-001: Implementation roadmap

Document key: `003-roadmap`. Date: 2026-11-09. Time zone: `Asia/Tehran`.

Status: **Proposed roadmap; Open choices retained**. The team approves this documentation location, not a phase choice, technical mechanism or test result. Implementation and acceptance have not been demonstrated here.

This document contains phases, milestones, prerequisite questions, exit gates, the first end-to-end slice and measurement/delivery sequence. The [Registry](registry/README.md) contains ADRs, issues, risks and full acceptance criteria. Use [001](001-system-blueprint.md) and [002](002-data-architecture.md) for the system and data contracts. [004](004-reconciliation-review.md) retains historical reconciliation evidence.

No phase or execution dependency is inferred from unconfirmed traceability links. The P0 design gates below apply only to affected work. The Accepted Agent, database, publication, deterministic and human-action boundaries are not reopened.

<a id="decisions-4"></a>

## ۴. اولویت پاسخ‌های لازم

پرسش‌ها در این مرحله ثبت می‌شوند؛ این سند هیچ پیام یا درخواستی به شخص دیگری ارسال نمی‌کند.

| اولویت | پرسش | چه کاری به پاسخ وابسته است؟ |
|---|---|---|
| P0 | RAW یا DEDUP دقیق Payload برای orders؟ | اعلام parity نهایی و مقدارهای حساس به input mode. |
| P0 | closure منبع چیست و مقدار qualified پذیرفته است؟ | انتشار خروجی‌های وابسته به incident حل‌نشده. |
| P0 اجرایی | نگاشت و آزمون دسترسی مصوب بریف و access_matrix روی ردیف/ستون منابع مشترک چگونه اجرا شود؟ اصل دامنه و محدودیت دادهٔ فردی مشخص است. | عرضهٔ Text-to-SQL و drill-down پس از اثبات کنترل دسترسی؛ فقط تعارض مشخص و حل‌نشده به برگزارکننده ارجاع شود. |
| P1 | شروع گزارش M11 و ترتیب upload/question هم‌روز؟ | coverage قطعی و QA مطابق clock. |
| P1 | نگاشت suppressed/ongoing و نگاشت خروجی اعداد افزوده تأیید شود. گردکردن Canonical از قبل Requirement است. | Validation نهایی JSON و متن؛ ADR-09. |
| P1 | مرز threshold، baseline و escalation در حالت‌های مبهم؟ | آزمون‌های قطعی detection و recurrence. |

کارهای طراحی و پیاده‌سازی آینده که مستقل از این پاسخ‌ها هستند، مانند source archive، snapshot و حفظ raw، می‌توانند پس از تأیید معماری جلو بروند. پاسخ‌ندادن به P0 نباید با انتخاب پنهانی business rule جبران شود.

<a id="decisions-6"></a>

## ۶. مسیر مرحله‌ای پیاده‌سازی پس از بازبینی

زمان‌ها برآورد تقویمی قطعی نیستند. مراحل با خروجی قابل بررسی و شرط خروج تعریف شده‌اند. برنامهٔ نسبی سه‌هفته‌ای بریف را می‌توان پس از شناخت ظرفیت تیم بر این مراحل منطبق کرد.

| مرحله | کار لازم | خروجی قابل بررسی | شرط خروج |
|---|---|---|---|
| P0: بازبینی معماری | بازبینی هر چهار سند شماره‌دار و قراردادهای وابسته، تعیین مالک ADRها و ثبت EvaluationProfile | تصمیم‌های پذیرفته یا ردشده و پرسش‌های پذیرش | Scope و مرزهای امنیت و مرجع روشن باشد؛ پیاده‌سازی فقط بعد از این مرحله. |
| P1: ستون فقرات داده | Archive، بررسی Manifest، Adapter، Data Lineage، Snapshot و ساعت سازمان و تنظیمات | Replay قابل تکرار تا یک Cutoff، با وضعیت منبع | Retry بی‌اثر، منابع محفوظ، بدون نشت آینده و منبع غایب قابل مشاهده. |
| P2: یک روز کامل | همهٔ ۵۵ KPI، Query Registry، یک چرخه Signal و Evidence و گزارش، QA محدود و RLS | صبح ۶۲ برای ۱۰ مدیر پایه، JSON و متن معتبر، Log هزینه و زمان | عددها برابر مرجع، Scope صحیح، بسته اتمی هر مدیر؛ انتشار مستقل و پوشش روز؛ سیاست‌های نامصوب صریح باشند. |
| P3: تاریخچه و Workflow | سه Workflow، Suppression و تشدید، بازبیان و تصمیم‌ها | اتاق کنترل با شواهد پرونده و مرحله و تاریخچه | آزمون‌های داده دیررس، اصلاح و بازگشایی و زمان‌بندی مدیر قبول شوند. |
| P4: Replay و تعامل | صبح ۶۲ تا ۹۱، همه ورودی‌های S07، تغییر سازمان و Dashboard | گزارش‌ها و ۱۶ QA با Manifest اجرا | پوشش بر اساس فهرست فعال مصوب؛ آزمون‌های Schema و امنیت موفق باشند. |
| P5: پذیرش و بسته | مقاومت در برابر خطا، Fixtureهای مشابه داده پنهان، Benchmark، Restore و بسته اجرایی | دستور واحد Docker، راهنمای تنظیمات، گزارش پذیرش و هزینه | بدون تغییر کد روی Data Root جدید اجرا شود؛ همه آزمون‌های پذیرش لازم موفق باشند. |

Milestone یک روز کامل P2 شامل همه محتوای الزامی گزارش، مشخصات نمودار، کارت تصمیم در موارد لازم، خلاصه سه Workflow، خروجی‌های متناظر JSON و پوشش مدیران فعال است. نبود هرکدام، Milestone را ناقص می‌کند. P3 عمق تاریخی و پوشش حالت‌های مرزی را اضافه می‌کند و نبود خروجی الزامی P2 را توجیه نمی‌کند. Roadmap دارای وضعیت Proposed است و شواهد کار تکمیل‌شده یا ظرفیت ثابت تیم نیست.

The P2/P3 scope remains Open in [REG-ISS-001](registry/open-issues-registry.md#reg-iss-001). Its full original alternatives, source pages and closure conditions are retained there. No phase choice is made by this structural task.

The complete P5 delivery supplement is retained as [the AT-19 delivery checklist](registry/acceptance-register.md#delivery-checklist). It includes all required UI, source-history, guide, cost and Demo Day items. The phase table and delivery gate remain Proposed as originally stated.

در هر مرحله، CSVهای audit به برنامهٔ تولیدی تبدیل یا به‌عنوان lookup پاسخ استفاده نمی‌شوند. fixtureهای آن‌ها فقط oracle آزمون توسعه‌اند. مسیر runtime فقط source، config و ورودی مجاز مدیر را می‌خواند.

### ۶.۱. کمترین مسیر سرتاسری قابل بررسی

پیش از تکمیل P2، یک slice کوچک چنین ساخته شود:

۱. ورودی‌های تاریخی لازم تا drop 061 با manifest و lineage دریافت شوند؛ دیگر dropها برای job قابل دسترسی نباشند.

2. مقدار `K_RSP_FRT_MED` و `K_RSP_TICKETS` با تبدیل‌های مصوب PostgreSQL محاسبه شود. اگر FRT واحد یا سازمان نمایش داده می‌شود، از شناسه Canonical و تبدیل مصوب همان سطح استفاده شود. KPI تیم با برچسب دیگر عرضه نشود.

۳. یک rule قطعی، یک evidence query برای شکست دسته و یک گزارش فارسی M09 ساخته شود. اگر شواهد علت کافی نیست، علت اختراع نشود. خروجی با schema، مقدار و scope بررسی شود.

۴. یک پرسش مجاز M09 و یک درخواست نامجاز برای دادهٔ تیم دیگر اجرا شود. در آزمون، هیچ دادهٔ نامجاز حتی در ورودی LLM ظاهر نشود.

۵. اجرای همان job دوباره، receipt و نتیجهٔ یکسان بدهد. hash منابع تغییر نکند.

این slice، محصول کامل یا پذیرش ۱۰ گزارش نیست. **نخستین milestone قابل ارائه، پایان P2 است: یک روز کامل با ۵۵ تعریف و ۱۰ گزارش پایه.** سپس همین مسیر روی روز دارای منبع غایب اجرا شود. مقیاس‌دادن UI پیش از این شواهد ارزش کمتری دارد.

<a id="decisions-8"></a>

## ۸. اندازه‌گیری عملکرد و هزینه

در هر روز، زمان واقعی سپری‌شده مراحل ingest، snapshot، facts، KPI، signal، workflow، evidence، LLM و validation ثبت شود. زمان bootstrap روزهای۱ تا۶۰ جدا از زمان هر روز ارزیابی گزارش شود. برای روز کامل، تعداد مدیر واقعی، تعداد پرسش و cache state ثبت شوند.

برای هر فراخوانی مدل، `day, purpose, model_version, input_tokens, output_tokens, cached_tokens, price_version, reserved_cost, actual_cost, retry_of` نگهداری شود. ledger روز با run receipt آشتی داده شود. نرخ ثابتِ بدون تاریخ یا تخمین LLM از هزینه پذیرفته نیست.

گزارش benchmark شامل همهٔ ۳۰ روز، بیشینه، میانه و توزیع زمان باشد. حد پذیرش هر روز کنترل می‌شود؛ میانگین خوب شکست یک روز را پنهان نمی‌کند. مصرف حافظه و حجم archive/snapshot نیز ثبت شود. هدف عددی برای این دو پس از baseline سخت‌افزار تعیین شود.

برای صحت، آمار زیر لازم است: تعداد تعریف و سری، شکست SQL، اختلاف عددی، اختلاف در نبود ردیف، امتناع به دلیل Scope، نشت کشف‌شده، پوشش گزارش، شکست Schema، مسئله باز و تعداد suppressed/escalated. این آمار نباید به سهمیه مصنوعی تعداد Signal تبدیل شود.

تفکیک شمارش با برچسب `Already Covered`: `KPI Definition` تعریف ثبت‌شده در Dictionary است؛ `KPI Series` سری مشخص با Entity و Dimension؛ `KPI Observation` مقدار آن سری در تاریخ و Snapshot معین است. Grain مشاهده و هویت سری در [سند 002، بخش ۲](002-data-architecture.md#data-2) ثبت شده‌اند. فایل `dataset/config/kpi_dictionary.csv` دارای ۵۵ تعریف با شناسه یکتا است. حدود ۱۵۰ در بریف صفحه ۱ تخمین است، نه Acceptance Threshold. عدد حدود ۷۰ خروجی، گزارش بررسی قبلی تیم در درخواست این بازبینی است و با برچسب `Evidence Pending` ثبت می‌شود؛ خروجی محاسباتی قابل بازرسی برای تأیید آن ارائه نشده است. بسته‌شدن این مورد به فهرست سری‌ها با Definition، Entity، Dimension، تاریخ، Snapshot و Query و روش شمارش بازتولیدپذیر نیاز دارد؛ AT-02 صحت تعریف و AT-10 ردیابی را کنترل می‌کنند. Breakdown شهر، کانال یا محصول فقط با منبع و Dimension و Query پشتیبان معتبر است؛ Ad hoc Query بدون قرارداد، Canonical KPI Definition محسوب نمی‌شود. برای رسیدن به ۱۵۰، KPI یا Dimension ساخته نشود و تعداد هدف جدیدی انتخاب نشود.

<a id="execution-gates"></a>

## Execution gate context retained from the former Decision Log

پیاده‌سازی خارج از این Task باقی می‌ماند. پیش از شروع پیاده‌سازی محصول، انتخاب‌های طراحی P0 تحت اختیار تیم بسته شوند یا سیاست‌های موقت نام‌گذاری‌شده صریحاً تصویب شوند. پرسش‌های پذیرش بیرونی می‌توانند حین ایجاد ساختار اولیه مجاز پیگیری شوند، اما نتیجه متأثر را نمی‌توان پذیرفته‌شده نامید. تصمیم‌های Accepted درباره Agent، موتور و انتشار به جلسه انتخاب مجدد نیاز ندارند.

## Governance and delivery navigation

- [Architecture decisions](registry/decisions-registry.md).
- [Open choices and missing evidence](registry/open-issues-registry.md).
- [Risk controls](registry/risk-register.md).
- [All 30 acceptance tests and full supplemental criteria](registry/acceptance-register.md).
- [Historical verification statement from former 003](004-reconciliation-review.md#decisions-9).

The AT-26 three-level matrix and R1-R8 acceptance cases remain mandatory where the source requires them. Monthly board summary remains optional. Reference definitions and all original numerical limits remain unchanged. A document check is not product acceptance.
