# Risk Register

Documentation location: team-designated governance record. State: **Draft / Pending Review**. The full source records and criteria below are readable Markdown. English text is an index. The structural approval changes no decision, source rule, risk assessment or acceptance result.

State: **Draft / Pending Review**.

Severity: **Not Assessed** for every record. The sources supply no risk scoring method. Audit finding severity is not a risk score.

Control state: **Evidence Pending / Not Executed**. Source requirements remain requirements. Engineering controls remain Proposed unless the source explicitly approves them. No control effectiveness is claimed.

The two section-5 SQL translation/oracle risks form one main record. Their two source rows remain below. Other distinct effects stay separate.

<a id="reg-rsk-001"></a>

## REG-RSK-001: Future data exposure

Cause: Facts or preloaded files can include knowledge beyond the cutoff.

Consequence: A historical report can look correct but be invalid.

Control: Filter before projection; use future-data injection fixtures and snapshot hashes.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](risk-register.md#decisions-5).

Related ADR / DL / AT: ADR-08, DL-10, AT-03.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


### Full source record and conditions

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| نشت آینده از fact یا فایل preloadشده | گزارش تاریخی ظاهراً درست ولی غیرقابل قبول | cutoff قبل از projection؛ آزمون تزریق داده آینده؛ snapshot hash. |



<a id="reg-rsk-002"></a>

## REG-RSK-002: Unclear input grain

Cause: RAW and DEDUP can feed different populations to joins.

Consequence: Canonical values can differ from evaluator results.

Control: Keep separate modes and obtain the official input answer.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](risk-register.md#decisions-5).

Related ADR / DL / AT: ADR-02, DL-02, AT-02, AT-05.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


### Full source record and conditions

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| input grain نامشخص | عدد مرجع متفاوت با evaluator | دو policy جدا و پاسخ رسمی ADR-02. |



<a id="reg-rsk-003"></a>

## REG-RSK-003: Manifest mistaken for completeness

Cause: A manifest can omit a missing source.

Consequence: False zero values or early incident closure can be reported.

Control: Use expected-source contracts, separate closure and missing/empty tests.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](risk-register.md#decisions-5).

Related ADR / DL / AT: ADR-04, DL-03, AT-04, AT-23.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


### Full source record and conditions

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| اعتماد به manifest برای completeness | صفر جعلی یا رفع incident زودهنگام | expected source registry، closure جدا و آزمون missing/empty. |



<a id="reg-rsk-004"></a>

## REG-RSK-004: SQL translation drift

Cause: PostgreSQL and the reference oracle can differ in time, types, rounding and selected row sets.

Consequence: Even a hundredth-hour difference can break acceptance.

Control: Use one PostgreSQL product path, versioned translations, original hashes and an independent reference oracle.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](risk-register.md#decisions-5).

Related ADR / DL / AT: ADR-01, DL-01, AT-02, AT-05.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


### Full source record and conditions

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| تغییر محاسبات در تبدیل SQL | اختلاف حتی در صدم ساعت | Test Oracle مرجع SQLite، نسخه تبدیل PostgreSQL و هم‌ارزی در مرزها. |
| نگهداری تبدیل و Oracle مرجع | تفاوت رفتار SQL می‌تواند مقادیر گرد‌شده یا مجموعه ردیف‌ها را تغییر دهد. | یک مسیر محصول PostgreSQL؛ Test Oracle نسخه‌دار مستقل و رسیدهای تبدیل. |



<a id="reg-rsk-005"></a>

## REG-RSK-005: Raw query or cache exposure

Cause: Results, query context, cache or logs can carry another manager scope.

Consequence: Restricted data can reach a manager or the LLM.

Control: Apply RLS, scoped cache keys, separate worker identity and adversarial query tests.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](risk-register.md#decisions-5).

Related ADR / DL / AT: ADR-06, DL-06, AT-06, AT-13.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


### Full source record and conditions

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| دسترسی خام در query یا cache | نشت به مدیر دیگر یا LLM | RLS، scope در cache key، worker جدا و مجموعه آزمون Query خصمانه. |



<a id="reg-rsk-006"></a>

## REG-RSK-006: Historical correction mistaken for a business Signal

Cause: A knowledge revision can change an old value.

Consequence: False alerts and escalation can follow.

Control: Keep knowledge_revision and incident links separate from business eligibility.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](risk-register.md#decisions-5).

Related ADR / DL / AT: ADR-04, ADR-07, DL-03, DL-09, AT-04, AT-05, AT-24.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


### Full source record and conditions

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| اصلاح تاریخی به شکل سیگنال تجاری | هشدار و تشدید نادرست | `knowledge_revision` جدا و incident linkage. |



<a id="reg-rsk-007"></a>

## REG-RSK-007: Hardcoded development events

Cause: Runtime logic can depend on known incident dates or IDs.

Consequence: The product can fail on hidden data.

Control: Vary dates, identifiers, dimensions and delivery order in separate fixtures.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](risk-register.md#decisions-5).

Related ADR / DL / AT: ADR-08, DL-16, AT-19.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


### Full source record and conditions

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| hardcode حوادث توسعه | شکست روی دادهٔ پنهان | تغییر تاریخ، شناسه، dimension و ترتیب delivery در fixtureهای مصنوعی. |



<a id="reg-rsk-008"></a>

## REG-RSK-008: Recurrence without recipient state

Cause: One state shared among recipients can erase or repeat their history.

Consequence: The owner can miss a warning or a parent can receive a duplicate.

Control: Keep episode and recipient state separate and test the escalation chain.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](risk-register.md#decisions-5).

Related ADR / DL / AT: ADR-07, DL-09, AT-08, AT-24.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


### Full source record and conditions

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| قاعدهٔ تکرار بدون recipient state | حذف هشدار مالک یا تکرار برای والد | state جدا برای episode و recipient؛ تست escalation chain. |



<a id="reg-rsk-009"></a>

## REG-RSK-009: Unsupported causes

Cause: Two dependent measurements can look like two independent witnesses.

Consequence: A fabricated cause can receive high confidence.

Control: Use lineage-aware evidence review and deterministic validation outside the LLM.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](risk-register.md#decisions-5).

Related ADR / DL / AT: ADR-09, DL-11, DL-18, AT-10.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


### Full source record and conditions

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| نبود دو شاهد مستقل | علت ساختگی با confidence بالا | lineage groups و validator مستقل از LLM. |



<a id="reg-rsk-010"></a>

## REG-RSK-010: Causal claim from a simulated decision

Cause: A decision record and later change can be mistaken for proof of execution or effect.

Consequence: The report can attribute an effect without evidence.

Control: Compare observations with calendar context and stated limits; preserve fixed replay data.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](risk-register.md#decisions-5).

Related ADR / DL / AT: ADR-17, DL-12, AT-14, AT-29.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


### Full source record and conditions

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| برداشت علّی از تصمیم شبیه‌سازی‌شده | نسبت‌دادن اثر بدون مدرک | قبل و بعد با کنترل تقویم و محدودیت؛ عدم تغییر دادهٔ replay پس از تصمیم. |



<a id="reg-rsk-011"></a>

## REG-RSK-011: Growth in managers or questions

Cause: More reports, QA and retries consume shared daily resources.

Consequence: Time or cost limits can fail.

Control: Consider template writing, reservations and authorized cache; measure the worst day.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](risk-register.md#decisions-5).

Related ADR / DL / AT: ADR-10, ADR-13, ADR-14, DL-13, DL-14, AT-17, AT-18, AT-28.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


### Full source record and conditions

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| رشد تعداد مدیران یا سؤالات | شکست زمان یا هزینه | template writer، reservation، cache مجاز و اندازه‌گیری بدترین روز. |



<a id="reg-rsk-012"></a>

## REG-RSK-012: Current lifecycle replaces reference facts

Cause: An operational state can be substituted for canonical MIN/MAX selections.

Consequence: Backlog or SLA can change without source authority.

Control: Keep operational projections separate and retain the formula hash.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](risk-register.md#decisions-5).

Related ADR / DL / AT: ADR-11, DL-05, AT-02, AT-05.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


### Full source record and conditions

| ریسک | اثر | اقدام و نشانهٔ کنترل |
|---|---|---|
| وضعیت فعلی entity جایگزین reference شود | تغییر backlog/SLA بدون مجوز | projection عملیاتی جدا، formula hash ثابت. |



<a id="reg-rsk-013"></a>

## REG-RSK-013: Prompt injection from operational text

Cause: A ticket or upload contains instructions.

Consequence: Policy, numbers, recipients or actions can be changed.

Control: Treat text as untrusted data and check destination, number and tool authority independently.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](../001-system-blueprint.md#system-10).

Related ADR / DL / AT: ADR-06, ADR-16, ADR-17, DL-06, AT-13, AT-22.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.

<a id="reg-rsk-014"></a>

## REG-RSK-014: Premature attachment evidence

Cause: A question can precede receipt or readiness of its attachment.

Consequence: The answer can use evidence unavailable at question time.

Control: Record attachment dependency, receipt and readiness; use clarification/data-unavailable when needed.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](../001-system-blueprint.md#system-5).

Related ADR / DL / AT: ADR-08, ADR-16, DL-10, AT-03, AT-22.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.

<a id="reg-rsk-015"></a>

## REG-RSK-015: Incomplete day mistaken for success

Cause: A required manager job can fail before a draft exists.

Consequence: Successful independent packages can hide missing daily coverage.

Control: Track job/export/day outcomes separately and record failure even without a draft.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](../002-data-architecture.md#data-11).

Related ADR / DL / AT: ADR-14, DL-13, AT-15, AT-21, AT-28.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.

<a id="reg-rsk-016"></a>

## REG-RSK-016: Unapproved status serialization

Cause: The brief uses suppressed and the schema uses ongoing.

Consequence: Output can violate schema or silently lose suppression meaning.

Control: Preserve history and obtain a valid output mapping without changing the source schema.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](../001-system-blueprint.md#system-9).

Related ADR / DL / AT: ADR-09, DL-11, AT-11, AT-30.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.

<a id="reg-rsk-017"></a>

## REG-RSK-017: Ambiguous correction precedence

Cause: Equal-rank conflicting corrections have no supplied secondary order.

Consequence: An arbitrary payload can be reported as valid.

Control: Record conflict; obtain source precedence or review quarantine. No current correction tie is claimed.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](../002-data-architecture.md#data-3).

Related ADR / DL / AT: ADR-11, DL-05, AT-05.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.

<a id="reg-rsk-018"></a>

## REG-RSK-018: Unrecoverable history

Cause: Inconsistent archive/database backup or early retention removal can break replay.

Consequence: Historical reports and their source evidence cannot be reconstructed.

Control: Approve retention/backup policy and test file hashes, snapshot rebuild and sample reports after restore.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](../002-data-architecture.md#data-11).

Related ADR / DL / AT: ADR-12, DL-15, AT-19.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.

<a id="reg-rsk-019"></a>

## REG-RSK-019: Small-group or free-text identification

Cause: Aggregate capacity or title/blocker text can identify a person.

Consequence: A higher manager can receive restricted individual or leave data.

Control: Review redaction, purpose and group-size controls; test derived claims and text paths.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](../001-system-blueprint.md#system-10).

Related ADR / DL / AT: ADR-06, DL-06, DL-07, AT-06, AT-10.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.

<a id="reg-rsk-020"></a>

## REG-RSK-020: Reference KPI overwritten by management change

Cause: Configurable formula/owner/target changes can be confused with changes to the fixed 55 reference definitions.

Consequence: Canonical evaluation and previous versions can change without authority.

Control: Obtain the DL-19 lifecycle policy; preserve the reference and separately test add/change, effect time and rollback.

Control status: **Evidence Pending**. The product control is not executed.

Severity: **Not Assessed**.

Source Evidence: [Source](open-issues-registry.md#decision-log).

Related ADR / DL / AT: ADR-01, ADR-06, ADR-08, DL-19, AT-27, AT-29.

Evidence needed: The applicable source/policy answer, approved control contract and actual receipts for the related tests. Inspect both positive and negative cases before any risk reduction claim.


<a id="decisions-5"></a>

## ۵. ریسک‌های عمده و اقدام کنترل

The original 13 source risk rows are retained in the 20 risk records above. The two SQL/oracle rows share REG-RSK-004. No control is implemented and every severity remains Not Assessed.
