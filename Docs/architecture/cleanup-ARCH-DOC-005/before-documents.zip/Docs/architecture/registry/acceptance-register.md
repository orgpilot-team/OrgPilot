# Acceptance Register

Documentation location: team-designated governance record. State: **Draft / Pending Review**. The full source records and criteria below are readable Markdown. English text is an index. The structural approval changes no decision, source rule, risk assessment or acceptance result.

State: **Draft / Pending Review**.

All 30 tests have execution status **Planned / Not Executed** and evidence state **Evidence Pending**. No product execution receipt is supplied for these gates. Earlier dataset audits and document checks do not make a product test pass.

The source criteria are retained in full under each test. Common supplements below are part of the linked tests. They are not new tests. Source classifications describe authority; they are separate from execution status.

<a id="at-01"></a>

## AT-01: Intake and idempotency

Goal: Intake and idempotency.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief13-14; README manifest/source rules.

Unapproved mechanism or gap: Idempotent receipt mechanism Proposed.

Required evidence and acceptance checks: Manifest/actual/expected comparisons, unchanged hashes, retry receipts, independent-source extension diff and regression receipts.

Related decisions / issues: See the requirement and source edges in the matrix..

Source Evidence: [AT-01](acceptance-register.md#at-01); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-01 | دریافت و Idempotency | manifest/actual/expected مستقل سنجیده شوند؛ retry هیچ occurrence یا report اضافی نسازد؛ source hash تغییر نکند. افزودن Source System مستقل با SourceContract، Registry و Adapter جدید، بدون بازطراحی یا تغییر هسته، طبق معیار تکمیلی زیر آزموده شود. |



<a id="at-02"></a>

## AT-02: PostgreSQL equivalence

Goal: PostgreSQL equivalence.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. KPI dictionary all rows; reference views; brief16.

Unapproved mechanism or gap: PostgreSQL translation strategy Proposed; engine Accepted.

Required evidence and acceptance checks: All 55 source/translated SQL hashes, engine/type/input-policy versions and complete result comparisons for every replay morning and edge case; zero tolerance after canonical rounding.

Related decisions / issues: ADR-01, ADR-09, DL-01, DL-02, DL-16, DL-17, REG-ISS-005.

Source Evidence: [AT-02](acceptance-register.md#at-02); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-02 | هم‌ارزی PostgreSQL | همه 55 شناسه؛ Hashهای بدون تغییر SQL و View اصلی به‌همراه Hashهای SQL تبدیل‌شده؛ ورودی‌ها و سیاست یکسان؛ کلیدها، Dimensionها، وجود ردیف، NULL و مقادیر گرد‌شده مطابق مرجع برای همه صبح‌های Replay و حالت‌های مرزی برابر باشند. پس از گردکردن تلرانس وجود ندارد. |



<a id="at-03"></a>

## AT-03: Cutoff and replay

Goal: Cutoff and replay.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. README replay/input cutoff; brief14.

Unapproved mechanism or gap: Snapshot/commit implementation Proposed.

Required evidence and acceptance checks: Snapshots and query receipts for mornings 62-91, D-1 cutoffs, future-data negative cases and initial CRM history.

Related decisions / issues: ADR-01, ADR-16, DL-01, DL-04, DL-10, REG-ISS-009.

Source Evidence: [AT-03](acceptance-register.md#at-03); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-03 | Cutoff و Replay | صبح ۶۲ تا ۹۱؛ drop≤R-1؛ سؤال D با drop≤D-1؛ وجود ردیف‌های آینده در Storage ممکن، ولی نمایش آن‌ها در گزارش ممنوع است؛ تاریخچه اولیه CRM مجاز. |



<a id="at-04"></a>

## AT-04: Missing, empty and backfill

Goal: Missing, empty and backfill.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. README unavailable values; brief13-14,17.

Unapproved mechanism or gap: Closure/publication policy Open.

Required evidence and acceptance checks: Missing/empty/backfill reports with null and issue links; separate 32 support changes from two payment changes.

Related decisions / issues: DL-03, REG-ISS-004.

Source Evidence: [AT-04](acceptance-register.md#at-04); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-04 | missing/empty/backfill | منبع غایب در گزارش اعلام شود؛ NULL با issue؛ empty با missing یکی نشود؛ ۳۲ تغییر support و دو تغییر payment جدا توضیح داده شوند. |



<a id="at-05"></a>

## AT-05: Duplicates, schema and correction

Goal: Duplicates, schema and correction.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief14,17; observed aliases/correction; README.

Unapproved mechanism or gap: RAW/DEDUP and correction tie Open.

Required evidence and acceptance checks: Separate RAW/DEDUP outputs, header-alias receipts and L02045 correction eligibility from morning 71; no actual-report counterfactual.

Related decisions / issues: ADR-01, DL-01, DL-02, DL-04, DL-05, REG-ISS-004.

Source Evidence: [AT-05](acceptance-register.md#at-05); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-05 | duplicate/schema/correction | RAW/DEDUP قابل تفکیک؛ نام‌های جایگزین Schema بر اساس Header؛ اصلاح L02045 فقط از صبح۷۱؛ counterfactual وارد گزارش واقعی نشود. |



<a id="at-06"></a>

## AT-06: Authorization

Goal: Authorization.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Access matrix; brief5,10,12-13.

Unapproved mechanism or gap: Physical roles/projections Proposed; exact fields Open.

Required evidence and acceptance checks: Positive and negative access receipts in all three levels, including result, prompt, cache, export, log, errors and source-row drill-down.

Related decisions / issues: DL-06, DL-07, DL-15.

Source Evidence: [AT-06](acceptance-register.md#at-06); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-06 | مجوزسنجی | صفر نشت در سه سطح، در result، prompt، cache، export، logs و خطا؛ دادهٔ فردی فقط با direct-team و purpose مجاز. |



<a id="at-07"></a>

## AT-07: Organization and configuration changes

Goal: Organization and configuration changes.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief13,17; README; IN05/IN06.

Unapproved mechanism or gap: M11 precedence/activation authority Open.

Required evidence and acceptance checks: Metadata revisions, approved clock, IN06 report-79 effect, cache/grant revisions and added-team/level tests.

Related decisions / issues: DL-10.

Source Evidence: [AT-07](acceptance-register.md#at-07); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-07 | تغییر سازمان و تنظیمات | تیم/سطح جدید از metadata و clock؛ بدون تغییر کد؛ آستانهٔ IN06 از گزارش۷۹؛ cache و grant با revision سازگار. |



<a id="at-08"></a>

## AT-08: Recurrence and escalation

Goal: Recurrence and escalation.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. R1-R8; brief7-8.

Unapproved mechanism or gap: Ranking/grouping/reset mechanism Proposed/Open.

Required evidence and acceptance checks: Per-recipient history, rule/owner versions, <10% recurrence cases, escalation reasons, max-five outputs and Candidate/Open/Published mapping.

Related decisions / issues: ADR-15, DL-08, DL-09, DL-18, REG-ISS-004.

Source Evidence: [AT-08](acceptance-register.md#at-08); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-08 | تکرار و تشدید | کمتر از۱۰٪ تغییر به همان مخاطب new نسازد؛ reason و history تشدید حاضر؛ owner و rule version درست؛ حداکثر پنج مورد. آزمون‌های DQ در AT-24 اجرا شوند؛ نگاشت Candidate Signal، Open Item و Published Brief Item برای موارد خارج از پنج مورد، طبق DL-18 همچنان Open است. |



<a id="at-09"></a>

## AT-09: Event detection

Goal: Event detection.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief16 discovery definition.

Unapproved mechanism or gap: Official hidden labels unavailable.

Required evidence and acceptance checks: Official labeled event results: correct owner report, within 24 hours, correct KPI/entity and label-consistent cause; at least 90%. Hidden labels are absent.

Related decisions / issues: DL-09, DL-16.

Source Evidence: [AT-09](acceptance-register.md#at-09); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-09 | کشف رویداد | معیار رسمی: حضور در گزارش مالک، ظرف۲۴ ساعت، KPI/entity درست و علت سازگار با label مرجع؛ حداقل۹۰٪ روی پاسخ رسمی. |



<a id="at-10"></a>

## AT-10: Evidence support

Goal: Evidence support.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief9-10,13,16.

Unapproved mechanism or gap: Independence/scoring algorithm Proposed.

Required evidence and acceptance checks: Actual QueryRun/Snapshot references for every number and cause; reviewed evidence independence, positive/negative shared-population cases and full number-to-file lineage.

Related decisions / issues: ADR-09, DL-07, DL-11, REG-ISS-005.

Source Evidence: [AT-10](acceptance-register.md#at-10); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-10 | اتکا به شواهد | هر عدد Query و Snapshot داشته باشد؛ هر علت منتشرشده حداقل دو شاهد مستقل داشته باشد. صرف دو Evidence Group کافی نیست. آزمون مثبت و منفی استقلال و زنجیره کامل Data Lineage طبق معیارهای تکمیلی زیر اجرا شوند؛ فرضیه از Fact جدا و داده ناکافی به علت قطعی تبدیل نشود. |



<a id="at-11"></a>

## AT-11: Output and user interfaces

Goal: Output and user interfaces.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief10-12,15; output schemas.

Unapproved mechanism or gap: Internal complete content mapping Open.

Required evidence and acceptance checks: Brief/QA schema receipts; authenticated Persian RTL assistant and role-dashboard sessions at three levels; authorized drill-down, decision/referral history and mentioned_staff_ids checks.

Related decisions / issues: ADR-09, ADR-14, DL-11, REG-ISS-006.

Source Evidence: [AT-11](acceptance-register.md#at-11); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-11 | خروجی و UI | brief و QA مطابق schema؛ فارسی RTL؛ maxItems=5؛ لینک عدد تا query مجاز؛ همهٔ کارکنان نام‌برده در mentioned_staff_ids و scope کنترل شوند. مسیر سرتاسری دستیار گفت‌وگومحور و Dashboard سطح‌بندی‌شده، با هویت هر سه سطح، پاسخ، Drill-down مجاز و ثبت تصمیم یا ارجاع آزموده شود؛ ماتریس محتوای AT-26 و کنترل عدد AT-30 اعمال شوند. |



<a id="at-12"></a>

## AT-12: Three Workflows

Goal: Three Workflows.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Workflow stages; canonical workflow SQL; brief5-6,16.

Unapproved mechanism or gap: Stage owner mapping Open.

Required evidence and acceptance checks: Case/stage evidence for three Workflows, supplied SLA versus canonical KPI checks, repeats/open/unknown cases, M01 ownership, approved routing and executive-only Persian RTL control-room sessions.

Related decisions / issues: ADR-15, DL-08, REG-ISS-001, REG-ISS-003, REG-ISS-006.

Source Evidence: [AT-12](acceptance-register.md#at-12); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-12 | سه Workflow | ارتباط معتبر پرونده‌ها؛ SLA مراحل عرضه‌شده و SQL مستقل KPI؛ پرونده‌های تکراری، باز و نامعلوم؛ مالکیت سرتاسری M01؛ نگاشت و ارجاع مصوب مرحله؛ مالک نامعلوم و عامل از نوع واحد به مالک تیم حدسی تبدیل نشوند. مسیر سرتاسری UI اتاق کنترل مدیر ارشد، فارسی RTL، وضعیت هر سه Workflow، درصد SLA و گلوگاه مراحل تا Query و Evidence مجاز آزموده شود؛ ورود مدیر کل و سرپرست به این اتاق کنترل رد شود. |



<a id="at-13"></a>

## AT-13: Prompt injection

Goal: Prompt injection.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief13,17; injected operational upload.

Unapproved mechanism or gap: Enforcement mechanism Proposed.

Required evidence and acceptance checks: Injected tickets/uploads/header/filename cases with unchanged permissions, numbers, recipients and action boundaries.

Related decisions / issues: ADR-16, REG-ISS-009.

Source Evidence: [AT-13](acceptance-register.md#at-13); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-13 | Prompt Injection | دستور داخل ticket/upload هیچ policy، query permission، عدد، مقصد یا action را تغییر ندهد. |



<a id="at-14"></a>

## AT-14: Decision and action

Goal: Decision and action.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief11-12,15; scripted decisions.

Unapproved mechanism or gap: Execution confirmation fields Open.

Required evidence and acceptance checks: Valid-decision/draft linkage, before/after evidence, valid effect_direction, versioned deadlines/status/reminders and no organizational send/execute call.

Related decisions / issues: ADR-17, DL-12.

Source Evidence: [AT-14](acceptance-register.md#at-14); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-14 | تصمیم و اقدام | بدون تصمیم معتبر، draft اجرایی ایجاد/منتسب نشود؛ هیچ ارسال یا جابه‌جایی خودکار؛ effect_direction یکی از enum و شواهد قبل/بعد موجود. یادآوری سررسید و تاریخچه نسخه‌دار Deadline و وضعیت اقدام طبق معیار تکمیلی زیر و AT-29 آزموده شوند؛ Draft یا Reminder، اجرای اقدام نیست. |



<a id="at-15"></a>

## AT-15: Daily report coverage

Goal: Daily report coverage.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. README active roster; brief16.

Unapproved mechanism or gap: Independent publication Accepted; M11 precedence Open.

Required evidence and acceptance checks: The approved active roster for every morning, one valid package per required manager, no duplicate retry package, incomplete failed days and role-content checks.

Related decisions / issues: ADR-14, DL-10, DL-13, REG-ISS-001.

Source Evidence: [AT-15](acceptance-register.md#at-15); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-15 | پوشش روزانه | دقیقاً فهرست مدیران فعال مصوب، هر صبح گزارش پایه معتبر داشته باشد. انتشار مستقل مجاز است. هر بسته الزامی غایب یا ناموفق، روز را ناقص نگه می‌دارد. Retry پوشش تکراری ایجاد نکند. پوشش تعداد مدیران جای کنترل محتوای اختصاصی هر سطح در ماتریس AT-26 را نمی‌گیرد. |



<a id="at-16"></a>

## AT-16: Manager QA

Goal: Manager QA.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief17; scripted questions.

Unapproved mechanism or gap: 16 fixtures are not about60 official questions.

Required evidence and acceptance checks: All 16 supplied manager questions with clock/scope/definition/refusal receipts, plus official evaluator results of at least 85%; supplied samples alone cannot prove that score.

Related decisions / issues: DL-16, REG-ISS-002.

Source Evidence: [AT-16](acceptance-register.md#at-16); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-16 | QA | تمام۱۶ پرسش فعلی با clock، scope، تعریف و refusal مناسب؛ دقت رسمی حداقل۸۵٪ روی مجموعهٔ ارزیاب، نه فقط نمونه‌های توسعه. |



<a id="at-17"></a>

## AT-17: Performance

Goal: Performance.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief14,19.

Unapproved mechanism or gap: Hardware/final profile missing; no benchmark.

Required evidence and acceptance checks: Every day ingest-to-JSON/validation elapsed time on the declared machine, at most 15 minutes, simulated publication before 07:30; warm/cold recorded separately.

Related decisions / issues: ADR-01, DL-01, DL-14, DL-16.

Source Evidence: [AT-17](acceptance-register.md#at-17); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-17 | عملکرد | هر روز شامل ingest تا JSON و validation، حداکثر۱۵ دقیقه روی ماشین اعلامی؛ گزارش پیش از۰۷:۳۰ شبیه‌سازی‌شده؛ warm/cold جدا ثبت شوند. |



<a id="at-18"></a>

## AT-18: Cost

Goal: Cost.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief16,19.

Unapproved mechanism or gap: Reservation/rates/retry mechanism Proposed.

Required evidence and acceptance checks: Every day actual model cost at most USD 5; token, retry, cache, dated rates and reservation ledgers, including QA and repairs; controlled exhaustion outcomes.

Related decisions / issues: ADR-14, DL-14, DL-16, REG-ISS-006.

Source Evidence: [AT-18](acceptance-register.md#at-18); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-18 | هزینه | مجموع واقعی مدل در هر روز≤۵دلار؛ token، retry، cache hit، نرخ و reservation ثبت؛ اتمام بودجه نتیجه کنترل‌شده بدهد. |



<a id="at-19"></a>

## AT-19: Generalization and delivery

Goal: Generalization and delivery.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief14,18.

Unapproved mechanism or gap: Restore/restart engineering gate Proposed, not a supplied specific backup policy.

Required evidence and acceptance checks: New-root/config run without code edits, one Docker command, restart/restore receipts, no fixed incident/date IDs and the full P5 delivery inventory.

Related decisions / issues: DL-15, DL-16, REG-ISS-006.

Source Evidence: [AT-19](acceptance-register.md#at-19); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-19 | تعمیم و تحویل | data root و تنظیم جدید بدون تغییر کد؛ یک دستور Docker؛ روز و شناسه حادثه در کد ثابت نباشد؛ restart و restore موفق. شرط تکمیلی تحویل P5 و شواهد سه UI در AT-11/12 بررسی شوند. آزمون Source جدید AT-01 از آزمون Data Root جدید، تیم جدید و KPI جدید جدا بماند. |



<a id="at-20"></a>

## AT-20: One bounded Agent

Goal: One bounded Agent.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Accepted**. User request1; S16 Q01; S17 agent.

Unapproved mechanism or gap: Exact tool/time/token/step limits Open.

Required evidence and acceptance checks: One-Agent execution trace, deterministic calculation/Signal/access/final validation receipts and approved tool/token/time/cancel limits.

Related decisions / issues: ADR-13, DL-14.

Source Evidence: [AT-20](acceptance-register.md#at-20); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-20 | یک Agent با حدود مشخص | یک AI Agent تحلیل و نگارش را انجام دهد. ماژول‌های قطعی، محاسبه، Signalها، دسترسی و Validation را انجام دهند. حدود مصوب ابزار، Token، زمان و لغو اعمال شوند. Agent خودمختار اضافی وارد نشود. |



<a id="at-21"></a>

## AT-21: Failure and publication

Goal: Failure and publication.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Accepted**. User request1; S16 Q16; S17 PartialPublication.

Unapproved mechanism or gap: Atomic package mechanism and fallback Proposed.

Required evidence and acceptance checks: One pre-draft failure and one validation failure; independent once-only valid publication, paired text/JSON, visible failed required jobs, incomplete day and bounded rewrite/revalidation traces.

Related decisions / issues: ADR-14, DL-13.

Source Evidence: [AT-21](acceptance-register.md#at-21); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-21 | شکست و انتشار | یک Job مدیر پیش از Draft و Job دیگر حین Validation با شکست مواجه شوند. سایر بسته‌های معتبر یک‌بار منتشر شوند. متن و JSON هر بسته با هم ثبت شوند. Jobهای الزامی ناموفق قابل مشاهده و روز ناقص بمانند. Retry و Fallback در حدود زمان و هزینه بمانند. مسیر Validation Failure → Exact Reason → Rewrite → Revalidation طبق معیار تکمیلی زیر و AT-28 آزموده شود. |



<a id="at-22"></a>

## AT-22: Upload boundary

Goal: Upload boundary.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief3,12-14; README uploads; IN04/IN07.

Unapproved mechanism or gap: Exact format/readiness policy Open.

Required evidence and acceptance checks: Approved format list, identity/audience/receipt/readiness, parse failure and injection fixtures; no unavailable attachment evidence.

Related decisions / issues: ADR-16, DL-10, REG-ISS-009.

Source Evidence: [AT-22](acceptance-register.md#at-22); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-22 | مرز Upload | فهرست قالب مصوب، هویت، مخاطب، دریافت و آمادگی، شکست Parse و Injection آزموده شوند. اسناد عملیاتی از اسناد توسعه و Dropهای مرجع جدا بمانند. پیوست در دسترس‌نبوده وارد Evidence نشود. |



<a id="at-23"></a>

## AT-23: Dated historical context

Goal: Dated historical context.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Proposed**. S16 Q06 summary; existing S17 dated-value boundary.

Unapproved mechanism or gap: Historical display mapping/age Open; never replace current null.

Required evidence and acceptance checks: Current null plus issue and historical value with actual date/query/snapshot/unit/current authorization under an approved mapping; no substitution.

Related decisions / issues: ADR-09, DL-03.

Source Evidence: [AT-23](acceptance-register.md#at-23); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-23 | زمینه تاریخی تاریخ‌دار | مقدار جاری ناموجود همچنان null همراه با مسئله داده باشد. زمینه آخرین مقدار معتبر از تاریخ واقعی، Query، Snapshot، واحد و مجوز فعلی خود استفاده کند. مقدار قدیمی جای مقدار جاری قرار نگیرد. نگاشت خروجی باید مصوب باشد. |



<a id="at-24"></a>

## AT-24: All R1-R8 rules

Goal: All R1-R8 rules.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. escalation_rules.csv R1-R8; brief8 three checks.

Unapproved mechanism or gap: Only unspecified comparisons/samples/reset remain Open.

Required evidence and acceptance checks: Separate and combined R1-R8 cases at detection, report construction and final validation; fixed comparison/owner/history/holiday/info/Jalali-day gates and five DQ cases with positive business control.

Related decisions / issues: ADR-07, REG-ISS-004.

Source Evidence: [AT-24](acceptance-register.md#at-24); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-24 | پوشش کامل R1-R8 | هر قاعده جداگانه و در ترکیب با قواعد دیگر، هنگام تشخیص، ساخت گزارش و Validation نهایی آزموده شود. مقایسه‌های صریح، مالکیت، تاریخچه، معافیت تعطیلی، رفتار info و شرط روز شمسی حفظ شوند. حالت‌های حل‌نشده نام‌گذاری شوند؛ بی‌اعلام یکی انتخاب نشود. ارتباط DQIncident، KpiObservation و Signal Eligibility برای پنج نوع مسئله داده طبق معیار تکمیلی زیر و AT-04/05/08 آزموده شود. |



<a id="at-25"></a>

## AT-25: Every Workflow stage

Goal: Every Workflow stage.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. workflow_definitions.csv12 stages and canonical workflow SQL.

Unapproved mechanism or gap: Owner/projection details Open.

Required evidence and acceptance checks: All 12 stages with from/to events, numeric SLA versus deadline versus no-SLA, median targets, WF2 48h and separate canonical WF3 conditions; unresolved owners stay explicit.

Related decisions / issues: ADR-15, REG-ISS-001, REG-ISS-003.

Source Evidence: [AT-25](acceptance-register.md#at-25); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-25 | همه مراحل Workflow | هر 12 تعریف مرحله، نقاط ابتدا و انتها، انواع SLA و هدف‌های Median آزموده شوند. WF1.4 یک Deadline است؛ WF1.5 فاقد SLA است. WF2 با 48h و شرط‌های Canonical مربوط به WF3 جدا از مشاهده‌های مرحله حفظ شوند. مالک نامعلوم مرحله حل‌نشده بماند. |



<a id="at-26"></a>

## AT-26: Complete role report content

Goal: Complete role report content.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief5,9-12,15.

Unapproved mechanism or gap: Internal/wire content mapping Open.

Required evidence and acceptance checks: Eight Insight sections, required charts/cards/health/pending decisions/open actions/dashboard/status, plus every role-matrix cell with content/empty/missing/denied cases. Monthly board summary remains optional.

Related decisions / issues: DL-18, REG-ISS-001.

Source Evidence: [AT-26](acceptance-register.md#at-26); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-26 | محتوای کامل گزارش | هشت بخش Insight، عنوان و Target و مالک و پرسش پیشنهادی هر مورد، نوع و معیار و بازه و تفکیک و خط هدف نمودار، فیلدهای الزامی کارت تصمیم، سلامت، تصمیم‌های در انتظار، اقدام‌های باز، لینک Dashboard و وضعیت خواندن و تصمیم و ارجاع بررسی شوند. خلاصه ماهانه اختیاری می‌ماند. ماتریس اختصاصی سه سطح در ادامه، محتوای الزامی، شرطی، Empty State، Scope و موارد منفی را جدا می‌سنجد. |



<a id="at-27"></a>

## AT-27: Controlled configuration and KPI extension

Goal: Controlled configuration and KPI extension.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Brief13; README KPI extension.

Unapproved mechanism or gap: Inactive-candidate approval mechanism Proposed.

Required evidence and acceptance checks: Preserved 55 definitions; inactive candidate SQL/type/unit/scope/rollup validation, approval and versioned activation; separate add and change tests, write authorization, effect time, rollback and retained prior results.

Related decisions / issues: ADR-01, DL-19.

Source Evidence: [AT-27](acceptance-register.md#at-27); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-27 | پیکربندی کنترل‌شده و گسترش KPI | تغییرهای مجاز بدون ویرایش کد Validation شوند. 55 تعریف Canonical حفظ شوند. ثبت نامزد غیرفعال، بررسی SQL و نوع و واحد و Scope و Rollup، تصویب و فعال‌سازی نسخه‌دار با سیاست مصوب چرخه حیات آزموده شوند. اولویت‌ها نمی‌توانند Factها یا مجوزها را تغییر دهند. افزودن KPI جدید و تغییر مجاز فرمول، مالک یا مشخصات KPI موجود، دو آزمون مستقل هستند. مورد دوم به تصمیم Open در DL-19 وابسته است؛ تعریف مرجع ارزیابی و نتایج و نسخه‌های قبلی نباید بازنویسی شوند. روش تغییر، اختیار، زمان اثر و Rollback پیش از تصویب، معیار نتیجه قطعی ندارند. |



<a id="at-28"></a>

## AT-28: Parent execution grant

Goal: Parent execution grant.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Proposed**. Existing S17 F02/F05; user bounded-Agent boundary.

Unapproved mechanism or gap: Exact controller limits and cancellation product behavior Open.

Required evidence and acceptance checks: Parent/child request chain for model/tool/query/retry/upload/repair with nonresetting limits; timeout/cancel/budget and before/after-draft failure receipts. Exact limits require approval.

Related decisions / issues: See the requirement and source edges in the matrix..

Source Evidence: [AT-28](acceptance-register.md#at-28); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-28 | مجوز اجرای والد | کار مدل، ابزار، Query، Retry، پردازش Upload و Repair فرزند نمی‌تواند حدود والد را از نو تنظیم کند. Timeout، لغو، پایان بودجه و انتشار شکست پیش و پس از Draft آزموده شوند. وضعیت شکست فنی از Enumهای خروجی جدا بماند. حدود دقیق به تصویب نیاز دارند. |



<a id="at-29"></a>

## AT-29: Manager-input lifecycle

Goal: Manager-input lifecycle.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. Scripted inputs23; brief3,11-14.

Unapproved mechanism or gap: Write authority and same-day receipt precedence Open.

Required evidence and acceptance checks: All 23 authorized input events, all 16 QA files and seven non-question effects with receipt/effect/idempotency; separate close/referral fixtures, unchanged dataset and upload text not treated as a decision.

Related decisions / issues: ADR-17, DL-19.

Source Evidence: [AT-29](acceptance-register.md#at-29); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-29 | چرخه حیات ورودی مدیر | همه 23 رویداد عرضه‌شده از طریق عملیات مجاز، با زمان دریافت و اثر و Idempotency اجرا شوند. همه 16 فایل QA و هفت اثر غیرپرسشی بررسی شوند. بستن و ارجاع مجاز با Fixtureهای جدا آزموده شوند؛ داده اصلی هرگز تغییر نکند و متن Upload تصمیم تلقی نشود. |



<a id="at-30"></a>

## AT-30: Exact output contracts

Goal: Exact output contracts.

Execution status: **Planned / Not Executed**. Evidence state: **Evidence Pending**.

Reference contract / authority: **Requirement**. brief_schema.json; qa_answer_schema.json; README.

Unapproved mechanism or gap: Stronger semantic validators separate from permissive schema.

Required evidence and acceptance checks: Every required/nested schema field/type/enum/maxItems/date/value plus all text numbers (Persian, Arabic, Latin and separators) paired with actual JSON/query results; reject unsupported/mismatched/unexecuted SQL numbers.

Related decisions / issues: DL-17, DL-18, REG-ISS-002.

Source Evidence: [AT-30](acceptance-register.md#at-30); [authority basis](../audit-2026-11-09/acceptance-basis.csv).


### Full source record and conditions

| شناسه | آزمون | معیار پذیرش |
|---|---|---|
| AT-30 | قراردادهای دقیق خروجی | همه فیلدهای الزامی Schema، نوع‌های تو‌در‌تو، maxItems، نمایش تاریخ و مقدار و همه Enumها Validation شوند. بررسی‌های قوی‌تر ردیابی منبع جدا اعمال شوند. فایل مثال یا موفقیت Schema به معنی پذیرش عددی، معنایی یا مجوزسنجی نیست. استخراج همه اعداد متن، تطبیق با JSON و Query واقعی و رد عدد بدون منبع یا ناهمخوان طبق معیار تکمیلی زیر، همراه AT-10/11 بررسی شود. |



<a id="supplements"></a>

## Shared source criteria

Apply each supplement to its listed ATs. The quoted source language and all numbers, conditions and negative cases are retained.

<a id="supplement-tests"></a>

### AT supplements

Related tests: AT-01, AT-19, AT-27, AT-10, AT-06, AT-30, AT-11, AT-24, AT-04, AT-05, AT-08, AT-21, AT-28, AT-14, AT-29.

Source Evidence: [Source](acceptance-register.md#decisions-7).


### Full source record and conditions

#### تکمیل معیارهای آزمون موجود

موارد زیر با برچسب بررسی `Requirement Coverage Gap` ثبت می‌شوند. آن‌ها معیارهای ATهای موجود را تکمیل می‌کنند؛ AT جدید نیستند. منابع و قراردادهای موجود با برچسب `Already Covered` فقط ارجاع داده می‌شوند. اجرای آزمون‌ها و Evidence آن‌ها همچنان `Evidence Pending` است.

| AT مرتبط و منبع | نقص پوشش و موارد قابل آزمون | Evidence لازم برای بسته‌شدن |
|---|---|---|
| AT-01، AT-19 و AT-27؛ بریف صفحات ۱۳ و ۱۸؛ [قرارداد دریافت در 002](../002-data-architecture.md#data-4)؛ ADR-16 | یک Source System آزمایشی مستقل با SourceContract و Registry و Adapter اختصاصی اضافه شود. دریافت معتبر، Missing، Schema نامعتبر، Retry و ردیابی منبع بررسی شوند. افزودن Adapter مجاز است، اما به بازطراحی یا تغییر هسته نیاز نداشته باشد. این آزمون با افزودن تیم، KPI یا تغییر Data Root یکسان نیست. | Diff افزونه و تنظیمات در برابر هسته، نسخه قرارداد، رسیدهای دریافت و خطا، Provenance و نتیجه رگرسیون مسیرهای موجود؛ راهنمای افزودن Source در تحویل P5. |
| AT-10؛ بریف صفحه ۹؛ ADR-09؛ [استقلال در 001، بخش ۸](../001-system-blueprint.md#system-8) و [ثبت Evidence در 002، بخش ۸](../002-data-architecture.md#data-8) | علت باید حداقل دو شاهد مستقل داشته باشد. آزمون منفی: دو KPI مشتق از همان جمعیت یا دو ارجاع به نتیجه مشترک، با عوض‌شدن نام گروه مستقل محسوب نشوند. آزمون مثبت: شواهد با مسیر مشاهده و Lineage بررسی‌شده، پس از تأیید استقلال، قابل استفاده باشند؛ تفاوت دو سامانه فیزیکی نه شرط لازم است و نه اثبات کافی. گروه‌بندی آگاه از Lineage همچنان Proposed و روش دقیق ارزیابی Open است. | روش بازبینی‌شده و نسخه‌دار، شواهد و منشأ هر علت، نتیجه و دلیل بررسی استقلال، نمونه مثبت و منفی و ارتباط با InsightVersion و مخاطب مجاز؛ صرف تعداد گروه‌ها قابل قبول نیست. |
| AT-10 و AT-06؛ بریف صفحه ۹؛ ADR-06/09؛ [Data Lineage در 002، بخش ۸](../002-data-architecture.md#data-8) | زنجیره Report Number → QueryRun → Contributors → Source Row → Source File از نظر ارتباط واقعی، Snapshot و Hash بررسی شود. اشاره‌گر قطع‌شده، Contributor نامرتبط و فایل یا نسخه نادرست رد شوند. مجوز نتیجه، Query و هر مرحله Drill-down جدا کنترل شود؛ عدد تجمیعی مجاز، مجوز ردیف محدود نمی‌سازد. | مسیر قابل بازسازی تا فایل اصلی و Manifest، رسید اجرای Query و کنترل Hash، آزمون مثبت مجاز و آزمون منفی دسترسی در سه سطح؛ ردیف محدود نباید در UI، Prompt، Cache، Log یا Export افشا شود. |
| AT-30 با AT-10/11؛ بریف صفحه ۱۶، تعریف عدد درست؛ ADR-09؛ DL-17؛ `dataset/output_contract/brief_schema.json` | همه اعداد متن استخراج و هر عدد با مقدار پشتیبان قابل ردیابی در JSON و `query_id` و Query واقعاً اجراشده تطبیق داده شود. ارقام فارسی، عربی و لاتین و جداکننده هزارگان مطابق بریف تفسیر شوند؛ Precision و Rounding مرجع و تلرانس صفر پس از گردکردن حفظ شوند. عدد بدون منبع، مقدار ناهمخوان و SQL اجرا‌نشده رد شوند. برای متادیتا، تاریخ یا شناسه Exemption جدید ساخته نشود؛ تفسیر مبهم به قرارداد رسمی ارزیابی و DL-16 وابسته است. | فهرست همه اعداد استخراج‌شده و جفت JSON/Query آن‌ها، نتیجه مقایسه با اجرای مرجع در Snapshot و Scope یکسان و نمونه‌های رد؛ Schema Pass به‌تنهایی کافی نیست. |
| AT-24 با AT-04/05/08؛ بریف صفحات ۱۴ و ۱۷؛ ADR-04/07؛ [002، بخش 5.2](../002-data-architecture.md#data-5) | Missing Source، Late Arrival، Historical Correction، Duplicate Payload و Schema Change جداگانه آزموده شوند. هر مورد به‌تنهایی Business Signal نسازد و در مسائل داده ثبت شود. DQIncident، KpiObservation و ارزیابی Signal Eligibility با نسخه و دلیل مرتبط باشند؛ موفقیت SQL یا تغییر تاریخی عدد، به‌تنهایی مجوز Signal جدید نیست. کنترل مثبت، انحراف کسب‌وکار با Evidence مجاز و قاعده معتبر است. وضعیت نامعلوم به سالم تبدیل نشود. | رسید DQ، مشاهده و نتیجه ارزیابی Eligibility برای هر حالت و کنترل مثبت؛ Source Closure و سیاست انتشار داده نامطمئن در DL-03 و قواعد مرزی در DL-09 همچنان Open بمانند. |
| AT-21 و AT-28؛ بریف صفحه ۱۰، کنترل پیش از انتشار؛ ADR-14؛ DL-13 | خطای Validation عمداً ایجاد شود؛ دلیل دقیق به Writer بازگردد، نسخه بازنویسی‌شده دوباره Validation شود و فقط نسخه معتبر منتشر شود. بازنویسی نباید عدد، Query، Snapshot یا Scope را بدون مجوز تغییر دهد. تمام Repairها و Retryها در Budget و Deadline درخواست والد حساب شوند. تداوم شکست نباید Published Success ثبت شود. | نسخه‌های Draft و اصلاح، دلایل رد، رسید Revalidation، زنجیره درخواست والد و Log زمان و هزینه و نتیجه انتشار یا شکست؛ تعداد Retry و سیاست Fallback همچنان Open هستند. |
| AT-14 و AT-29؛ بریف صفحه ۴، پیگیری اقدام، و صفحات ۱۱ و ۱۲؛ ADR-17؛ DL-12؛ [تاریخچه تصمیم در 002](../002-data-architecture.md#data-8) | اقدام باز دارای Deadline، تغییر Deadline و وضعیت، سررسیدرسیده و بسته‌شده با نسخه، عامل و زمان آزموده شوند. Reminder باید به اقدام و نسخه درست متصل و در دامنه مدیر مجاز قابل بررسی باشد. ثبت Draft یا Reminder اجرای اقدام یا ارسال خودکار پیام به کارکنان نیست. روش Reminder، Proposed و قرارداد تأیید اجرای واقعی همچنان Open است. | تاریخچه نسخه‌ها و ارتباط اقدام، تصمیم و سررسید، Evidence یادآوری برای مورد لازم و کنترل منفی مورد بسته یا خارج از Scope؛ نبود فراخوانی ارسال یا اجرای سازمانی بررسی شود. |



<a id="role-matrix"></a>

### Three management levels: full content matrix

Related tests: AT-06, AT-11, AT-12, AT-14, AT-15, AT-26, AT-29.

Source Evidence: [Source](acceptance-register.md#decisions-7).


### Full source record and conditions

#### ماتریس محتوای اختصاصی سه سطح برای AT-26

منبع الزام: بریف صفحه ۵ و صفحات ۱۰ تا ۱۲؛ [محتوای گزارش در 001، بخش ۹](../001-system-blueprint.md#system-9) با برچسب `Already Covered`؛ دسترسی از `dataset/org/access_matrix.csv` و ADR-06. شکاف باقی‌مانده، تفکیک صریح آزمون‌های هر سطح است (`Requirement Coverage Gap`). AT-15 پوشش مدیران فعال را کنترل می‌کند؛ AT-26 محتوای هر بسته را می‌سنجد. هیچ ردیف، تعریف KPI جدید ایجاد نمی‌کند.

| سطح | محتوای الزامی | Scope مجاز | محتوای شرطی | وضعیت خالی مورد انتظار | موارد منفی امنیتی | ردیابی Evidence و Query |
|---|---|---|---|---|---|---|
| مدیر ارشد | پنج شاخص کلیدی سلامت سازمان در برابر هدف؛ وضعیت هر سه Workflow و گلوگاه مراحل؛ بخش موارد تشدیدشده، تصمیم‌های در انتظار و اثر تصمیم‌های قبلی. | تجمیع سازمان و زیرمجموعه مجاز طبق ماتریس و زمان اثر؛ اتاق کنترل Workflow. | درج مورد تشدیدشده، تصمیم معوق یا اثر فقط در صورت وجود؛ هدف یا مقدار غایب با وضعیت روشن. | نبود مورد یا تصمیم معوق صریح بیان شود؛ نبود داده با سالم‌بودن یا صفر جایگزین نشود؛ برای تکمیل پنج شاخص، مقدار یا KPI ساختگی ایجاد نشود. | داده فردی و مرخصی اشخاص، از جمله از طریق Drill-down و شواهد مشترک، افشا نشود. | هر عدد به QueryRun و Snapshot و Scope؛ هر گلوگاه به پرونده و Stage Evidence؛ اثر تصمیم به شواهد مشاهده‌شده و محدودیت آن متصل باشد. |
| مدیر کل | عملکرد تیم‌های فعال زیرمجموعه در برابر هدف و دوره مقایسه؛ مسائل وابسته به واحدهای دیگر؛ بخش گزینه‌های مجاز تخصیص منابع، تصمیم‌ها و اقدام‌های معوق. | تجمیع واحد و تیم‌های زیرمجموعه فعال؛ تعداد تیم از Metadata به دست آید و روی دو تیم ثابت نشود. | گزینه تخصیص منابع و مسئله بین‌واحدی فقط با Evidence و مجوز؛ تصمیم یا اقدام معوق فقط در صورت وجود؛ هیچ گزینه‌ای اجرا نشود. | نبود مسئله، تصمیم یا اقدام معوق مشخص شود؛ نبود مبنای مقایسه یا هدف اعلام شود؛ داده ساختگی تولید نشود. | داده فردی کارکنان، جزئیات محدود واحد دیگر و اتاق کنترل مخصوص مدیر ارشد رد شوند؛ وابستگی بین‌واحدی Grant ایجاد نکند. | شاخص و مقایسه به Query مجاز؛ مسئله بین‌واحدی به Projection مجاز Evidence؛ گزینه و پیگیری به تصمیم و Query پشتیبان متصل باشند. |
| سرپرست تیم | شاخص‌های تیم، وظایف امروز و معوق، بار کاری اعضای مستقیم برای مدیریت کار، سیگنال‌های تیم با شواهد و اقدام‌های درخواست‌شده توسط مدیر بالادستی. | تیم و اعضای مستقیم با Purpose مجاز مدیریت کار؛ ظرفیت مرخصی فقط تجمیعی. | Signal، مانع و اقدام بالادستی فقط در صورت وجود و مجوز؛ داده فردی فقط در مرز سرپرستی مستقیم. | نبود کار معوق، Signal یا اقدام درخواست‌شده روشن باشد؛ داده غایب به نبود کار تعبیر نشود. | داده تیم دیگر، رتبه‌بندی افراد، سرزنش فردی، نمایش مرخصی فردی و اتاق کنترل مدیر ارشد رد شوند. | بار کار به Task و Query مجاز و تاریخ؛ Signal به قاعده و شواهد؛ اقدام به تصمیم، Draft و نسخه سررسید متصل باشد. |

Evidence لازم برای بسته‌شدن شکاف ماتریس: خروجی و رسید Validation هر سه سطح برای حالت دارای محتوا، حالت خالی، داده ناموجود و درخواست نامجاز؛ Snapshot، نسخه Org/Grant و Queryهای مرتبط ثبت شوند. UIهای دستیار گفت‌وگومحور، Dashboard و اتاق کنترل در AT-11/12 با نشست احرازهویت‌شده، فارسی RTL و Drill-down مجاز آزموده شوند (بریف صفحات ۱۱، ۱۳ و ۱۸). ثبت تصمیم یا ارجاع از مسیر مجاز گفتگو به تاریخچه AT-14/29 برسد؛ نمایش UI یا اعتبار JSON به‌تنهایی پذیرش سرتاسری نیست.



<a id="rule-matrix"></a>

### R1-R8: complete acceptance cases

Related tests: AT-24.

Source Evidence: [Source](acceptance-register.md#decisions-7).


### Full source record and conditions

#### موارد اختصاصی قواعد برای AT-24

| قاعده | حداقل موارد برنامه‌ریزی‌شده با پشتوانه منبع | برخورد با مورد حل‌نشده |
|---|---|---|
| R1 | Signal جدید به مالک Canonical ارجاع شود؛ مالک جایگزین و مجوز گسترش داده نشود. | مالک غیرفعال یا فاقد نگاشت همچنان مسئله ارجاع است. |
| R2 | مقدار فراتر از crit؛ مدت برابر N در برابر بیشتر از N؛ بدترشدن دقیقاً 20% نسبت به اولین گزارش. دلایل و تاریخچه حفظ شوند. | تساوی دقیق با crit، مقدار اولیه صفر، روزهای نامعلوم و ساعت چندسطحی به سیاست مصوب نیاز دارند. |
| R3 | شاخص Workflow/ORG فراتر از warn با Evidence مجاز به M01 برسد. | نبود warn عددی Open است؛ از درصد خط پایه warn ساخته نشود. |
| R4 | تغییر کمتر از 10% برای همان گیرنده، مورد جدید نیست و باز می‌ماند. | تغییر دقیقاً 10% به‌طور خودکار مورد جدید را اثبات نمی‌کند؛ مرجع مقایسه و Reset همچنان Open هستند. |
| R5 | چهار مشاهده قبلی همان روز هفته؛ خط پایه Median؛ انحراف بیشتر از N؛ معافیت تعطیلی رسمی. | نمونه‌های غایب، خط پایه صفر، جهت و جمعیت تعطیلی‌های تاریخی به سیاست مصوب نیاز دارند. |
| R6 | بیش از پنج نامزد همچنان حداکثر پنج مورد تولید کند. گروه‌های هم‌علت با پشتوانه شواهد، تاریخچه سری و مالک مجاز را حفظ کنند. | وزن‌های رتبه‌بندی و الگوریتم گروه‌بندی شواهد همچنان Proposed هستند. |
| R7 | نمایش K_ENT_CONTRACT_MTD، K_DIG_SPEND و K_MKT_REV مجاز است، اما هرگز هشدار نمی‌سازند. | در دسترس بودن داده همچنان شرط است؛ info معافیت دسترسی یا کیفیت منبع نیست. |
| R8 | مقدار آستانه مجاز یکسان در روز 7 و روز 8 ماه شمسی: پیش از موعد هشدار آستانه ایجاد نشود و سپس ارزیابی عادی انجام شود. | تساوی با آستانه همچنان نیازمند سیاست مشخص است؛ خود شرط روز 8 ثابت است. |



<a id="oracle-boundaries"></a>

### Calculation, quality and discovery oracles

Related tests: AT-02, AT-04, AT-09.

Source Evidence: [Source](acceptance-register.md#decisions-7).


### Full source record and conditions

### ۷.۱. تفکیک oracle محاسبه، کیفیت و کشف

oracle محاسبه، SQL اصلی روی ورودی پذیرفته‌شده و cutoff مشخص است. CSVهای ممیزی S09-S10 برای regression همان داده مفیدند؛ ستون‌های reportable ممیزی، سیاست مصوب محصول نیستند.

oracle کیفیت، وضعیت source و قرارداد closure است. عدد برابر با SQL، به معنی complete بودن منبع نیست. در آزمون، SQL value و publication state جدا مقایسه شوند.

oracle کشف، برچسب‌های پنهان برگزارکننده است. این برچسب‌ها در workspace نیستند. از نام incident یا تاریخ‌های شناخته‌شده برای ادعای دستیابی به ۹۰٪ استفاده نمی‌شود. با fixtureهای مصنوعی می‌توان سازوکار را آزمون کرد، ولی امتیاز رسمی فقط پس از ارزیابی رسمی معلوم است.



<a id="input-and-negative-cases"></a>

### Manager questions, seven other inputs and adversarial cases

Related tests: AT-03, AT-06, AT-07, AT-13, AT-14, AT-16, AT-22, AT-29.

Source Evidence: [Source](acceptance-register.md#manager-question-map).


### Full source record and conditions

<a id="manager-question-map"></a>

### 7.2. پرسش‌های عرضه‌شده مدیران

این پرسش‌ها ورودی مدیر از S07 هستند، نه پرسش‌های بازبینی معماری در S16. شناسه‌های آن‌ها Namespace جدا دارند. این جدول رفتار مورد انتظار را مشخص می‌کند، نه پاسخ‌های عددی ذخیره‌شده.

| پرسش | رفتار مورد انتظار |
|---|---|
| Q01 / M09 | تیکت روز قبل به تفکیک category در T_RSP؛ توضیح علت فقط با شاهد کافی و داده تا drop065. |
| Q02 / M04 | صبح/روز۶۷ با gap پشتیبانی؛ `data_unavailable` طبق سیاست hold، یا فقط خروجی qualified در صورت پذیرش رسمی؛ صفر جعلی ممنوع. |
| Q03 / M02 | روشن‌کردن دامنهٔ «درآمد» و هدف؛ KPI سازمان خارج از grant واحد را بدون اجازه نخواند. امکان clarification یا refusal؛ سؤال داشتن، grant نمی‌سازد. |
| Q04 / M01 | median روزانهٔ picking در هفت روز گذشته؛ از KPI/query مجاز؛ median هفت median جای آن نباشد. |
| Q05 / M11 | marketplace از آغاز فعالیت مجاز تا دیروز؛ roster، input policy و cutoff رعایت شوند. |
| Q06 / M11 | درآمد کل سازمان خارج از scope؛ `refused_out_of_scope`. |
| Q07 / M01 | «فروش» مبهم؛ تعریف و بازه روشن یا فرض مشخص با امکان تأیید؛ تعریف قدیمی جای خالص مرجع نیاید. |
| Q08 / M03 | درخواست تعداد سفارش؛ policy عملیاتی باید اجازه دهد. بدون resource grant، KPI سازمان قابل استفاده نیست. پاسخ مورد انتظار نیازمند ADR-06 است. |
| Q09 / M02 | attachment فقط پس از دریافت مجاز؛ reconciliation واحد، بازه و تعریف؛ تعریف فایل بیرونی از دو عدد حدس زده نشود. |
| Q10 / M07 | کارهای باز اعضای مستقیم انبار برای مدیریت کار مجاز؛ بدون رتبه‌بندی عملکرد. |
| Q11 / M03 | بارکاری فردی تیم انبار برای مدیر واحد مجاز نیست؛ `refused_individual_data` و پیشنهاد تجمیع تیم. |
| Q12 / M05 | win-rate سی‌روزه به تفکیک lead source؛ query ثبت‌شدهٔ افزوده در scope T_ENT؛ فیلتر won/lost و window مرجع حفظ شود. |
| Q13 / M09 | پرونده‌های T_CMP خارج از تیم؛ `refused_out_of_scope`. |
| Q14 / M08 | تحویل به‌موقع شهر مشهد در سه روز گذشته؛ query با snapshot تا drop089 و unit/precision صحیح. |
| Q15 / M01 | تصمیم‌های مجاز با اثر مشاهده‌شده و uncertainty؛ نتیجه درج‌شده در متن قدیمی جای محاسبه را نگیرد. |
| Q16 / M06 | CPL هفت‌روزه به تفکیک source؛ جمع spend بر جمع lead، NULLIF و هزار تومان؛ نه میانگین CPLهای روزانه. |

Q03 نشان می‌دهد بررسی scope باید قبل از تولید پاسخ عددی باشد. مرجع محاسبهٔ target فعلی `scope='ORG'` است. تیم فروش نباید به بهانهٔ سؤال، هدف یا درآمد کامل سازمان را دریافت کند. راه‌حل نهایی به تأیید policy و معنای سؤال وابسته است.

### 7.2a. ورودی‌های غیرپرسشی مدیران

منبع: S07. این موارد Fixture الزامات هستند، نه شناسه‌های ثابت در کد زمان اجرا. رکورد دقیق ورودی، روز، عامل، محتوا و مرز مورد انتظار در [قراردادهای ورودی مدیر](../audit-2026-11-09/manager-input-contracts.csv) حفظ شده‌اند.

| ورودی | اثر الزامی و مرز آن | آزمون‌های پذیرش برنامه‌ریزی‌شده |
|---|---|---|
| IN01، روز 62، M01، priority | تمرکز بر تحویل و تجربه مشتری برای انتخاب مجاز بعدی، Evidence و تأکید گزارش ذخیره شود. هیچ فرمول یا مجوزی تغییر نمی‌کند. | AT-07، AT-29 |
| IN02، روز 68، M04، decision DE-01 | تصمیم جابه‌جایی موقت نیرو و Draftها و پیگیری مصوب ثبت شوند. جابه‌جایی اجرا یا انتساب تاریخ‌دار کارکنان ساخته نشود. داده ثابت بعدی Replay، منبع مشاهده است. | AT-14، AT-29 |
| IN03، روز 69، M04، decision DE-02 | تصمیم انتشار FAQ و Draftها و پیگیری ثبت شوند. ARKA در سایت واقعی منتشر نمی‌کند. | AT-14، AT-29 |
| IN04، روز 73، M01، upload | صورت‌جلسه به‌عنوان Evidence غیرقابل اعتماد ثبت شود. دستورهای تعبیه‌شده و متن جلسه، مجوزها، اعداد، گیرندگان یا اختیار اقدام را تغییر نمی‌دهند. | AT-13، AT-22، AT-29 |
| IN05، روز 75، M01، org_change | تغییر T_MKT/M11/E25/E26 بدون تغییر کد نسخه‌دار شود. تقدم روز اثر ثابت در برابر صبح بعد همچنان ADR-08 است. | AT-07، AT-15، AT-29 |
| IN06، روز 78، M04، threshold_change | پس از بررسی اختیار، warn مربوط به K_RSP_FRT_MED از 3h به 4h برای صبح 79 نسخه‌دار شود. قواعد قبلی و فرمول Canonical حفظ شوند. دسترسی خواندن به‌تنهایی اختیار نوشتن را اثبات نمی‌کند. | AT-07، AT-29 |
| IN07، روز 80، M02، upload | CSV فروش بیرونی پس از دریافت و پردازش موفق ثبت شود. تعریف آن از دو مقدار حدس زده نشود و پیش از موعد برای پرسش مدیر Q09 خوانده نشود. | AT-03، AT-22، AT-29 |

بریف همچنین بستن و ارجاع مجاز، تغییر Goal و Target و تعریف‌های قابل پیکربندی KPI را الزامی می‌کند. همه این موارد به‌صورت نوع Fixture عرضه نشده‌اند. آن‌ها جدا و بدون ویرایش S07 آزموده شوند. برای پرسش روز D، Dropهای عملیاتی تا D-1 هستند؛ Evidence بارگذاری‌شده همان روز به نسخه آماده و مجاز نیاز دارد و نباید گزارش صبح را بازنویسی کند.

<a id="boundary-cases"></a>

### ۷.۳. آزمون‌های مرزی و خصمانه

- median: empty، all-NULL، odd/even، mixed NULL، عدد منفی، مقدار اعشاری و مرز rounding؛ چهار مورد زمان S08 تکرار شوند.
- گروه: نبود ردیف در برابر NULL، صفر واقعی، مخرج صفر، Dimension جدید، تاریخچه اولیه CRM و آیندهٔ cal.
- تاریخچه: event بسیار دیررس، MIN قبلی، MAX بعدی، reopen، refund بعد از تحویل، فرزند قبل از والد و correction tie متعارض.
- وابستگی: تغییر category در دو گروه، جابه‌جایی timestamp، windowهای هفت/سی روز، MTD، ساعت۲۲ و contributor ثابت‌مقدار.
- امنیت: UNION و CTE به دادهٔ فردی، SQL چنددستوری، function اثرگذار، SET ROLE/set_config، ATTACH، فایل/extension، query پرهزینه و خطای افشاگر.
- جداسازی: cache یک مدیر برای مدیر دیگر استفاده نشود؛ request در pool context قبلی را نگیرد؛ لینک query گذشته به کاربر لغوشده داده نشود.
- Injection: دستور مخفی upload روز۷۳ و متن تیکت، همچنین دستور در header/filename؛ هیچ دستور داده‌ای به control plane نرود.
- تعمیم: جابه‌جایی زمان حوادث، نام فایل‌های schema شناخته‌شده، IDs جدید و تعداد تیم بیشتر؛ هیچ شناسهٔ نمونه در منطق تولیدی لازم نباشد.

fixtureهای مصنوعی در محیط آزمون جدا ساخته می‌شوند. dataset اصلی یا auditها برای ساختن آزمون دستکاری نمی‌شوند.



<a id="measurement"></a>

### Daily performance and cost measurement

Related tests: AT-17, AT-18.

Source Evidence: [Source](../003-roadmap.md#decisions-8).


### Full source record and conditions

<a id="decisions-8"></a>

## ۸. اندازه‌گیری عملکرد و هزینه

در هر روز، زمان واقعی سپری‌شده مراحل ingest، snapshot، facts، KPI، signal، workflow، evidence، LLM و validation ثبت شود. زمان bootstrap روزهای۱ تا۶۰ جدا از زمان هر روز ارزیابی گزارش شود. برای روز کامل، تعداد مدیر واقعی، تعداد پرسش و cache state ثبت شوند.

برای هر فراخوانی مدل، `day, purpose, model_version, input_tokens, output_tokens, cached_tokens, price_version, reserved_cost, actual_cost, retry_of` نگهداری شود. ledger روز با run receipt آشتی داده شود. نرخ ثابتِ بدون تاریخ یا تخمین LLM از هزینه پذیرفته نیست.

گزارش benchmark شامل همهٔ ۳۰ روز، بیشینه، میانه و توزیع زمان باشد. حد پذیرش هر روز کنترل می‌شود؛ میانگین خوب شکست یک روز را پنهان نمی‌کند. مصرف حافظه و حجم archive/snapshot نیز ثبت شود. هدف عددی برای این دو پس از baseline سخت‌افزار تعیین شود.

برای صحت، آمار زیر لازم است: تعداد تعریف و سری، شکست SQL، اختلاف عددی، اختلاف در نبود ردیف، امتناع به دلیل Scope، نشت کشف‌شده، پوشش گزارش، شکست Schema، مسئله باز و تعداد suppressed/escalated. این آمار نباید به سهمیه مصنوعی تعداد Signal تبدیل شود.

تفکیک شمارش با برچسب `Already Covered`: `KPI Definition` تعریف ثبت‌شده در Dictionary است؛ `KPI Series` سری مشخص با Entity و Dimension؛ `KPI Observation` مقدار آن سری در تاریخ و Snapshot معین است. Grain مشاهده و هویت سری در [سند 002، بخش ۲](../002-data-architecture.md#data-2) ثبت شده‌اند. فایل `dataset/config/kpi_dictionary.csv` دارای ۵۵ تعریف با شناسه یکتا است. حدود ۱۵۰ در بریف صفحه ۱ تخمین است، نه Acceptance Threshold. عدد حدود ۷۰ خروجی، گزارش بررسی قبلی تیم در درخواست این بازبینی است و با برچسب `Evidence Pending` ثبت می‌شود؛ خروجی محاسباتی قابل بازرسی برای تأیید آن ارائه نشده است. بسته‌شدن این مورد به فهرست سری‌ها با Definition، Entity، Dimension، تاریخ، Snapshot و Query و روش شمارش بازتولیدپذیر نیاز دارد؛ AT-02 صحت تعریف و AT-10 ردیابی را کنترل می‌کنند. Breakdown شهر، کانال یا محصول فقط با منبع و Dimension و Query پشتیبان معتبر است؛ Ad hoc Query بدون قرارداد، Canonical KPI Definition محسوب نمی‌شود. برای رسیدن به ۱۵۰، KPI یا Dimension ساخته نشود و تعداد هدف جدیدی انتخاب نشود.



<a id="delivery-checklist"></a>

### P5 full delivery checklist

Related tests: AT-11, AT-12, AT-18, AT-19.

Source Evidence: [Source](../003-roadmap.md#decisions-6).


### Full source record and conditions

تکمیل شرط تحویل P5 با برچسب بررسی `Requirement Coverage Gap` (بریف صفحه ۱۸؛ AT-19): علاوه بر Docker، Replay روی Data Root جدید و راهنمای تنظیمات موجود در جدول، بسته تحویل باید سه UI، مخزن کامل Git با تاریخچه تغییرات، راهنمای نصب و افزودن KPI، Source و سطح مدیریتی، گزارش هزینه LLM/API و هزینه زیرساخت و ارائه ۱۰ دقیقه‌ای Demo Day را داشته باشد. برای بستن این شکاف، فهرست مسیر و نسخه اقلام تحویل، Log اجرای دستور Docker و Replay، Evidence سه UI در AT-11/12 و گزارش هزینه در AT-18 بررسی شوند. این شرط، دستور ایجاد مخزن، Commit یا Push در این Task نیست.



<a id="decisions-7"></a>

## ۷. راهبرد آزمون و پذیرش

آزمون‌ها لایه‌ای هستند: قرارداد منبع، محاسبه، تاریخچه، دسترسی، سیگنال، تولید و اجرای کامل. هر آزمون snapshot، input policy، engine/config version و نتیجهٔ قابل بررسی دارد. «نبود exception» یا «متن خوب» معیار صحت نیست.

برچسب‌های `Already Covered`، `Requirement Coverage Gap`، `Open Decision`، `Proposed` و `Evidence Pending` در تکمیل‌های این بازبینی، نتیجه بررسی پوشش هستند؛ وضعیت رسمی ADR را عوض نمی‌کنند. معیارهای افزوده‌شده همگی آزمون برنامه‌ریزی‌شده‌اند. بستن شکاف پوشش آزمون به ثبت اجرای موارد مثبت و منفی و Evidence قابل بازرسی نیاز دارد؛ درج معیار، اجرای موفق یا Passed بودن آن را اثبات نمی‌کند.

<a id="acceptance-authority-notes"></a>



جدول، الزامات منبع و آزمون‌های برنامه‌ریزی‌شده تصمیم‌های Accepted یا سازوکارهای Proposed را ترکیب می‌کند. حدود فعلی بریف با نسخه حفظ شوند. تأیید برگزارکننده طبق DL-16 همچنان لازم است. پس از شکست آزمون، حد بدون اختیار تغییر نکند.

هر ردیف AT یک آزمون پذیرش برنامه‌ریزی‌شده محصول است. هیچ ردیف AT در این ممیزی موفق اعلام نشده است. [فهرست مبنای پذیرش](../audit-2026-11-09/acceptance-basis.csv)، منبع و مبنای Requirement/Accepted/Proposed هر آزمون را مشخص می‌کند. سازوکارهای مهندسی مانند Restore، رفتار دقیق Retry، ثبت اتمی بسته و تأیید نامزد، پیش از اعلام موفقیت به سیاست مصوب خود نیاز دارند.
