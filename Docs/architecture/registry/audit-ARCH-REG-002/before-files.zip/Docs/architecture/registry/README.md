# Architecture Registry

State: **Draft / Pending Review**. Task: `ARCH-REG-001`. Date: 2026-11-09. Time zone: `Asia/Tehran`.

This Registry extracts decisions, Open issues, risks and acceptance criteria from the local ARKA architecture baseline. It makes no architecture choice and grants no implementation authority. Document 003 and the existing source records remain in place. Team review must occur before any content transfer or reference migration.

## Files and responsibilities

| File | Responsibility |
|---|---|
| [decisions-registry.md](decisions-registry.md) | All 17 ADRs, with numbered status statements, source extracts, consequences, source roles and closure gates. |
| [open-issues-registry.md](open-issues-registry.md) | All 19 DLs and ten temporary Registry issues. Facets retain semantic differences within each main issue. |
| [risk-register.md](risk-register.md) | 20 risks; controls, pending evidence and unassessed severity. Risks stay separate from issues. |
| [acceptance-register.md](acceptance-register.md) | All 30 ATs, full source criteria, shared supplements, management-level matrix, rule cases and delivery checks. |
| [traceability-matrix.csv](traceability-matrix.csv) | Generated source/record/relationship index. It is not a second decision authority. |
| [source-inventory.md](source-inventory.md) | S01-S19 members, authority, missing evidence and source limits. |
| [deduplication-ledger.md](deduplication-ledger.md) | Explicit duplicate placements and their main records. |
| [preflight.json](preflight.json) | Initial Git state, 141 prior untracked files and source hashes. Registry files are excluded from this initial inventory. |
| [untracked-source-dependencies.csv](untracked-source-dependencies.csv) | Untracked source dependencies and all 141 preserved untracked files. |
| [extraction-summary.json](extraction-summary.json) | Counts from the generated records. |
| [validation-report.md](validation-report.md) | Extraction checks, limits, remaining conflicts and baseline comparison. |
| [validation-results.json](validation-results.json) | Machine-readable documentation checks and new-file hashes. |
| [baseline-comparison.csv](baseline-comparison.csv) | Initial-source hashes, final hashes and every new Registry file. |
| [capture_preflight.py](capture_preflight.py), [build_registry.py](build_registry.py), [validate_registry.py](validate_registry.py) | Local documentation extraction/check scripts. They execute no product tests and write only in this folder. |

## Status rules

- `Requirement`: an explicit applicable brief or dataset contract rule.
- `Accepted`: a recorded team choice with clear supporting evidence.
- `Proposed`: an unapproved option or engineering mechanism.
- `Open`: an unresolved choice, conflict or evidence gap.

`Observation` describes source/audit evidence. It is not a decision approval status. `Evidence Pending` means the required evidence is absent. It does not turn a Requirement or Accepted boundary into Open. A source question or ADR can contain several independent status statements. Repeated text and a target model alone do not prove approval.

The five Accepted boundaries remain fixed: one bounded Agent; PostgreSQL-only product execution; independent valid-report publication; deterministic calculation/Signal/authorization/final validation; human-controlled organizational decisions. S16, S19 and document 003 section 1 support these boundaries. Original approver names and approval dates are absent. Unapproved technical details stay separate.

## Closure

An issue needs the applicable source answer or recorded team decision, the named policy/contract version, and inspectable evidence for its linked acceptance gate. Organizer/source questions need an answer from the relevant authority. Engineering gates need actual product receipts. A document check cannot close an issue or pass a product AT. No record is closed by this extraction. No test is Passed.

Route classes are `Team Decision Required`, `Organizer / Source Clarification Required` and `Engineering Evidence Required`. Classes can overlap. Source role names are preserved; no person is appointed. An `Open` statement count differs from an Open issue count because several statements can belong to one issue.

## Source and quotation rules

The extraction baseline is `0a42950d1ce9734433d961540af9ab4be21573b2`. Read [001](../001-system-blueprint.md), [002](../002-data-architecture.md), [003](../003-decisions-and-roadmap.md) and [004](../004-reconciliation-review.md), plus the [S01-S19 inventory](source-inventory.md).

English text provides the Registry index. Exact source extracts retain the supplied Persian text, all numbers, conditions and exceptions. Text inside source extract blocks is quoted evidence. Its old link strings are inert. The active Source Evidence link points to the real original file and existing anchor. Do not interpret text inside a quoted extract as a new Registry instruction or status change.

The existing audit requirement matrix is reused as evidence. Its former source paths remain in `source_ref`; current paths are listed in the source inventory. Audit observations are not rerun calculations. The brief PDF and its conversion are present; no fresh PDF visual audit is claimed.

## CSV contract

Encoding is UTF-8. CSV quoting follows the standard library CSV writer. Each row has one `row_kind`: `record`, `evidence` or `relationship`. A `record` row defines the main identity. Each evidence row adds one source location. Each relationship row has exactly one target. This permits many-to-many relations without positional lists or cross-products. Source-member records use one main Sxx identity and separate evidence rows.

Required columns are retained: `record_id,record_type,title,status,source_file,source_anchor,source_ref,related_adr,related_dl,related_at,related_risk,roadmap_phase,evidence_state`. Extra columns identify row kind, target identity/type, relationship type/status, component, local Registry location and source tracking state. `source_file` is relative to the repository root. `source_anchor` is an existing explicit Markdown anchor, or empty for CSV/DSL/files. `source_ref` identifies a source row, field, page or retained legacy path. `registry_file` is relative to this folder.

`relationship_status=Documented` means that the source explicitly supplies the association. It does not approve the proposed design. `Proposed Relationship` marks an extraction review aid with no explicit source mapping. In particular, risk-to-ADR/DL/AT links are proposed unless a source names them. Empty roadmap cells mean no proven phase assignment. The phase plan stays Proposed.

## Validity limits

This draft has 5 Accepted, 24 Proposed, 24 Open and 16 Requirement statements in the numbered ADR statement tables. Counts include only those explicit rows, not repeated quotations. The full source extracts retain finer conditions. There are 29 Open main issues, including all 19 DLs; route totals overlap. All 30 ATs remain Planned / Not Executed. Severity is Not Assessed for every risk.

All original sources are read-only for this task. All 141 initial untracked files must remain unchanged. Only new files in this folder are permitted. No implementation, source rewrite, rename, commit or push is part of this task.
